import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.HorizontalAlignment;
import com.itextpdf.layout.properties.TextAlignment;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class RAPREZERVARI {

	JFrame frame;
	private JSpinner startSpinner;
	private JSpinner endSpinner;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RAPREZERVARI window = new RAPREZERVARI();
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RAPREZERVARI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 15));
		frame.getContentPane().setForeground(Color.DARK_GRAY);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 1550, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton3 = new JButton("");
		btnNewButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RAPCLIENTI window = new RAPCLIENTI();
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				window.frame.setVisible(true);
				frame.dispose();
				
			}
		});
		btnNewButton3.setIcon(new ImageIcon(RAPCLIENTI.class.getResource("/images/icons8-update-left-rotation-24.png")));
		btnNewButton3.setForeground(Color.WHITE);
		btnNewButton3.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 14));
		btnNewButton3.setBackground(Color.LIGHT_GRAY);
		btnNewButton3.setBounds(1491, 817, 33, 33);
		frame.getContentPane().add(btnNewButton3);
		
		
		
		JLabel lblNewLabel_1 = new JLabel("RAPORT REZERVARI");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 19));
		lblNewLabel_1.setBounds(10, 11, 213, 21);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("DATA INCEPUT");
		lblNewLabel_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1_1.setBounds(521, 12, 181, 21);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("DATA FINAL");
		lblNewLabel_1_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1_1_1.setBounds(830, 12, 181, 21);
		frame.getContentPane().add(lblNewLabel_1_1_1);
		
		SpinnerDateModel startModel = new SpinnerDateModel();
        startSpinner = new JSpinner(startModel);
        startSpinner.setFont(new Font("Arial", Font.BOLD, 15));
        startSpinner.setBounds(521, 44, 115, 33); 
        startSpinner.setEditor(new JSpinner.DateEditor(startSpinner, "MM/dd/yyyy"));
        frame.getContentPane().add(startSpinner);
	
        SpinnerDateModel endModel = new SpinnerDateModel();
        endSpinner = new JSpinner(endModel);
        endSpinner.setFont(new Font("Arial", Font.BOLD, 15));
        endSpinner.setBounds(830, 44, 115, 33); 
        endSpinner.setEditor(new JSpinner.DateEditor(endSpinner, "MM/dd/yyyy"));
        frame.getContentPane().add(endSpinner);
        
        JButton button2 = new JButton("AFISEAZA RAPORT");
        button2.setForeground(Color.WHITE);
		button2.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 14));
		button2.setBackground(Color.LIGHT_GRAY);
		button2.setBounds(660, 279, 185, 33);
		frame.getContentPane().add(button2);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				RAPOARTE window = new RAPOARTE();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		lblNewLabel.setIcon(new ImageIcon(RAPREZERVARI.class.getResource("/images/icons8-home-page-48.png")));
		lblNewLabel.setBounds(1478, 11, 46, 40);
		frame.getContentPane().add(lblNewLabel);
		
		JRadioButton radioButton1 = new JRadioButton("Afisare rezervari (+ istoric)");
		radioButton1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
		radioButton1.setBounds(176, 170, 201, 23);
		frame.getContentPane().add(radioButton1);
		
		JRadioButton radioButton2 = new JRadioButton("Afisare rezervari");
		radioButton2.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
		radioButton2.setBounds(425, 170, 139, 23);
		frame.getContentPane().add(radioButton2);
		
		JRadioButton radioButton3 = new JRadioButton("Afisare rezervari dupa status");
		radioButton3.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
		radioButton3.setBounds(618, 170, 213, 23);
		frame.getContentPane().add(radioButton3);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Inregistrata", "Confirmata", "Efectuata"}));
		comboBox.setBounds(857, 168, 131, 23);
		frame.getContentPane().add(comboBox);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(171, 347, 1212, 364);
		frame.getContentPane().add(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		
		JButton button3 = new JButton("Print");
		button3.setForeground(Color.DARK_GRAY);
		button3.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 14));
		button3.setBackground(Color.LIGHT_GRAY);
		button3.setBounds(1260, 718, 123, 23);
		frame.getContentPane().add(button3);
		
		
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				generateReport();
				
				
			}
		});
		
	}
		private void generateReport() {
	        try {
	            
		            Class.forName("com.mysql.cj.jdbc.Driver");
		
		            
		            String url = "jdbc:mysql://localhost:3306/hotel";
		            String username = "root";
		            String password = "Gabriel01";
		            Connection conn = DriverManager.getConnection(url, username, password);
		
		            
		           
		            Date startDate = (Date) startSpinner.getValue();
		            Date endDate = (Date) endSpinner.getValue();
		            SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
		            String formattedsStart = dateFormatter.format(startDate);
					String formattedEnd = dateFormatter.format(endDate);
		            
					// se afiseaza toate datele 
					
		            String query1 = "SELECT * FROM istoric_rezervari WHERE checkin >= ? AND checkout <= ?";
		       		PreparedStatement stmt = conn.prepareStatement(query1);
		            stmt.setDate(1, new java.sql.Date(startDate.getTime()));
		            stmt.setDate(2, new java.sql.Date(endDate.getTime()));
		            ResultSet rs = stmt.executeQuery();
		            
			    
		            SimpleDateFormat dateFormatter2 = new SimpleDateFormat("yyyy-MM-dd");
		            String timeStamp = dateFormatter2.format(startDate);
		            
		        	String filePath = "C:\\Users\\Gabi\\Desktop\\rapoarte_hotel\\"; 
		        	String fileName = filePath + "Raport_rezervari_" + timeStamp + ".pdf";
		        	
				
	
			        PdfWriter writer = new PdfWriter(new FileOutputStream(fileName));
			        PdfDocument pdf = new PdfDocument(writer);
			        Document document = new Document(pdf, PageSize.A4);
	
		            
		            Paragraph title = new Paragraph("RAPORT REZERVARI");
		            title.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
		            document.add(title);
		            
		            Paragraph title2 = new Paragraph("-----------------------------------------------------------------------------"
		            		+ "---------------------------------------------------");
		            title2.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
		            document.add(title2);
	
		            
		            Paragraph perioada = new Paragraph("Perioada raportului: " + formattedsStart.toString() + " - " + formattedEnd.toString());
		            perioada.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
		            document.add(perioada);
	
		            
		            Table table = new Table(11);
		            table.addCell("Cod Rezervare");
		            table.addCell("Cod Client");
		            table.addCell("Nume Client");
		            table.addCell("Numar Camera");
		            table.addCell("Tip Camera");
		            table.addCell("Cod SPA");
		            table.addCell("Nr. Factura");
		            table.addCell("Check-In");
		            table.addCell("Check-Out");
		            table.addCell("Numar de persoane");
		            table.addCell("TOTAL incasare");
		            table.setHorizontalAlignment(HorizontalAlignment.CENTER);
		            
		           
	
		            while (rs.next()) {
		                table.addCell(rs.getString("idrezervare"));
		                table.addCell(rs.getString("idclient"));
		                table.addCell(rs.getString("numeclient"));
		                table.addCell(rs.getString("idcamera"));
		                table.addCell(rs.getString("tipcamera"));
		                table.addCell(rs.getString("idspa"));
		                table.addCell(rs.getString("idfactura"));
		                table.addCell(rs.getString("checkin"));
		                table.addCell(rs.getString("checkout"));
		                table.addCell(rs.getString("numarpers"));
		                table.addCell(rs.getString("totalincasare"));
		                table.setMarginBottom(20);
		            }
		            
		            document.add(table);
		            
		            Paragraph title3 = new Paragraph("-----------------------------------------------------------------------------"
		            		+ "---------------------------------------------------");
		            title3.setTextAlignment(TextAlignment.CENTER).setMarginBottom(20);
		            document.add(title3);
		            
		           
		            String query2= "SELECT COUNT(*) AS total_rezervari FROM istoric_rezervari WHERE checkin >= ? AND checkout <= ?";
		            PreparedStatement stmt2 = conn.prepareStatement(query2);
		            stmt2.setDate(1, new java.sql.Date(startDate.getTime()));
		            stmt2.setDate(2, new java.sql.Date(endDate.getTime()));
		            ResultSet rs2 = stmt2.executeQuery();
		            
		            int totalRezervari=0;
		            if (rs2.next()) {
		            	
		                 totalRezervari = rs2.getInt("total_rezervari");
		            }
		                
		                String totalrezervari = "Numarul total de rezervari intre " +
		                                      dateFormatter.format(startDate) + " si " +
		                                      dateFormatter.format(endDate) + " este: " + totalRezervari;
		                
		                Paragraph totalRezerv = new Paragraph(totalrezervari).setTextAlignment(TextAlignment.CENTER)
		                		.setMarginBottom(15);
		                totalRezerv.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
		                document.add(totalRezerv);
		            
		          
		                    
		                    
		            document.close();
	
		            JOptionPane.showMessageDialog(null, "Raport realizat!");
		            
			} catch (Exception e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(null, "Eroare la generarea raportului!");
	        }
			
			
		
	}
}
