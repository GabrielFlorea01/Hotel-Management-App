import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import javax.swing.JTextField;

import com.mysql.cj.protocol.x.SyncFlushDeflaterOutputStream;

import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import javax.swing.ImageIcon;


public class FORGOT_PASSWORD {

	JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField_1;
	private Button button;
	private Button button_1;
	
	private static final String SQLSELECT_USER = "SELECT * FROM utilizator WHERE emailUtil = ?";
    private static final String SQLUPDATE_PAROLA = "UPDATE utilizator SET parolaUtil = ? WHERE emailUtil = ?";
    private JLabel lblNewLabel_2;
    private JLabel lblNewLabel_3;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FORGOT_PASSWORD window = new FORGOT_PASSWORD();
					window.frame.setVisible(true);
					window.frame.setLocationRelativeTo(null);
					window.frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FORGOT_PASSWORD() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setForeground(Color.DARK_GRAY);
		frame.getContentPane().setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		frame.setResizable(false);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Email");
		lblNewLabel.setForeground(Color.DARK_GRAY);
		lblNewLabel.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setBounds(575, 269, 46, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Parola noua");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setBounds(544, 335, 94, 25);
		frame.getContentPane().add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setFont(new Font("SansSerif", Font.PLAIN, 15));
		textField.setBackground(new Color(255, 255, 255));
		textField.setForeground(new Color(0, 0, 0));
		textField.setBounds(636, 263, 320, 25);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setFont(new Font("SansSerif", Font.PLAIN, 15));
		passwordField_1.setBackground(new Color(255, 255, 255));
		passwordField_1.setForeground(new Color(0, 0, 0));
		passwordField_1.setBounds(636, 334, 320, 25);
		frame.getContentPane().add(passwordField_1);
		
		
		button = new Button("SALVEAZA");
		button.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 14));
		button.setForeground(Color.WHITE);
		button.setBackground(Color.LIGHT_GRAY);
		button.setBounds(723, 428, 104, 35);
		frame.getContentPane().add(button);
		
		button_1 = new Button("INAPOI LA LOGIN");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  LOGIN loginWindow = new LOGIN();
					loginWindow.frame.setVisible(true);
					loginWindow.frame.setLocationRelativeTo(null);
				    frame.dispose();
			
			}
		});
		button_1.setForeground(Color.WHITE);
		button_1.setBackground(Color.LIGHT_GRAY);
		button_1.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 14));
		button_1.setBounds(683, 586, 196, 25);
		frame.getContentPane().add(button_1);
		
		lblNewLabel_2 = new JLabel("FORGOT PASSWORD");
		lblNewLabel_2.setForeground(Color.DARK_GRAY);
		lblNewLabel_2.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 28));
		lblNewLabel_2.setBounds(636, 21, 287, 32);
		frame.getContentPane().add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(FORGOT_PASSWORD.class.getResource("/images/icons8-eye-24.png")));
		lblNewLabel_3.setBounds(966, 335, 24, 25);
		frame.getContentPane().add(lblNewLabel_3);
		frame.setBounds(100, 100, 1550, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		
		button.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		
			String email = textField.getText();
			String parolanoua = passwordField_1.getText();
			
			
			
			if (email.equals("")||parolanoua.equals("")) 
			{
				JOptionPane.showMessageDialog(null, "Fiecare camp trebuie completat !");
			}
			else {
				
				
				try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root",
						"Gabriel01");)
				
				{

						PreparedStatement selectStmt = conn.prepareStatement(SQLSELECT_USER);
		                PreparedStatement updateStmt = conn.prepareStatement(SQLUPDATE_PAROLA); 
		                {
		                	
		            selectStmt.setString(1, email);
		            ResultSet rs = selectStmt.executeQuery();
		            if (rs.next()) {
		                updateStmt.setString(1, parolanoua);
		                updateStmt.setString(2, email);
		                updateStmt.executeUpdate();
		                
		                JOptionPane.showMessageDialog(null, "Parola a fost actualizata cu succes !");
		                LOGIN loginWindow = new LOGIN();
						loginWindow.frame.setVisible(true);
						loginWindow.frame.setLocationRelativeTo(null);
						frame.dispose();
					
		            } else {
		                System.out.println("User negasit !");
		            }
		        
		    
		
					
				 
					
	
				
		}}catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			
			
			
			
	
		}
		
		
		});
		
		
	
	
	}
}

