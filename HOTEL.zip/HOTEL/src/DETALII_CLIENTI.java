import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class DETALII_CLIENTI {

	JFrame frame;
	private JTextField textField;
	private JTable table;
	private JTextField textField2;
	private JTextField textField3;
	private JTextField textField4;
	private JTextField textField5;
	private JTextField textField6;
	private JTextField textField7;
	private JTextField textField8;
	private JTextField textField9;
	private JTextField textField10;
	private JTextField textField11;
	private JTextField textField12;
	private JTextField textField13;
	private JTextField textField14;
	private JTextField textField15;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DETALII_CLIENTI window = new DETALII_CLIENTI();
					window.frame.setVisible(true);
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DETALII_CLIENTI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setForeground(new Color(255, 255, 255));
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Cauta dupa nume");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setBounds(506, 23, 145, 31);
		frame.getContentPane().add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setFont(new Font("SansSerif", Font.PLAIN, 16));
		textField.setBounds(643, 28, 243, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("CAUTA");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Nume = textField.getText();
				
				if (Nume.equals("")) 
				{
					JOptionPane.showMessageDialog(null, "Completeaza nume !");
				}
				else {
					try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
						     PreparedStatement stmt = conn.prepareStatement("SELECT * FROM hotel.client WHERE numeClient= ?");) {
						    stmt.setString(1, Nume);
						    ResultSet rs = stmt.executeQuery();
						    
						    if (rs.next()) {
						        DefaultTableModel tm = (DefaultTableModel)table.getModel();
						        tm.setRowCount(0);
						        
						        do {
						        	 Object o[]= {rs.getInt("IDClient"),rs.getString("numeClient"),rs.getString("telefonClient"),rs.getString("emailClient"),rs.getString("adresa_tara"),rs.getString("adresa_oras"),rs.getString("adresa_strada"),
							            		rs.getString("adresa_numar"), rs.getString("act_identitate"), rs.getString("act_serie"), rs.getString("act_numar"), rs.getString("cnpClient"), rs.getString("cetatenieClient"), rs.getString("provClient"), rs.getString("numarMasina") };
							            tm.addRow(o);
							            
							            textField2.setText(rs.getString("numeClient"));
							            textField3.setText(rs.getString("telefonClient"));
							            textField4.setText(rs.getString("emailClient"));
							            textField5.setText(rs.getString("adresa_tara"));
							            textField6.setText(rs.getString("adresa_oras"));
							            textField7.setText(rs.getString("adresa_strada"));
							            textField8.setText(rs.getString("adresa_numar"));
							            textField9.setText(rs.getString("act_identitate"));
							            textField10.setText(rs.getString("act_serie"));
							            textField11.setText(rs.getString("act_numar"));
							            textField12.setText(rs.getString("cnpClient"));
							            textField13.setText(rs.getString("cetatenieClient"));
							            textField14.setText(rs.getString("provClient"));
							            textField15.setText(rs.getString("numarMasina"));
						            
						        } while(rs.next());
						        
						    } else {
						        JOptionPane.showMessageDialog(null, "Clientul nu a fost gasit !");
						    }
						    
						} catch (SQLException e1) {
						    e1.printStackTrace();
						}
				}
				
				

				
			
			}
		});
		
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.setFont(new Font("Century Gothic", Font.ITALIC, 13));
		btnNewButton.setForeground(Color.DARK_GRAY);
		btnNewButton.setBounds(896, 29, 89, 21);
		frame.getContentPane().add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(36, 137, 1461, 247);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Nume si prenume ", "Telefon", "Email", "Adresa: Tara", "Adresa: Oras", "Adresa: Strada", "Adresa: Nr.", "A.I:Tip", "A.I: Serie", "A.I: Numar", "CNP", "Cetatenie", "Provenienta", "Numar masina"
			}
		));
		table.getColumnModel().getColumn(1).setPreferredWidth(109);
		table.getColumnModel().getColumn(4).setPreferredWidth(90);
		table.getColumnModel().getColumn(5).setPreferredWidth(84);
		table.getColumnModel().getColumn(6).setPreferredWidth(96);
		table.getColumnModel().getColumn(8).setPreferredWidth(56);
		table.getColumnModel().getColumn(9).setPreferredWidth(63);
		table.getColumnModel().getColumn(10).setPreferredWidth(78);
		table.getColumnModel().getColumn(11).setPreferredWidth(122);
		table.getColumnModel().getColumn(12).setPreferredWidth(101);
		table.getColumnModel().getColumn(14).setPreferredWidth(94);
		scrollPane.setViewportView(table);
		table.setBackground(new Color(204, 204, 204));
		
		JButton btnNewButton_5 = new JButton("");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DETALII_CLIENTI dtlclWindow = new DETALII_CLIENTI();
				dtlclWindow.frame.setVisible(true);
				dtlclWindow.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		btnNewButton_5.setIcon(new ImageIcon(DETALII_CLIENTI.class.getResource("/images/icons8-update-left-rotation-24.png")));
		btnNewButton_5.setForeground(new Color(255, 255, 255));
		btnNewButton_5.setBackground(Color.WHITE);
		btnNewButton_5.setFont(new Font("SansSerif", Font.BOLD, 14));
		btnNewButton_5.setBounds(1478, 821, 46, 29);
		frame.getContentPane().add(btnNewButton_5);
		
		JButton btnNewButton_2_1 = new JButton("Modifica datele clientului");
		btnNewButton_2_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton_2_1.setForeground(Color.black);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton_2_1.setForeground(Color.DARK_GRAY);
			}
		});
		
		
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 String nume = textField2.getText();
			        String telefon = textField3.getText();
			        String email = textField4.getText();
			        String adresaTara = textField5.getText();
			        String adresaOras = textField6.getText();
			        String adresaStrada = textField7.getText();
			        String adresaNumar = textField8.getText();
			        String actIdentitate = textField9.getText();
			        String actSerie = textField10.getText();
			        String actNumar = textField11.getText();
			        String cnp = textField12.getText();
			        String cetatenie = textField13.getText();
			        String prov = textField14.getText();
			        String numarMasina = textField15.getText();
			        
			        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "Gabriel01");
			             PreparedStatement stmt = conn.prepareStatement("UPDATE hotel.client SET numeClient = ?, telefonClient = ?, emailClient = ?, adresa_tara = ?, adresa_oras = ?, adresa_strada = ?, adresa_numar = ?, act_identitate = ?, act_serie = ?, act_numar = ?, cnpClient = ?, cetatenieClient = ?, provClient = ?, numarMasina = ? WHERE numeClient = ?")) {
			            
			            stmt.setString(1, nume);
			            stmt.setString(2, telefon);
			            stmt.setString(3, email);
			            stmt.setString(4, adresaTara);
			            stmt.setString(5, adresaOras);
			            stmt.setString(6, adresaStrada);
			            stmt.setString(7, adresaNumar);
			            stmt.setString(8, actIdentitate);
			            stmt.setString(9, actSerie);
			            stmt.setString(10, actNumar);
			            stmt.setString(11, cnp);
			            stmt.setString(12, cetatenie);
			            stmt.setString(13, prov);
			            stmt.setString(14, numarMasina);
			            stmt.setString(15, nume);
			            
			            int rowsUpdated = stmt.executeUpdate();
			            
			         
			            if (rowsUpdated > 0) {
			                JOptionPane.showMessageDialog(null, "Date actualizate cu succes!");
			            } else{
			                JOptionPane.showMessageDialog(null, "Nu s-a modificat nimic !");
			            }
			            
			           
			        } catch (SQLException e1) {
			            e1.printStackTrace();
			        }
			}
		});
		btnNewButton_2_1.setForeground(Color.DARK_GRAY);
		btnNewButton_2_1.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_2_1.setBackground(Color.LIGHT_GRAY);
		btnNewButton_2_1.setBounds(36, 800, 210, 31);
		frame.getContentPane().add(btnNewButton_2_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DASHBOARD window = new DASHBOARD();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		lblNewLabel_2.setIcon(new ImageIcon(DETALII_CLIENTI.class.getResource("/images/icons8-home-page-48.png")));
		lblNewLabel_2.setBounds(1478, 11, 46, 42);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_1_1 = new JLabel("Nume si prenume");
		lblNewLabel_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1_1.setBounds(42, 431, 151, 31);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Telefon");
		lblNewLabel_1_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1_1_1.setBounds(304, 431, 174, 31);
		frame.getContentPane().add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("Email");
		lblNewLabel_1_1_2.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_2.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1_1_2.setBounds(566, 431, 174, 31);
		frame.getContentPane().add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_1_3 = new JLabel("Adresa : tara");
		lblNewLabel_1_1_3.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_3.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1_1_3.setBounds(42, 517, 174, 31);
		frame.getContentPane().add(lblNewLabel_1_1_3);
		
		JLabel lblNewLabel_1_1_3_1 = new JLabel("Adresa : oras");
		lblNewLabel_1_1_3_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_3_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1_1_3_1.setBounds(304, 517, 174, 31);
		frame.getContentPane().add(lblNewLabel_1_1_3_1);
		
		JLabel lblNewLabel_1_1_3_2 = new JLabel("Adresa : strada");
		lblNewLabel_1_1_3_2.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_3_2.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1_1_3_2.setBounds(566, 517, 174, 31);
		frame.getContentPane().add(lblNewLabel_1_1_3_2);
		
		JLabel lblNewLabel_1_1_3_3 = new JLabel("Adresa : numar");
		lblNewLabel_1_1_3_3.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_3_3.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1_1_3_3.setBounds(815, 517, 174, 31);
		frame.getContentPane().add(lblNewLabel_1_1_3_3);
		
		JLabel lblNewLabel_1_1_3_4 = new JLabel("Act identitate : tip");
		lblNewLabel_1_1_3_4.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_3_4.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1_1_3_4.setBounds(42, 612, 174, 31);
		frame.getContentPane().add(lblNewLabel_1_1_3_4);
		
		JLabel lblNewLabel_1_1_3_4_1 = new JLabel("Act identitate : serie");
		lblNewLabel_1_1_3_4_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_3_4_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1_1_3_4_1.setBounds(304, 612, 174, 31);
		frame.getContentPane().add(lblNewLabel_1_1_3_4_1);
		
		JLabel lblNewLabel_1_1_3_4_1_1 = new JLabel("Act identitate : numar");
		lblNewLabel_1_1_3_4_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_3_4_1_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1_1_3_4_1_1.setBounds(566, 612, 174, 31);
		frame.getContentPane().add(lblNewLabel_1_1_3_4_1_1);
		
		JLabel lblNewLabel_1_1_3_4_1_2 = new JLabel("CNP");
		lblNewLabel_1_1_3_4_1_2.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_3_4_1_2.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1_1_3_4_1_2.setBounds(815, 612, 174, 31);
		frame.getContentPane().add(lblNewLabel_1_1_3_4_1_2);
		
		JLabel lblNewLabel_1_1_3_4_1_3 = new JLabel("Cetatenie");
		lblNewLabel_1_1_3_4_1_3.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_3_4_1_3.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1_1_3_4_1_3.setBounds(1080, 612, 174, 31);
		frame.getContentPane().add(lblNewLabel_1_1_3_4_1_3);
		
		JLabel lblNewLabel_1_1_3_4_1_4 = new JLabel("Provenienta");
		lblNewLabel_1_1_3_4_1_4.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_3_4_1_4.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1_1_3_4_1_4.setBounds(826, 431, 174, 31);
		frame.getContentPane().add(lblNewLabel_1_1_3_4_1_4);
		
		JLabel lblNewLabel_1_1_3_4_1_5 = new JLabel("Numar masina (daca este cazul)");
		lblNewLabel_1_1_3_4_1_5.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_3_4_1_5.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1_1_3_4_1_5.setBounds(1041, 431, 224, 31);
		frame.getContentPane().add(lblNewLabel_1_1_3_4_1_5);
		
		textField2 = new JTextField();
		textField2.setFont(new Font("Century Gothic", Font.ITALIC, 13));
		textField2.setColumns(10);
		textField2.setBounds(36, 462, 210, 21);
		frame.getContentPane().add(textField2);
		
		textField3 = new JTextField();
		textField3.setFont(new Font("Century Gothic", Font.ITALIC, 13));
		textField3.setColumns(10);
		textField3.setBounds(293, 462, 224, 21);
		frame.getContentPane().add(textField3);
		
		textField4 = new JTextField();
		textField4.setFont(new Font("Century Gothic", Font.ITALIC, 13));
		textField4.setColumns(10);
		textField4.setBounds(554, 462, 224, 21);
		frame.getContentPane().add(textField4);
		
		textField5 = new JTextField();
		textField5.setFont(new Font("Century Gothic", Font.ITALIC, 13));
		textField5.setColumns(10);
		textField5.setBounds(36, 547, 210, 21);
		frame.getContentPane().add(textField5);
		
		textField6 = new JTextField();
		textField6.setFont(new Font("Century Gothic", Font.ITALIC, 13));
		textField6.setColumns(10);
		textField6.setBounds(293, 547, 210, 21);
		frame.getContentPane().add(textField6);
		
		textField7 = new JTextField();
		textField7.setFont(new Font("Century Gothic", Font.ITALIC, 13));
		textField7.setColumns(10);
		textField7.setBounds(554, 547, 210, 21);
		frame.getContentPane().add(textField7);
		
		textField8 = new JTextField();
		textField8.setFont(new Font("Century Gothic", Font.ITALIC, 13));
		textField8.setColumns(10);
		textField8.setBounds(808, 547, 210, 21);
		frame.getContentPane().add(textField8);
		
		textField9 = new JTextField();
		textField9.setFont(new Font("Century Gothic", Font.ITALIC, 13));
		textField9.setColumns(10);
		textField9.setBounds(36, 647, 185, 21);
		frame.getContentPane().add(textField9);
		
		textField10 = new JTextField();
		textField10.setFont(new Font("Century Gothic", Font.ITALIC, 13));
		textField10.setColumns(10);
		textField10.setBounds(293, 647, 185, 21);
		frame.getContentPane().add(textField10);
		
		textField11 = new JTextField();
		textField11.setFont(new Font("Century Gothic", Font.ITALIC, 13));
		textField11.setColumns(10);
		textField11.setBounds(554, 647, 185, 21);
		frame.getContentPane().add(textField11);
		
		textField12 = new JTextField();
		textField12.setFont(new Font("Century Gothic", Font.ITALIC, 13));
		textField12.setColumns(10);
		textField12.setBounds(808, 647, 210, 21);
		frame.getContentPane().add(textField12);
		
		textField13 = new JTextField();
		textField13.setFont(new Font("Century Gothic", Font.ITALIC, 13));
		textField13.setColumns(10);
		textField13.setBounds(1070, 647, 210, 21);
		frame.getContentPane().add(textField13);
		
		textField14 = new JTextField();
		textField14.setFont(new Font("Century Gothic", Font.ITALIC, 13));
		textField14.setColumns(10);
		textField14.setBounds(815, 462, 185, 21);
		frame.getContentPane().add(textField14);
		
		textField15 = new JTextField();
		textField15.setFont(new Font("Century Gothic", Font.ITALIC, 13));
		textField15.setColumns(10);
		textField15.setBounds(1041, 462, 185, 21);
		frame.getContentPane().add(textField15);
		
		JButton btnNewButton_3 = new JButton("Arata clienti");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
					     PreparedStatement stmt = conn.prepareStatement("SELECT * FROM hotel.client");) {
					    
					    ResultSet rs = stmt.executeQuery();
					    
					    if (rs.next()) {
					        DefaultTableModel tm = (DefaultTableModel)table.getModel();
					        tm.setRowCount(0);
					        
					        do { 
					            Object o[]= {rs.getInt("IDClient"),rs.getString("numeClient"),rs.getString("telefonClient"),rs.getString("emailClient"),rs.getString("adresa_tara"),rs.getString("adresa_oras"),rs.getString("adresa_strada"),
					            		rs.getString("adresa_numar"), rs.getString("act_identitate"), rs.getString("act_serie"), rs.getString("act_numar"), rs.getString("cnpClient"), rs.getString("cetatenieClient"), rs.getString("provClient"), rs.getString("numarMasina") };
					            tm.addRow(o);
					            
					            
					            
					        } while(rs.next());
					        
					    } else {
					        JOptionPane.showMessageDialog(null, "Nu s-au gasit clienti !");
					    }
					    
					} catch (SQLException e1) {
					    e1.printStackTrace();
					}
			}
		});
		btnNewButton_3.setForeground(Color.DARK_GRAY);
		btnNewButton_3.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_3.setBackground(Color.LIGHT_GRAY);
		btnNewButton_3.setBounds(36, 105, 145, 21);
		frame.getContentPane().add(btnNewButton_3);
		frame.setBounds(00, 100, 1550, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
