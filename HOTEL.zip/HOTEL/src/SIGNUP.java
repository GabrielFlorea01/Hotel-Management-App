import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Label;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Button;
import java.awt.Font;
import java.awt.TextField;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import java.awt.TextArea;

import javax.security.auth.login.LoginContext;
import javax.swing.ImageIcon;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;



public class SIGNUP {

	JFrame frame;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SIGNUP window = new SIGNUP();
					window.frame.setVisible(true);
					window.frame.setLocationRelativeTo(null);
					window.frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SIGNUP() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Leelawadee UI", Font.BOLD, 16));
		frame.getContentPane().setBackground(new Color(255, 255, 255));

		Button button_1 = new Button("Inapoi la LOGIN");
	
		
		button_1.setForeground(Color.WHITE);
		button_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		button_1.setBackground(Color.LIGHT_GRAY);
		button_1.setBounds(708, 806, 141, 30);
		frame.getContentPane().add(button_1);
		
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  LOGIN loginWindow = new LOGIN();
					loginWindow.frame.setVisible(true);
					loginWindow.frame.setLocationRelativeTo(null);
				    frame.dispose();
			}});

		frame.setBounds(100, 100, 1550, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		Button button = new Button("SIGN UP");
		button.setForeground(Color.WHITE);
		button.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		button.setBackground(Color.LIGHT_GRAY);
		button.setBounds(708, 503, 129, 30);
		frame.getContentPane().add(button);

		TextField textField1 = new TextField();
		textField1.setFont(new Font("SansSerif", Font.PLAIN, 15));
		textField1.setBounds(614, 308, 330, 25);
		frame.getContentPane().add(textField1);

		TextField textField2 = new TextField();
		textField2.setFont(new Font("SansSerif", Font.PLAIN, 15));
		textField2.setBounds(614, 371, 330, 25);
		frame.getContentPane().add(textField2);

		JLabel lblNewLabel = new JLabel("Nume");
		lblNewLabel.setForeground(Color.DARK_GRAY);
		lblNewLabel.setFont(new Font("Leelawadee UI", Font.BOLD, 16));
		lblNewLabel.setBounds(542, 308, 66, 25);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Email");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("Leelawadee UI", Font.BOLD, 16));
		lblNewLabel_1.setBounds(542, 366, 66, 30);
		frame.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_3 = new JLabel("Parola");
		lblNewLabel_3.setForeground(Color.DARK_GRAY);
		lblNewLabel_3.setFont(new Font("Leelawadee UI", Font.BOLD, 16));
		lblNewLabel_3.setBounds(542, 425, 73, 30);
		frame.getContentPane().add(lblNewLabel_3);

		passwordField = new JPasswordField();
		passwordField.setFont(new Font("SansSerif", Font.PLAIN, 15));
		passwordField.setBounds(614, 428, 330, 25);
		frame.getContentPane().add(passwordField);

		JLabel lblNewLabel_4 = new JLabel("SIGN UP");
		lblNewLabel_4.setBackground(new Color(255, 255, 255));
		lblNewLabel_4.setForeground(Color.DARK_GRAY);
		lblNewLabel_4.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 28));
		lblNewLabel_4.setBounds(708, 35, 141, 38);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
		    boolean passwordVisible = false;

		    @Override
		    public void mouseClicked(MouseEvent e) {
		        passwordVisible = !passwordVisible;
		        updatePasswordVisibility();
		    }

		    private void updatePasswordVisibility() {
		        if (passwordVisible) {
		            passwordField.setEchoChar((char) 0); 
		            lblNewLabel_2.setIcon(new ImageIcon(SIGNUP.class.getResource("/images/icons8-hide-24.png")));
		        } else {
		            passwordField.setEchoChar('*'); 
		            lblNewLabel_2.setIcon(new ImageIcon(SIGNUP.class.getResource("/images/icons8-eye-24.png")));
		        }
		    }
		});

		lblNewLabel_2.setIcon(new ImageIcon(SIGNUP.class.getResource("/images/icons8-eye-24.png")));
		lblNewLabel_2.setBounds(954, 432, 31, 18);
		frame.getContentPane().add(lblNewLabel_2);

		
		

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nume = textField1.getText();
				String email = textField2.getText();
				String parola = passwordField.getText();
				
				
				ResultSet rs=null;
				
		
				if (nume.equals("")||email.equals("")||parola.equals("")) 
				{
					JOptionPane.showMessageDialog(null, "Fiecare camp trebuie completat !");
				}
				
				else{
					
					try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root",
						"Gabriel01");
						
	
					PreparedStatement stmt = conn.prepareStatement("SELECT idUtil from hotel.utilizator WHERE emailUtil= ?");) {
					
						stmt.setString(1, email);
					    rs = stmt.executeQuery();
					  
					    if(rs.next()) 
					    {
					    	
					    	JOptionPane.showMessageDialog(null, "Utilizatorul deja exista !");
					    } 
					    else 
					    {
			
					    	
					    	java.util.Date utilDate = new java.util.Date();
					    	java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
					    	
					    	

					    	PreparedStatement stmt2 = conn.prepareStatement("INSERT INTO utilizator (numeUtil, emailutil, parolaUtil, data_adaugare, aprobat) VALUES (?, ?, ?, ?, ?)");
					    	stmt2.setString(1, nume);
					    	stmt2.setString(2, email);
					    	stmt2.setString(3, parola);
					    	stmt2.setDate(4, sqlDate);
					    	stmt2.setString(5, "NU");
					    	stmt2.executeUpdate();
						    
						    JOptionPane.showMessageDialog(null, "Utilizatorul a fost adaugat cu succes, asteapta aprobarea Adminului !");
						    
						    LOGIN loginWindow = new LOGIN();
							loginWindow.frame.setVisible(true);
							loginWindow.frame.setLocationRelativeTo(null);
						    frame.dispose();
					
						    
					           
					    }
					    
					}
					   
					    catch (SQLException ex) {
					         ex.printStackTrace();
					    
					    }
					 };
					    

			
			}

			
		});

	}
}
