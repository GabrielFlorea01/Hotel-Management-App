import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Label;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Button;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.swing.SwingConstants;
import javax.swing.JDesktopPane;
import javax.swing.JToolBar;
import javax.swing.JInternalFrame;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import java.awt.Component;
import javax.swing.Box;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButtonMenuItem;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.JSlider;
import javax.swing.JEditorPane;
import javax.swing.JTextField;

public class DASHBOARD {

	JFrame frame;
	private JTable table;
	private JTextField textField1;
	private JTable table_1;
	private JTextField textField2;
	private JTable table_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DASHBOARD window = new DASHBOARD();
					window.frame.setVisible(true);
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DASHBOARD() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		frame.getContentPane().setForeground(Color.DARK_GRAY);
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.getContentPane().setLayout(null);
		frame.setBounds(100, 100, 1556, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLabel lblNewLabel = new JLabel("LOG OUT");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (JOptionPane.showConfirmDialog(null, "Sigur vrei sa te deloghzei?", "ATENTIE !",
				        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
				    LOGIN logwindw = new LOGIN();
				    logwindw.frame.setVisible(true);
				    logwindw.frame.setLocationRelativeTo(null);
				    frame.dispose()	;
				} else {
				    
				}
				
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNewLabel.setForeground(Color.RED);
				
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblNewLabel.setForeground(Color.DARK_GRAY);
			}
		});
		
		
		
		
		
		lblNewLabel.setIcon(new ImageIcon(DASHBOARD.class.getResource("/images/icons8-log-out-32.png")));
		lblNewLabel.setForeground(Color.DARK_GRAY);
		lblNewLabel.setBackground(Color.LIGHT_GRAY);
		lblNewLabel.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setBounds(1419, 11, 121, 42);
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(204, 204, 204));
		panel.setBounds(0, -12, 354, 873);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton_1 = new JButton("CAMERE");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton_1.setBackground(Color.lightGray);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton_1.setBackground(Color.darkGray);
			}
		});
		btnNewButton_1.setBounds(0, 305, 353, 51);
		panel.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CAMERE camWindow = new CAMERE();
				camWindow.frame.setVisible(true);
				camWindow.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		
		
		
		
		btnNewButton_1.setBackground(Color.DARK_GRAY);
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		
		JButton btnNewButton7 = new JButton("REZERVARI");
		btnNewButton7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton7.setBackground(Color.lightGray);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton7.setBackground(Color.darkGray);
			}
		});
		btnNewButton7.setBounds(0, 250, 353, 51);
		panel.add(btnNewButton7);
		btnNewButton7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DETALII_REZERVARI rzvwndw = new DETALII_REZERVARI();
				rzvwndw.frame.setVisible(true);
				rzvwndw.frame.setLocationRelativeTo(null);
				frame.dispose();
				
				
			}
		});
		
		
		
		btnNewButton7.setForeground(Color.WHITE);
		btnNewButton7.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		btnNewButton7.setBackground(Color.DARK_GRAY);
		
		JButton btnNewButton_4 = new JButton("CLIENTI");
		btnNewButton_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton_4.setBackground(Color.lightGray);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton_4.setBackground(Color.darkGray);
			}
		});
		
		btnNewButton_4.setBounds(0, 194, 353, 51);
		panel.add(btnNewButton_4);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DETALII_CLIENTI dtlclWindow = new DETALII_CLIENTI();
				dtlclWindow.frame.setVisible(true);
				dtlclWindow.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		btnNewButton_4.setForeground(Color.WHITE);
		btnNewButton_4.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_4.setBackground(Color.DARK_GRAY);
		
		JButton btnNewButton_3 = new JButton("CHECK-OUT");
		btnNewButton_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton_3.setBackground(Color.lightGray);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton_3.setBackground(Color.darkGray);
			}
		});
		btnNewButton_3.setBounds(0, 137, 353, 51);
		panel.add(btnNewButton_3);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CHECK_OUT coutWindow = new CHECK_OUT();
				coutWindow.frame.setVisible(true);
				coutWindow.frame.setLocationRelativeTo(null);
			    frame.dispose();
			}
		});
		
	
		btnNewButton_3.setForeground(Color.WHITE);
		btnNewButton_3.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_3.setBackground(Color.DARK_GRAY);
		
		JButton btnNewButton_5_1 = new JButton("FACTURI");
		btnNewButton_5_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton_5_1.setBackground(Color.lightGray);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton_5_1.setBackground(Color.darkGray);
			}
		});
		btnNewButton_5_1.setBounds(0, 359, 353, 51);
		panel.add(btnNewButton_5_1);
		btnNewButton_5_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FACTURI window = new FACTURI();
				window.frame.setLocationRelativeTo(null);
				window.frame.setVisible(true);
				frame.dispose();
			}
		});
		btnNewButton_5_1.setForeground(Color.WHITE);
		btnNewButton_5_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_5_1.setBackground(Color.DARK_GRAY);
		
		JButton btnNewButton_5 = new JButton("RESTAURANT");
		btnNewButton_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton_5.setBackground(Color.lightGray);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton_5.setBackground(Color.darkGray);
			}
		});
		btnNewButton_5.setBounds(0, 732, 353, 48);
		panel.add(btnNewButton_5);
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RESTAURANT window = new RESTAURANT();
				window.frame.setSize(1550,900);
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		btnNewButton_5.setForeground(Color.WHITE);
		btnNewButton_5.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_5.setBackground(Color.DARK_GRAY);
		
		JButton btnNewButton_6 = new JButton("SPA");
		btnNewButton_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton_6.setBackground(Color.lightGray);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton_6.setBackground(Color.darkGray);
			}
		});
		btnNewButton_6.setBounds(0, 791, 353, 48);
		panel.add(btnNewButton_6);
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SPA spaWindow = new SPA();
				spaWindow.frame.setVisible(true);
				spaWindow.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		btnNewButton_6.setBackground(Color.DARK_GRAY);
		btnNewButton_6.setForeground(Color.WHITE);
		btnNewButton_6.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		
		JButton btnNewButton_2 = new JButton("CHECK-IN");
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton_2.setBackground(Color.lightGray);
			}
		});
		
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton_2.setBackground(Color.darkGray);
			}
		});
		
		
	    btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				REZERVARE_NOUA rzvnWindow = new REZERVARE_NOUA();
				rzvnWindow.frame.setVisible(true);
				rzvnWindow.frame.setLocationRelativeTo(null);
			    frame.dispose();
			}
		});
		
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_2.setBackground(Color.DARK_GRAY);
		btnNewButton_2.setBounds(0, 80, 353, 51);
		panel.add(btnNewButton_2);
		
		JLabel lblNewLabel_4_1 = new JLabel("Rezervari cu check-out astazi:");
		lblNewLabel_4_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_4_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel_4_1.setBackground(Color.WHITE);
		lblNewLabel_4_1.setBounds(804, 251, 268, 38);
		frame.getContentPane().add(lblNewLabel_4_1);
		
		JTextField textField1 = new JTextField();
		textField1.setHorizontalAlignment(SwingConstants.CENTER);
		textField1.setFont(new Font("Leelawadee UI", Font.ITALIC, 15));
		textField1.setEditable(false);
		textField1.setBounds(599, 530, 77, 32);
		frame.getContentPane().add(textField1);
		textField1.setColumns(10);

		JLabel lblNewLabel_4_1_1 = new JLabel("Camere ocupate:");
		
		lblNewLabel_4_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "Gabriel01");)
				{
					
			    PreparedStatement stmt1 = conn.prepareStatement("SELECT COUNT(*) AS total FROM camera");
	            ResultSet rs1 = stmt1.executeQuery();
	            rs1.next();
	            int cameretotale = rs1.getInt("total");

	            PreparedStatement stmt2 = conn.prepareStatement("SELECT COUNT(*) AS ocupate FROM camera WHERE statusCamera = 'Ocupata'");
	            ResultSet rs2 = stmt2.executeQuery();
	            rs2.next();
	            int camereocupate = rs2.getInt("ocupate");

	            double procentcamere = (camereocupate * 100.0) / cameretotale;

				PreparedStatement stmt3= conn.prepareStatement("SELECT * FROM camera WHERE statusCamera='Ocupata'");
                ResultSet rs3= stmt3.executeQuery();
                DefaultTableModel tm2 = (DefaultTableModel) table_1.getModel();
                tm2.setRowCount(0);
                if (!rs3.next()) {
                    JOptionPane.showMessageDialog(null, "Nu sunt camere ocupate!");
                    return;
                }
                do {
                    Object o[] = { rs3.getInt("IDCamera"), rs3.getString("tipCamera"),rs3.getString("dotari") };
                    tm2.addRow(o);
                } while (rs3.next());
                
                textField1.setText(String.format("%.2f%%", procentcamere));
                
			}catch (Exception e2) {
				e2.printStackTrace();
			}
			
		}});
				
		lblNewLabel_4_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_4_1_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 17));
		lblNewLabel_4_1_1.setBackground(Color.WHITE);
		lblNewLabel_4_1_1.setBounds(450, 526, 154, 38);
		frame.getContentPane().add(lblNewLabel_4_1_1);
		
		JTextField textField2 = new JTextField();
		textField2.setFont(new Font("Leelawadee UI", Font.ITALIC, 15));
		textField2.setEditable(false);
		textField2.setColumns(10);
		textField2.setBounds(1357, 532, 77, 33);
		frame.getContentPane().add(textField2);

		JLabel lblNewLabel_4_1_1_1 = new JLabel("Mese ocupate:");
		lblNewLabel_4_1_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			    
				try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "Gabriel01");)
				{
					
			    PreparedStatement stmt1 = conn.prepareStatement("SELECT COUNT(DISTINCT IDMasa) AS meseOcupate FROM restaurant WHERE datapreparat = CURDATE()");
	            ResultSet rs1 = stmt1.executeQuery();
	            rs1.next();
	            int meseOcupate = rs1.getInt("meseOcupate");

	            PreparedStatement stmt2 = conn.prepareStatement("SELECT COUNT(*) AS totalMese FROM camera");
	            ResultSet rs2 = stmt2.executeQuery();
	            rs2.next();
	            int totalMese = rs2.getInt("totalMese");

	            double procentMese = (meseOcupate * 100.0) / totalMese;

					
			    LocalDate currentDate = LocalDate.now();
		        Date azi = Date.valueOf(currentDate);

		        PreparedStatement stmt3 = conn.prepareStatement("SELECT DISTINCT IDMasa, IDRezervare FROM restaurant WHERE datapreparat = ?");
		        stmt3.setDate(1, azi);
		        ResultSet rs3 = stmt3.executeQuery();
				
                DefaultTableModel tm3 = (DefaultTableModel) table_2.getModel();
                tm3.setRowCount(0);
                if (!rs3.next()) {
                    JOptionPane.showMessageDialog(null, "Nu sunt mese ocupate!");
                    return;
                }
                do {
                    Object o[] = { rs3.getInt("IDMasa"), rs3.getString("IDRezervare")};
                    tm3.addRow(o);
                } while (rs3.next());
                
                textField2.setText(String.format("%.2f%%", procentMese));
				
			}catch (Exception e2) {
				e2.printStackTrace();
			}
			
		
	
			}});
		
		lblNewLabel_4_1_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_4_1_1_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 17));
		lblNewLabel_4_1_1_1.setBackground(Color.WHITE);
		lblNewLabel_4_1_1_1.setBounds(1232, 526, 125, 38);
		frame.getContentPane().add(lblNewLabel_4_1_1_1);

		
		

	
		
		
		//tabel check-out
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(450, 300, 1009, 154);
        frame.getContentPane().add(scrollPane);
        table = new JTable();
        table.setModel(new DefaultTableModel(
        	new Object[][] {
        	},
        	new String[] {
        		"ID Rezervare", "ID Client", "ID Camera", "ID Spa", "Data de Check-in", "Data de Check-out", "Numar de persoane", "Status rezervare"
        	}
        ));
        table.getColumnModel().getColumn(3).setPreferredWidth(74);
        table.setFont(new Font("Century Gothic", Font.ITALIC, 14));
        scrollPane.setViewportView(table);
        
        //tabel camere
        JScrollPane scrollPane_1 = new JScrollPane();
        scrollPane_1.setBounds(452, 580, 434, 218);
        frame.getContentPane().add(scrollPane_1);
        table_1 = new JTable();
        table_1.setModel(new DefaultTableModel(
        	new Object[][] {
        	},
        	new String[] {
        		"Numar", "Tip", "Dotari"
        	}
        ));
        table_1.setFont(new Font("Century Gothic", Font.ITALIC, 14));
        scrollPane_1.setViewportView(table_1);
        
        //tabel mese
        JScrollPane scrollPane_2 = new JScrollPane();
        scrollPane_2.setBounds(1019, 583, 440, 211);
        frame.getContentPane().add(scrollPane_2);
        table_2 = new JTable();
        table_2.setModel(new DefaultTableModel(
        	new Object[][] {
        	},
        	new String[] {
        		"Numar masa", "Cod rezervare"
        	}
        ));
        table_2.setFont(new Font("Century Gothic", Font.ITALIC, 14));
        scrollPane_2.setViewportView(table_2);

		

		JButton btnNewButton = new JButton("");
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.setBounds(0, 0, 353, 3);
		panel.add(btnNewButton);

		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        
		                try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "Gabriel01");
		                     PreparedStatement stmt = conn.prepareStatement("SELECT IDRezervare, IDClient, IDCamera, IDSpa, checkIN, checkOUT, numarPers, statusRezerv FROM rezervare WHERE checkOUT = ?");) {

		                    LocalDate azi = LocalDate.now();

		                    stmt.setDate(1, java.sql.Date.valueOf(azi));

		                    ResultSet rs = stmt.executeQuery();
		                    DefaultTableModel tm = (DefaultTableModel) table.getModel();
		                    tm.setRowCount(0);

		                    if (!rs.next()) {
		                        JOptionPane.showMessageDialog(null, "Nu aveti check-out de facut astazi !");
		                        return;
		                    }
		                    do {
		                        Object o[] = { rs.getInt("IDRezervare"), rs.getString("IDClient"), rs.getString("IDCamera"), rs.getString("IDSpa"), rs.getString("checkIN"),
		                                rs.getString("checkOUT"), rs.getString("numarPers"), rs.getString("statusRezerv") };
		                        tm.addRow(o);
		                    } while (rs.next());
		                    
		                  
		                    
		                } catch (SQLException e1) {
		                    e1.printStackTrace();
		                }
		            }
		        

		});

		
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setIcon(new ImageIcon(DASHBOARD.class.getResource("/images/labirint.png")));
		lblNewLabel_4.setForeground(Color.DARK_GRAY);
		lblNewLabel_4.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 26));
		lblNewLabel_4.setBackground(Color.WHITE);
		lblNewLabel_4.setBounds(796, 11, 244, 93);
		frame.getContentPane().add(lblNewLabel_4);
		
		
	
		
		
		
		JLabel lblNewLabel_1 = new JLabel("CLICK PENTRU DETALII");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setBounds(850, 97, 154, 33);
		frame.getContentPane().add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 13));
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DASHBOARD window = new DASHBOARD();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		lblNewLabel_3.setIcon(new ImageIcon(DASHBOARD.class.getResource("/images/icons8-update-left-rotation-24.png")));
		lblNewLabel_3.setBounds(1506, 826, 24, 24);
		frame.getContentPane().add(lblNewLabel_3);
		
		
		
		
		
		
		
		
		
	}
}
