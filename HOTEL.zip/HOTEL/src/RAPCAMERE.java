import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.JSpinner;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.PatternSyntaxException;

import com.itextpdf.io.exceptions.IOException;
import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.exceptions.PdfException;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.List;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.properties.HorizontalAlignment;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.styledxmlparser.jsoup.nodes.Element;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;;

public class RAPCAMERE {

	 private JSpinner startSpinner;
	 private JSpinner endSpinner;
	 private JComboBox<String> comboBox1;
  
    
	JFrame frame;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RAPCAMERE window = new RAPCAMERE();
					window.frame.setResizable(false);
					window.frame.setVisible(true);
					window.frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RAPCAMERE() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 1550, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
	
  
        
        SpinnerDateModel startModel = new SpinnerDateModel();
        startSpinner = new JSpinner(startModel);
        startSpinner.setFont(new Font("Arial", Font.BOLD, 15));
        startSpinner.setBounds(538, 41, 122, 33); 
        startSpinner.setEditor(new JSpinner.DateEditor(startSpinner, "dd/MM/yyyy"));
        frame.getContentPane().add(startSpinner);
        
    
        SpinnerDateModel endModel = new SpinnerDateModel();
        endSpinner = new JSpinner(endModel);
        endSpinner.setFont(new Font("Arial", Font.BOLD, 15));
        endSpinner.setBounds(825, 41, 115, 33); 
        endSpinner.setEditor(new JSpinner.DateEditor(endSpinner, "dd/MM/yyyy"));
        frame.getContentPane().add(endSpinner);
		
		
		
		JButton btnNewButton3 = new JButton("");
		btnNewButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RAPCAMERE window = new RAPCAMERE();
				window.frame.setResizable(false);
				window.frame.setVisible(true);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
				
			}
		});
		btnNewButton3.setIcon(new ImageIcon(RAPCAMERE.class.getResource("/images/icons8-update-left-rotation-24.png")));
		btnNewButton3.setForeground(Color.WHITE);
		btnNewButton3.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 14));
		btnNewButton3.setBackground(Color.LIGHT_GRAY);
		btnNewButton3.setBounds(1492, 823, 32, 27);
		frame.getContentPane().add(btnNewButton3);
		
		
		JButton button2 = new JButton("ARATA RAPORT");
		button2.setForeground(Color.DARK_GRAY);
 		button2.setBackground(Color.LIGHT_GRAY);
 		button2.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 15));
 		button2.setBounds(632, 279, 185, 27);
 		frame.getContentPane().add(button2);
 		
 		JLabel lblNewLabel_1 = new JLabel("RAPORT CAMERE");
 		lblNewLabel_1.setForeground(Color.DARK_GRAY);
 		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 20));
 		lblNewLabel_1.setBounds(10, 11, 181, 21);
 		frame.getContentPane().add(lblNewLabel_1);
 		
 		JLabel lblNewLabel_1_1 = new JLabel("DATA INCEPUT");
 		lblNewLabel_1_1.setForeground(Color.DARK_GRAY);
 		lblNewLabel_1_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 15));
 		lblNewLabel_1_1.setBounds(541, 13, 181, 21);
 		frame.getContentPane().add(lblNewLabel_1_1);
 		
 		JLabel lblNewLabel_1_1_1 = new JLabel("DATA FINAL");
 		lblNewLabel_1_1_1.setForeground(Color.DARK_GRAY);
 		lblNewLabel_1_1_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 15));
 		lblNewLabel_1_1_1.setBounds(832, 13, 181, 21);
 		frame.getContentPane().add(lblNewLabel_1_1_1);
 		
 		JScrollPane scrollPane = new JScrollPane();
 		scrollPane.setBounds(142, 316, 1236, 434);
 		frame.getContentPane().add(scrollPane);
 		
 		
 		
 		table_1 = new JTable();
 		scrollPane.setViewportView(table_1);
 		table_1.setModel(new DefaultTableModel(
 			    new Object[][] {},
 			    new String[] {}
 			));
 		
 		comboBox1 = new JComboBox<String>();
 		comboBox1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
 	    comboBox1.setBounds(590, 206, 167, 23);
 	    frame.getContentPane().add(comboBox1);
 	    
 	    JButton btnNewButton = new JButton("Print");
 	    btnNewButton.setBackground(Color.LIGHT_GRAY);
 	    btnNewButton.setForeground(Color.DARK_GRAY);
 	    btnNewButton.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
 	    btnNewButton.addActionListener(new ActionListener() {
 	    	public void actionPerformed(ActionEvent e) {
 	    		genereazaPDF();
 	    	}
 	
 	    });
 	    
 	    
 	    btnNewButton.setBounds(1270, 761, 108, 23);
 	    frame.getContentPane().add(btnNewButton);
 	    
 	    JLabel lblNewLabel_2 = new JLabel("");
 	    lblNewLabel_2.addMouseListener(new MouseAdapter() {
 	    	@Override
 	    	public void mouseClicked(MouseEvent e) {
 	    		RAPOARTE window = new RAPOARTE();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
 	    	}
 	    });
 	    lblNewLabel_2.setIcon(new ImageIcon(RAPCAMERE.class.getResource("/images/icons8-home-page-48.png")));
 	    lblNewLabel_2.setBounds(1478, 11, 46, 40);
 	    frame.getContentPane().add(lblNewLabel_2);
 	    
 	    JRadioButton radioButton1 = new JRadioButton("Afisare camere");
 	    radioButton1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
 	    radioButton1.setBounds(62, 176, 128, 23);
 	    frame.getContentPane().add(radioButton1);
 	    
 	    JRadioButton radioButton2 = new JRadioButton("Afisare camere disponibile");
 	    radioButton2.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
 	    radioButton2.setBounds(256, 176, 206, 23);
 	    frame.getContentPane().add(radioButton2);
 	    
 	    JRadioButton radioButton3 = new JRadioButton("Afisare camere disponibile dupa tip:");
 	    radioButton3.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
 	    radioButton3.setBounds(535, 176, 272, 23);
 	    frame.getContentPane().add(radioButton3);
 	    
 	    JRadioButton radioButton4 = new JRadioButton("Afisare camere disponibile dupa dotari:");
 	    radioButton4.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
 	    radioButton4.setBounds(886, 176, 272, 23);
 	    frame.getContentPane().add(radioButton4);
 	    
 	    JComboBox<String> comboBox2 = new JComboBox<String>();
 	    comboBox2.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
 	    comboBox2.setBounds(950, 206, 167, 23);
 	    frame.getContentPane().add(comboBox2);
 	    
 	    JRadioButton radioButton5 = new JRadioButton("Cea mai populara camera");
 	    radioButton5.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
 	    radioButton5.setBounds(1235, 176, 197, 23);
 	    frame.getContentPane().add(radioButton5);

 	    comboBox1.addItem("");
 	    comboBox1.addItem("Single");
 	    comboBox1.addItem("Dubla");
 	    comboBox1.addItem("Suita");
 	    comboBox1.addItem("Single Premium");
 	    comboBox1.addItem("Dubla Premium");
 	    comboBox1.addItem("Suita Premium");

 	
 	
 		
		button2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	generateRaport();
            }
        });
		
	}
		
	
	private void generateRaport() {
	    

	    
		String tipSelectat = (String) comboBox1.getSelectedItem();
		
		
			
			try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "Gabriel01");
			         PreparedStatement stmt = conn.prepareStatement("SELECT * FROM hotel.camera WHERE tipCamera = ?")) {

			        stmt.setString(1, tipSelectat);

			        ResultSet rs = stmt.executeQuery();

			        
			        DefaultTableModel tm = new DefaultTableModel();
			        tm.addColumn("Numar");
			        tm.addColumn("Tip");
			        tm.addColumn("Pret");
			        tm.addColumn("Status");

			        while (rs.next()) {
			            Object[] rowData = {rs.getInt("IDCamera"), rs.getString("tipCamera"), rs.getString("pretCamera"), rs.getString("statusCamera")};
			            tm.addRow(rowData);
			        }

			        table_1.setModel(tm);

			        if (tm.getRowCount() == 0) {
			            JOptionPane.showMessageDialog(null, "Selectati un tip de camera!", "Atentie!", JOptionPane.WARNING_MESSAGE);
			        }
			        
			        if (tipSelectat == null) {
				        JOptionPane.showMessageDialog(null, "Selectati un tip de camera!", "Atentie!", JOptionPane.WARNING_MESSAGE);
				        return;
				    }

			    } catch (SQLException e1) {
			        e1.printStackTrace();
			    }
			
		
	}
	
	
	
	private void genereazaPDF() {
        try {
        	
        	Date startDate = (Date) startSpinner.getValue();
            Date endDate = (Date) endSpinner.getValue();
            SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
            String formattedsStart = dateFormatter.format(startDate);
			String formattedEnd = dateFormatter.format(endDate);
			
		    SimpleDateFormat dateFormatter2 = new SimpleDateFormat("yyyy-MM-dd");
	        String timeStamp = dateFormatter2.format(startDate);
	        
	        
	            
	        String filePath = "C:\\Users\\Gabi\\Desktop\\rapoarte_hotel\\"; 
	        String fileName = filePath + "Raport_Camere_" + timeStamp + ".pdf";
			
	       
	        
		    PdfWriter writer = new PdfWriter(new FileOutputStream(fileName));
		    PdfDocument pdf = new PdfDocument(writer);
		    Document document = new Document(pdf, PageSize.A4);
		    
		    Paragraph title = new Paragraph("RAPORT CAMERE");
            title.setTextAlignment(TextAlignment.CENTER).setMarginBottom(25);
            document.add(title);
            
            Paragraph perioada = new Paragraph("Perioada raportului: " + formattedsStart.toString() + " - " + formattedEnd.toString());
            perioada.setTextAlignment(TextAlignment.CENTER).setMarginBottom(20);
            document.add(perioada);
		    
		   
            Table pdfTable = new Table(table_1.getColumnCount());
            
            pdfTable.setHorizontalAlignment(HorizontalAlignment.CENTER);

            if (table_1.getColumnCount() > 0) { 
            
            for (int column = 0; column < table_1.getColumnCount(); column++) {
                Cell cell = new Cell();
                cell.add(new Paragraph(table_1.getColumnName(column)));
                cell.setTextAlignment(TextAlignment.CENTER);
                cell.setWidth(100);
                
                pdfTable.addHeaderCell(cell);
            }

            
            for (int row = 0; row < table_1.getRowCount(); row++) {
                for (int column = 0; column < table_1.getColumnCount(); column++) {
                    Cell cell = new Cell();
                    cell.add(new Paragraph(table_1.getValueAt(row, column).toString()));
                    cell.setTextAlignment(TextAlignment.CENTER);
                    pdfTable.addCell(cell);
                }
            }

            document.add(pdfTable);
            document.close();

            JOptionPane.showMessageDialog(null, "Raportul a fost generat cu succes!", "Succes", JOptionPane.INFORMATION_MESSAGE);
            }} catch (FileNotFoundException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "A aparut o eroare la generarea raportului!", "Eroare", JOptionPane.ERROR_MESSAGE);
        }
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
