import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;

import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.HorizontalAlignment;
import com.itextpdf.layout.properties.TextAlignment;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Button;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class RAPRESTAURANT {

	JFrame frame;
	private JSpinner startSpinner;
	private JSpinner endSpinner;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RAPRESTAURANT window = new RAPRESTAURANT();
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RAPRESTAURANT() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setForeground(Color.DARK_GRAY);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 1550, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		
		JLabel lblNewLabel_1 = new JLabel("RAPORT RESTAURANT");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel_1.setBounds(10, 11, 235, 21);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("DATA INCEPUT");
		lblNewLabel_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel_1_1.setBounds(522, 11, 146, 21);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("DATA FINAL");
		lblNewLabel_1_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel_1_1_1.setBounds(828, 11, 126, 21);
		frame.getContentPane().add(lblNewLabel_1_1_1);
		
		SpinnerDateModel startModel = new SpinnerDateModel();
        startSpinner = new JSpinner(startModel);
        startSpinner.setFont(new Font("Arial", Font.BOLD, 15));
        startSpinner.setBounds(522, 43, 115, 33); 
        startSpinner.setEditor(new JSpinner.DateEditor(startSpinner, "MM/dd/yyyy"));
        frame.getContentPane().add(startSpinner);
	
        SpinnerDateModel endModel = new SpinnerDateModel();
        endSpinner = new JSpinner(endModel);
        endSpinner.setFont(new Font("Arial", Font.BOLD, 15));
        endSpinner.setBounds(828, 43, 115, 33); 
        endSpinner.setEditor(new JSpinner.DateEditor(endSpinner, "MM/dd/yyyy"));
        frame.getContentPane().add(endSpinner);
        
        JButton button2 = new JButton("AFISEAZA RAPORT");
		button2.setForeground(Color.DARK_GRAY);
		button2.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 14));
		button2.setBackground(Color.LIGHT_GRAY);
		button2.setBounds(650, 261, 185, 27);
		frame.getContentPane().add(button2);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				RAPOARTE window = new RAPOARTE();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		lblNewLabel.setIcon(new ImageIcon(RAPRESTAURANT.class.getResource("/images/icons8-home-page-48.png")));
		lblNewLabel.setBounds(1478, 11, 46, 42);
		frame.getContentPane().add(lblNewLabel);
		
		JButton button1 = new JButton("");
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RAPRESTAURANT window = new RAPRESTAURANT();
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				window.frame.setVisible(true);
				frame.dispose();
				
			}
		});
		button1.setBackground(Color.LIGHT_GRAY);
		button1.setIcon(new ImageIcon(RAPRESTAURANT.class.getResource("/images/icons8-update-left-rotation-24.png")));
		button1.setBounds(1489, 823, 35, 27);
		frame.getContentPane().add(button1);
		
		JRadioButton radioButton1 = new JRadioButton("Afisare rezervari cu consumatie");
		radioButton1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
		radioButton1.setBounds(91, 163, 228, 23);
		frame.getContentPane().add(radioButton1);
		
		JRadioButton radioButton2 = new JRadioButton("Afisarea tutuor meselor");
		radioButton2.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
		radioButton2.setBounds(426, 163, 176, 23);
		frame.getContentPane().add(radioButton2);
		
		JRadioButton radioButton3 = new JRadioButton("Afisarea mesei ( + detalii ) :");
		radioButton3.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
		radioButton3.setBounds(734, 163, 193, 23);
		frame.getContentPane().add(radioButton3);
		
		JComboBox comboBox1 = new JComboBox();
		comboBox1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 15));
		comboBox1.setBounds(938, 164, 87, 22);
		frame.getContentPane().add(comboBox1);
		
		JRadioButton radioButton4 = new JRadioButton("Afisarea celui mai popular preparat");
		radioButton4.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
		radioButton4.setBounds(1147, 163, 252, 23);
		frame.getContentPane().add(radioButton4);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(91, 312, 1320, 426);
		frame.getContentPane().add(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		
		JButton button3 = new JButton("Print");
		button3.setForeground(Color.DARK_GRAY);
		button3.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 14));
		button3.setBackground(Color.LIGHT_GRAY);
		button3.setBounds(1297, 746, 115, 21);
		frame.getContentPane().add(button3);
		
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				generateReport();
				
			}
		});
		
	}
	
	
	private void generateReport() {
	    try {
	        String url = "jdbc:mysql://localhost:3306/hotel";
	        String username = "root";
	        String password = "Gabriel01";
	        Connection conn = DriverManager.getConnection(url, username, password);

	        Date startDate = (Date) startSpinner.getValue();
	        Date endDate = (Date) endSpinner.getValue();

	        String filePath = "C:\\Users\\Gabi\\Desktop\\rapoarte_hotel\\";
	        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
	        String timeStamp = dateFormatter.format(startDate);
	        String fileName = filePath + "Raport_restaurant_" + timeStamp + ".pdf";

	        PdfWriter writer = new PdfWriter(new FileOutputStream(fileName));
	        PdfDocument pdf = new PdfDocument(writer);
	        Document document = new Document(pdf, PageSize.A4);

	        Paragraph title = new Paragraph("RAPORT RESTAURANT");
	        title.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
	        document.add(title);

	        Paragraph title2 = new Paragraph("-----------------------------------------------------------------------------"
	            + "---------------------------------------------------");
	        title2.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
	        document.add(title2);

	        SimpleDateFormat dateFormatter2 = new SimpleDateFormat("dd/MM/yyyy");
	        String formattedStart = dateFormatter2.format(startDate);
	        String formattedEnd = dateFormatter2.format(endDate);

	        Paragraph perioada = new Paragraph("Perioada raportului: " + formattedStart + " - " + formattedEnd);
	        perioada.setTextAlignment(TextAlignment.CENTER).setMarginBottom(20);
	        document.add(perioada);

	        Table table = new Table(2);
	        table.setHorizontalAlignment(HorizontalAlignment.CENTER);
	        table.addCell("Numar camera");
	        table.addCell("A optat pentru restaurant");

	        String query = "SELECT DISTINCT istoric_rezervari.idcamera, " +
	                "CASE WHEN EXISTS (SELECT 1 FROM istoric_restaurant " +
	                "WHERE idmasa = istoric_rezervari.idcamera AND datapreparat BETWEEN ? AND ?) " +
	                "THEN 'DA' ELSE 'NU' END AS optiune_restaurant " +
	                "FROM istoric_rezervari " +
	                "LEFT JOIN istoric_restaurant ON istoric_rezervari.idcamera = istoric_restaurant.idmasa " +
	                "WHERE checkin >= ? AND checkout <= ?";

	        PreparedStatement stmt = conn.prepareStatement(query);
	        stmt.setDate(1, new java.sql.Date(startDate.getTime()));
	        stmt.setDate(2, new java.sql.Date(endDate.getTime()));
	        stmt.setDate(3, new java.sql.Date(startDate.getTime()));
	        stmt.setDate(4, new java.sql.Date(endDate.getTime()));

	        ResultSet rs = stmt.executeQuery();
	        boolean hasData = false;

	        while (rs.next()) {
	            String numarCamera = String.valueOf(rs.getInt("idcamera"));
	            String optiuneRestaurant = rs.getString("optiune_restaurant");

	            if (optiuneRestaurant.equals("DA")) {
	                table.addCell(numarCamera).setTextAlignment(TextAlignment.CENTER);;
	                table.addCell(optiuneRestaurant).setTextAlignment(TextAlignment.CENTER);;
	                table.setHorizontalAlignment(HorizontalAlignment.CENTER);
	                table.setMarginBottom(20);
	                hasData = true;
	            }
	            
	           
	        }

	        if (!hasData) {
	            Paragraph nuexista = new Paragraph("Nu exista rezervari cu restaurant in perioada " + formattedStart
	                    + " - " + formattedEnd);
	            nuexista.setTextAlignment(TextAlignment.CENTER).setMarginBottom(20);
	            document.add(nuexista);
	            
	        } else {
	        	document.add(table);
	        	 if (hasData) {
		                int rowCount = table.getNumberOfRows() - 1; 
		                Paragraph totalRows = new Paragraph("Total de rezervari cu restaurant: " + rowCount);
		                totalRows.setTextAlignment(TextAlignment.CENTER).setMarginBottom(20);
		                document.add(totalRows);
		            }
	        	
	        	}
	        
	        document.close();
	        JOptionPane.showMessageDialog(null, "Raport generat cu succes!");
	        RAPRESTAURANT window = new RAPRESTAURANT();
			window.frame.setResizable(false);
			window.frame.setLocationRelativeTo(null);
			window.frame.setVisible(true);
	        

	    } catch (SQLException ex) {
	        JOptionPane.showMessageDialog(null, "Eroare la generarea raportului: " + ex.getMessage());
	        
	    } catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	    
	}
}
	    
	
