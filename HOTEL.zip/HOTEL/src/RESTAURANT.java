import java.awt.EventQueue;

import javax.swing.JFrame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JList;
import java.awt.event.ContainerAdapter;
import java.awt.event.ContainerEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.util.ArrayList;
import javax.swing.JSpinner;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.border.LineBorder;

public class RESTAURANT {

	
	JFrame frame;
	private JTextField textField;
	private JTextField textField3;
	private JTextField textField4;
	private JTable table;
	private JTextField textField5;
	private JTable table2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RESTAURANT window = new RESTAURANT();
					window.frame.setSize(1550,900);
					window.frame.setVisible(true);
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RESTAURANT() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Arial", Font.BOLD, 15));
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setBounds(100,100, 1500,900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("RESTAURANT");
		lblNewLabel.setForeground(Color.DARK_GRAY);
		lblNewLabel.setBackground(Color.DARK_GRAY);
		lblNewLabel.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setIcon(new ImageIcon(RESTAURANT.class.getResource("/images/icons8-restaurant-on-site-48.png")));
		lblNewLabel.setBounds(21, 22, 180, 56);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RESTAURANT window = new RESTAURANT();
				window.frame.setSize(1550,900);
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		btnNewButton_2.setBackground(Color.LIGHT_GRAY);
		btnNewButton_2.setIcon(new ImageIcon(RESTAURANT.class.getResource("/images/icons8-update-left-rotation-24.png")));
		btnNewButton_2.setBounds(1470, 135, 41, 26);
		frame.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel_1 = new JLabel("Introdu numarul mesei");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setBackground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setBounds(530, 43, 180, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Selecteaza preparatul :");
		lblNewLabel_2.setForeground(Color.DARK_GRAY);
		lblNewLabel_2.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_2.setBounds(384, 183, 214, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
	
		
		textField = new JTextField();
		textField.setFont(new Font("Arial", Font.BOLD, 16));
		textField.setBounds(715, 39, 81, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JComboBox<String >comboBox = new JComboBox<String>();
		comboBox.setFont(new Font("Century Gothic", Font.ITALIC, 15));
		comboBox.setBounds(384, 208, 276, 26);
		frame.getContentPane().add(comboBox);
		comboBox.removeAllItems();
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(384, 307, 250, 43);
		frame.getContentPane().add(scrollPane);
		
		String[] columnNames = {"Cod Preparat", "Pret"};
		DefaultTableModel model = new DefaultTableModel(columnNames, 0);
		JTable table = new JTable();
		table.setFont(new Font("Arial", Font.PLAIN, 14));
		table.setModel(model);
		scrollPane.setViewportView(table);
		
		JScrollPane scrollPane2 = new JScrollPane();
		scrollPane2.setBounds(695, 164, 816, 514);
		frame.getContentPane().add(scrollPane2);
		
		String[] columnNume = {"Numar masa", "Denumire", "Data", "Cantitate"};
		DefaultTableModel model2 = new DefaultTableModel(columnNume, 0);
		JTable table2 = new JTable();
		table2.setBorder(new LineBorder(new Color(0, 0, 0)));
		table2.setFont(new Font("Century Gothic", Font.ITALIC, 14));
		table2.setModel(model2);
		scrollPane2.setViewportView(table2);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Categorie();
			}

			private void Categorie() {
               	 String categorie = (String) comboBox_1.getSelectedItem();
            	 comboBox.removeAllItems();
            	 
            	 try {
            		 Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
            		 PreparedStatement stmt5 = conn.prepareStatement("SELECT descriere FROM preparate WHERE categorie = ?");
          		     stmt5.setString(1, categorie);

          		        
          		    ResultSet rs3 = stmt5.executeQuery();

          		       
      		        while (rs3.next()) {
      		            String preparat = rs3.getString("descriere");
      		            comboBox.addItem(preparat);
      		        }
            		 
					
				} catch (Exception e) {
					
				}

            		   
   				
   			}
			
		});
		
		
		comboBox_1.setFont(new Font("Century Gothic", Font.ITALIC, 14));
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"", "MIC DEJUN", "PRANZ SI CINA", "GARNITURI", "DESERTURI", "BAUTURI NON-ALCOOLICE", "BAUTURI ALCOOLICE"}));
		comboBox_1.setBounds(71, 211, 214, 26);
		frame.getContentPane().add(comboBox_1);
		
		
		
		
		
		JButton btnNewButton_5 = new JButton("Go");
		btnNewButton_5.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String id = textField.getText();

		        if (id.equals("")) {
		            JOptionPane.showMessageDialog(null, "Completeaza numarul camerei !");
		        } else {
		            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01")) {
		                PreparedStatement stmtGETcamera = conn.prepareStatement("SELECT IDCamera FROM camera");
		                ResultSet rscamera = stmtGETcamera.executeQuery();
		                boolean exista = false;

		                while (rscamera.next()) {
		                    int nrcam = rscamera.getInt("IDCamera");
		                    if (nrcam == Integer.parseInt(textField.getText())) {
		                        exista = true;
		                        break;
		                    }
		                }

		                if (exista) {
		                    PreparedStatement smtSELECTmasa= conn.prepareStatement("SELECT * FROM rezervare WHERE IDCamera= ?");
		                    smtSELECTmasa.setInt(1, Integer.parseInt(id));
		                    ResultSet rs1 = smtSELECTmasa.executeQuery();

		                    if (rs1.next()) {
		                        JOptionPane.showMessageDialog(null, "Masa cu numarul " + id + " a fost selectata!");

		                        PreparedStatement stmtComanda = conn.prepareStatement("SELECT restaurant.IDMasa, restaurant.IDRezervare, preparate.descriere, preparate.categorie,  restaurant.datapreparat, restaurant.cantitate "
		                                + "FROM restaurant JOIN preparate ON restaurant.IDPreparat = preparate.IDPreparat "
		                                + "WHERE restaurant.IDMasa = ?");

		                        stmtComanda.setInt(1, Integer.parseInt(id));
		                        ResultSet rSet = stmtComanda.executeQuery();

		                        DefaultTableModel tm = (DefaultTableModel) table2.getModel();
		                        tm.setRowCount(0);

		                        while (rSet.next()) {
		                            Object o[] = {rSet.getInt("IDMasa"), rSet.getString("descriere"), rSet.getDate("datapreparat"), 
		                                rSet.getInt("cantitate"),rSet.getString("categorie"),rSet.getInt("IDRezervare")};
		                            tm.addRow(o);
		                        }

		                        int numarPers = 0;
		                        PreparedStatement stmt4 = conn.prepareStatement("SELECT numarPers FROM hotel.rezervare WHERE IDCamera = ?");
		                        stmt4.setString(1, id);
		                        ResultSet rs2 = stmt4.executeQuery();
		                        if (rs2.next()) {
		                            numarPers = rs2.getInt("numarPers");
		                        }
		                        textField3.setText(Integer.toString(numarPers));
		                        textField4.setText(id);

		                        comboBox.addActionListener(new ActionListener() {
		                            public void actionPerformed(ActionEvent e) {
		                                String selectedPreparat = (String) comboBox.getSelectedItem();

		                                try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
		                                        PreparedStatement stmt = conn.prepareStatement("SELECT IDPreparat, pret FROM hotel.preparate WHERE descriere = ?")) {

		                                    stmt.setString(1, selectedPreparat);
		                                    ResultSet rs = stmt.executeQuery();

		                                    model.setRowCount(0);
		                                    while (rs.next()) {
		                                        int id = rs.getInt("IDPreparat");
		                                        double pret = rs.getDouble("pret");
		                                        model.addRow(new Object[]{id, pret});
		                                    }
		                                } catch (SQLException ex) {
		                                    ex.printStackTrace();
		                                }
		                            }
		                        });
		                    } else {
		                        JOptionPane.showMessageDialog(null, "Masa cu numarul " + id + " nu are rezervare !");
		                    }
		                } else {
		                    JOptionPane.showMessageDialog(null, "Camera nu exista!");
		                }
		            } catch (SQLException ex) {
		                ex.printStackTrace();
		            }
		        }
		    }
		});

		
		
		JSpinner spinner = new JSpinner();
		spinner.setFont(new Font("Century Gothic", Font.BOLD, 16));
		spinner.setBounds(71, 325, 96, 38);
		frame.getContentPane().add(spinner);
		
		spinner.addChangeListener(new ChangeListener() {
		    public void stateChanged(ChangeEvent e) {
		    	
		        String preparat = (String) comboBox.getSelectedItem();

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
		             PreparedStatement stmt = conn.prepareStatement("SELECT IDPreparat, pret FROM hotel.preparate WHERE descriere = ?")) {

		            stmt.setString(1, preparat);
		            ResultSet rs = stmt.executeQuery();

		            if (rs.next()) {
		            	double pret = rs.getDouble("pret");
		                int cantitate = (int) spinner.getValue();
		                double total = pret * cantitate;
		                textField5.setText(String.format("%.2f", total));
		                
		                
		            }

		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }

		    }
		});


		
		btnNewButton_5.setForeground(Color.DARK_GRAY);
		btnNewButton_5.setFont(new Font("Eras Bold ITC", Font.ITALIC, 14));
		btnNewButton_5.setBackground(Color.LIGHT_GRAY);
		btnNewButton_5.setBounds(806, 39, 81, 26);
		frame.getContentPane().add(btnNewButton_5);
		
	
		
		JLabel lblNewLabel_4 = new JLabel("Numar de persoane");
		lblNewLabel_4.setForeground(Color.DARK_GRAY);
		lblNewLabel_4.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_4.setBounds(708, 701, 150, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Numar camera");
		lblNewLabel_5.setForeground(Color.DARK_GRAY);
		lblNewLabel_5.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_5.setBounds(1007, 701, 125, 14);
		frame.getContentPane().add(lblNewLabel_5);
		

		textField3 = new JTextField();
		textField3.setFont(new Font("Arial", Font.BOLD, 15));
		textField3.setEditable(false);
		textField3.setBounds(708, 726, 62, 26);
		frame.getContentPane().add(textField3);
		textField3.setColumns(10);
		
		textField4 = new JTextField();
		textField4.setFont(new Font("Arial", Font.BOLD, 15));
		textField4.setEditable(false);
		textField4.setBounds(1007, 726, 62, 26);
		frame.getContentPane().add(textField4);
		textField4.setColumns(10);
		
		JLabel lblNewLabel_2_1 = new JLabel("DETALII :");
		lblNewLabel_2_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_2_1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_2_1.setBounds(384, 289, 71, 14);
		frame.getContentPane().add(lblNewLabel_2_1);
		
	
		
		JLabel lblNewLabel_2_1_1_1 = new JLabel("Introdu cantitatea :");
		lblNewLabel_2_1_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_2_1_1_1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_2_1_1_1.setBounds(71, 289, 150, 14);
		frame.getContentPane().add(lblNewLabel_2_1_1_1);
		
		JLabel lblNewLabel_2_1_1_1_1 = new JLabel("TOTAL :");
		lblNewLabel_2_1_1_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_2_1_1_1_1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_2_1_1_1_1.setBounds(71, 408, 81, 14);
		frame.getContentPane().add(lblNewLabel_2_1_1_1_1);
		
		textField5 = new JTextField();
		textField5.setFont(new Font("SansSerif", Font.BOLD, 15));
		textField5.setEditable(false);
		textField5.setBounds(71, 432, 114, 32);
		frame.getContentPane().add(textField5);
		textField5.setColumns(10);
		
		
		
		
		JButton btnNewButton6 = new JButton("ADAUGA");
		btnNewButton6.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	
		        String idmasa = textField4.getText();
		        String selectedPreparat = (String) comboBox.getSelectedItem();
		        int cantitate = (int) spinner.getValue();
		        int idRezervare = 0;

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01")) 
		        {
		            // se verifica daca exista deja in lista 
		        	
		            PreparedStatement stmt2 = conn.prepareStatement("SELECT * FROM hotel.restaurant WHERE IDMasa = ? AND IDPreparat = ?");
		            stmt2.setString(1, idmasa);
		            stmt2.setString(2, selectedID(selectedPreparat, conn));
		            ResultSet rs2 = stmt2.executeQuery();

		            if (rs2.next()) {
		                // deja exista se intreaba daca se doreste updatarea sau stergerea sa
		            	
		                int choice = JOptionPane.showOptionDialog(null, "Preparatul exista deja la masa. Doriti sa il actualizati sau sa il stergeti?", "Preparat existent !", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new String[] {"Update", "Stergere"}, null);
		                if (choice == JOptionPane.YES_OPTION) {
		                	 spinner.setValue(0);
		                	 textField5.setText("");
		    	
		                } else if (choice == JOptionPane.NO_OPTION) {
		                	PreparedStatement stmt = conn.prepareStatement("DELETE FROM hotel.restaurant WHERE IDMasa = ? AND IDPreparat = ?");
		                    stmt.setString(1, idmasa);
		                    stmt.setString(2, selectedID(selectedPreparat, conn));
		                    stmt.executeUpdate();
		                    JOptionPane.showMessageDialog(null, "Preparatul a fost sters de la masa cu succes!");
		                }
		            } else {
		            	
		                // preparatul nu exista, se face inserarea
		            	
		            	PreparedStatement stmtGETrezervare = conn.prepareStatement("SELECT * FROM rezervare WHERE IDCamera=?");
		            	stmtGETrezervare.setString(1, idmasa);
		            	ResultSet rsgetrezerv =stmtGETrezervare.executeQuery();
		            	if (rsgetrezerv.next()) {
		            		 idRezervare= rsgetrezerv.getInt("IDRezervare");
							
						}
		            	
		                PreparedStatement stmtInsert = conn.prepareStatement("INSERT INTO hotel.restaurant (IDMasa, IDPreparat, datapreparat, cantitate, IDRezervare) VALUES (?, ?, ?, ?, ?)");

		                LocalDateTime now = LocalDateTime.now();
		                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		                String formattedDateTime = now.format(formatter);

		                stmtInsert.setString(1, idmasa);
		                stmtInsert.setString(2, selectedID(selectedPreparat, conn));
		                stmtInsert.setString(3, formattedDateTime);
		                stmtInsert.setInt(4, cantitate);
		                stmtInsert.setInt(5, idRezervare);
		                stmtInsert.executeUpdate();

		                JOptionPane.showMessageDialog(null, "Preparatul a fost adaugat la masa!");
		                spinner.setValue(0);
		                textField5.setText("");
		                DefaultTableModel tm = (DefaultTableModel) table.getModel();
		                tm.setRowCount(0);
		                
		            }
		            
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }

		    private String selectedID(String selectedPreparat, Connection conn) throws SQLException {
		        PreparedStatement stmt = conn.prepareStatement("SELECT IDPreparat FROM hotel.preparate WHERE descriere = ?");
		        stmt.setString(1, selectedPreparat);
		        ResultSet rs = stmt.executeQuery();
		        if (rs.next()) {
		            return rs.getString("IDPreparat");
		        }
		        
		        return null;
		    }
		});

		
	
		btnNewButton6.setForeground(Color.DARK_GRAY);
		btnNewButton6.setFont(new Font("Eras Bold ITC", Font.ITALIC, 14));
		btnNewButton6.setBackground(Color.LIGHT_GRAY);
		btnNewButton6.setBounds(71, 602, 167, 76);
		frame.getContentPane().add(btnNewButton6);
		
		JButton btnNewButton7 = new JButton("STERGE");
		btnNewButton7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					String idmasa = textField4.getText();
			        String selectedPreparat = (String) comboBox.getSelectedItem();
			        
					try (Connection conn2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "Gabriel01")) {
					    PreparedStatement stmt = conn2.prepareStatement("DELETE FROM hotel.restaurant WHERE IDMasa = ? AND IDPreparat = ?");
					    stmt.setString(1, idmasa);
					    stmt.setString(2, getSelectedID(selectedPreparat, conn2));
					    int affectedRows = stmt.executeUpdate();
					    if (affectedRows == 0) {
					        JOptionPane.showMessageDialog(null, "Nu exista acest preparat la masa!");
					    } else {
					        JOptionPane.showMessageDialog(null, "Preparatul a fost sters de la masa cu succes!");
					    }
					} catch (SQLException ex) {
					    ex.printStackTrace();
					}

			    }
		
					private String getSelectedID(String selectedPreparat, Connection conn) throws SQLException {
					PreparedStatement stmt = conn.prepareStatement("SELECT IDPreparat FROM hotel.preparate WHERE descriere = ?");
				    stmt.setString(1, selectedPreparat);
				    ResultSet rs = stmt.executeQuery();
				    if (rs.next()) {
				        return rs.getString("IDPreparat");
				    }
					
					return null;
				}
	});
		
		btnNewButton7.setForeground(Color.DARK_GRAY);
		btnNewButton7.setFont(new Font("Eras Bold ITC", Font.ITALIC, 14));
		btnNewButton7.setBackground(Color.LIGHT_GRAY);
		btnNewButton7.setBounds(265, 602, 167, 76);
		frame.getContentPane().add(btnNewButton7);
		
		JButton btnNewButton8 = new JButton("UPDATE");
		btnNewButton8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "Gabriel01")) {

				        	String idmasa = textField4.getText();
					        String selectedPreparat = (String) comboBox.getSelectedItem();
					        int cantitate = (int) spinner.getValue();
					        LocalDateTime now = LocalDateTime.now();
				            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
				            String formattedDateTime = now.format(formatter);

				           
				            String preparatID = getSelectedPreparatID(selectedPreparat, conn);

				            
				            PreparedStatement stmt = conn.prepareStatement("UPDATE hotel.restaurant SET datapreparat = ?, cantitate = ? WHERE IDMasa = ? AND IDPreparat = ?");
				            stmt.setString(1, formattedDateTime);
				            stmt.setInt(2, cantitate);
				            stmt.setString(3, idmasa);
				            stmt.setString(4, preparatID);
				            int rowsAffected = stmt.executeUpdate();

				            if (rowsAffected > 0) {
				                JOptionPane.showMessageDialog(frame, "Modificare cu succes !");
				            } else {
				                JOptionPane.showMessageDialog(frame, "Nu s-a gasit nimic pentru aceasta masa si preparat !");
				            }

				        } catch (SQLException ex) {
				            ex.printStackTrace();
				        }
				    }
			
						private String getSelectedPreparatID(String selectedPreparat, Connection conn) throws SQLException {
						PreparedStatement stmt = conn.prepareStatement("SELECT IDPreparat FROM hotel.preparate WHERE descriere = ?");
					    stmt.setString(1, selectedPreparat);
					    ResultSet rs = stmt.executeQuery();
					    if (rs.next()) {
					        return rs.getString("IDPreparat");
					    }
						
						return null;
					}
		});

		btnNewButton8.setForeground(Color.DARK_GRAY);
		btnNewButton8.setFont(new Font("Eras Bold ITC", Font.ITALIC, 14));
		btnNewButton8.setBackground(Color.LIGHT_GRAY);
		btnNewButton8.setBounds(175, 701, 167, 76);
		frame.getContentPane().add(btnNewButton8);
		
		JLabel lblNewLabel_2_2 = new JLabel("Selecteaza categoria :");
		lblNewLabel_2_2.setForeground(Color.DARK_GRAY);
		lblNewLabel_2_2.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_2_2.setBounds(71, 182, 201, 17);
		frame.getContentPane().add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DASHBOARD window = new DASHBOARD();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		lblNewLabel_6.setIcon(new ImageIcon(RESTAURANT.class.getResource("/images/icons8-home-page-48.png")));
		lblNewLabel_6.setBounds(1478, 11, 46, 46);
		frame.getContentPane().add(lblNewLabel_6);
		
		JButton btnNewButton = new JButton("Preparate ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PREPARATE window = new PREPARATE();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		btnNewButton.setForeground(Color.DARK_GRAY);
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 14));
		btnNewButton.setBounds(1399, 812, 125, 38);
		frame.getContentPane().add(btnNewButton);
		
		
		
		
		
	}


}

