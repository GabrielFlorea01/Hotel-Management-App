import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.NumberFormatter;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JRadioButton;
import javax.swing.JCheckBox;

public class SPA {

	JFrame frame;
	private JTextField textField;
	private JTable table;
	private JTextField textField2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SPA window = new SPA();
					window.frame.setResizable(false);
					window.frame.setVisible(true);
					window.frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SPA() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setSize(1550,900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JCheckBox checkBox1 = new JCheckBox("1 - PISCINA");
		checkBox1.setFont(new Font("Century Gothic", Font.ITALIC, 14));
		checkBox1.setBounds(1016, 288, 109, 23);
		frame.getContentPane().add(checkBox1);
		
		JCheckBox checkBox2 = new JCheckBox("2 - SPA");
		checkBox2.setFont(new Font("Century Gothic", Font.ITALIC, 14));
		checkBox2.setBounds(1172, 288, 89, 23);
		frame.getContentPane().add(checkBox2);
		
		JCheckBox checkBox3 = new JCheckBox("3 - SPA & PISCINA");
		checkBox3.setFont(new Font("Century Gothic", Font.ITALIC, 14));
		checkBox3.setBounds(1298, 288, 143, 23);
		frame.getContentPane().add(checkBox3);
		
		checkBox1.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		       if (checkBox1.isSelected()) {
	
					checkBox2.setEnabled(false);
			        checkBox3.setEnabled(false);
			       
			        
		      }else {
		    	   checkBox2.setEnabled(true);
			       checkBox3.setEnabled(true);
		      		}
		    }
		});
		

		
		checkBox2.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		       if (checkBox2.isSelected()) {
		    	   
		        checkBox1.setEnabled(false);
		        checkBox3.setEnabled(false);
		       
		      }else {
		    	  
		    	   checkBox1.setEnabled(true);
			       checkBox3.setEnabled(true);
			  		}
		    }
		});
		

		
		checkBox3.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		       if (checkBox3.isSelected()) {
		        checkBox1.setEnabled(false);
		        checkBox2.setEnabled(false);
		        
		      }else {
		    	   checkBox1.setEnabled(true);
			       checkBox2.setEnabled(true);
			       
			   }
		    }
		});
		
		JLabel lblNewLabel = new JLabel("SERVICII DE SPA/PISICNA");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel.setIcon(new ImageIcon(SPA.class.getResource("/images/icons8-spa-care-64.png")));
		lblNewLabel.setBounds(10, 11, 251, 57);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Cauta dupa numarul camerei");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setBounds(499, 55, 227, 20);
		frame.getContentPane().add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setFont(new Font("SansSerif", Font.BOLD, 15));
		textField.setBounds(736, 54, 89, 22);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("CAUTA");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				String textFieldid = textField.getText();
				
				if (textFieldid.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Completeaza numarul camerei (de la 1 la 30 ) !","Eroare !", JOptionPane.ERROR_MESSAGE);

				} else if (!textFieldid.matches("\\d+")) {
					JOptionPane.showMessageDialog(null, "Te rog intorodu un numar valabil !", "Eroare !", JOptionPane.ERROR_MESSAGE);

				} else {
				
				try 
				(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
				PreparedStatement stmt = conn.prepareStatement("SELECT rezervare.IDRezervare, client.numeClient, rezervare.IDCamera, rezervare.IDSpa, spa.descriere, rezervare.numarPers FROM rezervare "
						+ "JOIN client ON client.IDClient=rezervare.IDClient "
						+ "JOIN spa ON spa.IDSpa=rezervare.IDSpa "
						+ "WHERE IDCamera= ?");)
				{
					stmt.setInt(1, Integer.parseInt(textField.getText()));
					ResultSet rs =stmt.executeQuery();
					DefaultTableModel tm = (DefaultTableModel)table.getModel();
					tm.setRowCount(0);
					
					 if (!rs.next()) {
		                    JOptionPane.showMessageDialog(null, "Nu s-a gasit camera !");
		                    return;
		                }
					 
					 do { Object o[]= {rs.getInt("IDRezervare"),rs.getString("numeClient"),rs.getString("IDCamera"),rs.getString("IDSpa"),rs.getString("descriere"),rs.getString("numarPers")};
						    tm.addRow(o);
						
					} while (rs.next());
					 
				}catch (SQLException e1) {
					e1.printStackTrace();
				}
				
			}
	}});
		
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.setForeground(Color.DARK_GRAY);
		btnNewButton.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 14));
		btnNewButton.setBounds(855, 55, 89, 21);
		frame.getContentPane().add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(67, 249, 738, 333);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Century Gothic", Font.ITALIC, 14));
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID Rezervare", "Nume client", "Numar camera", "ID Spa", "Serviciu de tip", "Numar de persoane"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(84);
		table.getColumnModel().getColumn(2).setPreferredWidth(93);
		table.getColumnModel().getColumn(3).setPreferredWidth(83);
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SPA spaWindow = new SPA();
				spaWindow.frame.setVisible(true);
				spaWindow.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		btnNewButton_2.setBackground(Color.LIGHT_GRAY);
		btnNewButton_2.setIcon(new ImageIcon(SPA.class.getResource("/images/icons8-update-left-rotation-24.png")));
		btnNewButton_2.setBounds(1490, 823, 34, 27);
		frame.getContentPane().add(btnNewButton_2);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBackground(Color.WHITE);
		comboBox.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 14));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Piscina", "Spa", "Spa&Piscina", "Nimic"}));
		comboBox.setBounds(363, 631, 115, 27);
		frame.getContentPane().add(comboBox);
		
		JButton btnNewButton4 = new JButton("UPDATE SPA");
		btnNewButton4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton4.setForeground(Color.green);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton4.setForeground(Color.darkGray);
			}
		});
		
		btnNewButton4.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	
		        int selectedRow = table.getSelectedRow();
		        
		        if (selectedRow == -1) {
		            JOptionPane.showMessageDialog(null, "Selecteaza o rezervare!", "Eroare!", JOptionPane.ERROR_MESSAGE);
		            return;
		        }

		        String descriereSpa = comboBox.getSelectedItem().toString();
		        int IDRezervare = (int) table.getValueAt(selectedRow, 0);

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "Gabriel01")) {
		           
		            try (PreparedStatement stmt = conn.prepareStatement("UPDATE rezervare SET IDSpa = ? WHERE IDRezervare = ?")) {
		                int idSpa = 0;

		                // se extrage ID-ul dupa descriere
		                
		                PreparedStatement stmtSpa = conn.prepareStatement("SELECT IDSpa FROM spa WHERE descriere = ?");
		                stmtSpa.setString(1, descriereSpa);
		                ResultSet rsSpa = stmtSpa.executeQuery();
		                if (rsSpa.next()) {
		                    idSpa = rsSpa.getInt("IDSpa");
		                }

		                stmt.setInt(1, idSpa);
		                stmt.setInt(2, IDRezervare);
		                stmt.executeUpdate();

		                JOptionPane.showMessageDialog(null, "Actualizare spa cu succes !");

		                SPA window = new SPA();
		                window.frame.setResizable(false);
		                window.frame.setVisible(true);
		                window.frame.setLocationRelativeTo(null);
		                frame.dispose();
		            }
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Eroare la actualizarea spa-ului !");
		        }
		    }
		});


		
		btnNewButton4.setForeground(Color.DARK_GRAY);
		btnNewButton4.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 14));
		btnNewButton4.setBackground(Color.LIGHT_GRAY);
		btnNewButton4.setBounds(346, 718, 132, 41);
		frame.getContentPane().add(btnNewButton4);
		
		JButton btnNewButton5 = new JButton("Arata rezervarile cu servicii");
		btnNewButton5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
						PreparedStatement stmt = conn.prepareStatement("SELECT rezervare.IDRezervare, client.numeClient, rezervare.IDCamera, rezervare.IDSpa, spa.descriere, rezervare.numarPers from rezervare  "
								+ "JOIN client ON rezervare.IDClient=client.IDClient "
								+ "JOIN spa ON spa.IDSpa=rezervare.IDSpa");)
						{
						ResultSet rs = stmt.executeQuery();
						DefaultTableModel tm = (DefaultTableModel)table.getModel();
						tm.setRowCount(0);
						
						while(rs.next()) {
							Object o[]= {rs.getInt("IDRezervare"),rs.getString("numeClient"),rs.getString("IDCamera"),rs.getString("IDSpa"),rs.getString("descriere"),rs.getString("numarPers")};
						    tm.addRow(o);
						}
						
						
						
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
				
			}
		});
		btnNewButton5.setForeground(Color.DARK_GRAY);
		btnNewButton5.setFont(new Font("SansSerif", Font.BOLD, 15));
		btnNewButton5.setBackground(Color.LIGHT_GRAY);
		btnNewButton5.setBounds(67, 206, 251, 20);
		frame.getContentPane().add(btnNewButton5);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DASHBOARD window = new DASHBOARD();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
			}
		});
		lblNewLabel_2.setIcon(new ImageIcon(SPA.class.getResource("/images/icons8-home-page-48.png")));
		lblNewLabel_2.setBounds(1478, 11, 46, 41);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_1_1 = new JLabel("Selecteaza serviciul:");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1_1.setBounds(1093, 226, 227, 20);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Introdu pretul:");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_1.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1_1_1.setBounds(997, 357, 170, 20);
		frame.getContentPane().add(lblNewLabel_1_1_1);
		
		textField2 = new JTextField();
		textField2.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 16));
		textField2.setBounds(1151, 356, 170, 27);
		frame.getContentPane().add(textField2);
		textField2.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Modifica pretul");
		btnNewButton_1.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	
		        int spaSelectat = 0;

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "Gabriel01")) {
		            int idSpa1 = 0;
		            int idSpa2 = 0;
		            int idSpa3 = 0;

		            PreparedStatement stmtPiscina = conn.prepareStatement("SELECT IDSpa FROM spa WHERE descriere = 'Piscina'");
		            ResultSet rsPiscina = stmtPiscina.executeQuery();
		            if (rsPiscina.next()) {
		                idSpa1 = rsPiscina.getInt("IDSpa");
		            }

		            PreparedStatement stmtSpa = conn.prepareStatement("SELECT IDSpa FROM spa WHERE descriere = 'Spa'");
		            ResultSet rsSpa = stmtSpa.executeQuery();
		            if (rsSpa.next()) {
		                idSpa2 = rsSpa.getInt("IDSpa");
		            }

		            PreparedStatement stmtSpaPiscina = conn.prepareStatement("SELECT IDSpa FROM spa WHERE descriere = 'Spa&Piscina'");
		            ResultSet rsSpaPiscina = stmtSpaPiscina.executeQuery();
		            if (rsSpaPiscina.next()) {
		                idSpa3 = rsSpaPiscina.getInt("IDSpa");
		            }

		            if (checkBox1.isSelected()) {
		                spaSelectat = idSpa1;
		            } else if (checkBox2.isSelected()) {
		                spaSelectat = idSpa2;
		            } else if (checkBox3.isSelected()) {
		                spaSelectat = idSpa3;
		            }

		            String pret = textField2.getText();
		            if (pret.isEmpty()) {
		                JOptionPane.showMessageDialog(null, "Introduceti un pret valid!", "Eroare!", JOptionPane.ERROR_MESSAGE);
		                return;
		            }

		            float pretSpa = Float.parseFloat(pret);

		            PreparedStatement stmtUpdatePret = conn.prepareStatement("UPDATE spa SET pretSpa = ? WHERE IDSpa = ?");
		            stmtUpdatePret.setFloat(1, pretSpa);
		            stmtUpdatePret.setInt(2, spaSelectat);
		            stmtUpdatePret.executeUpdate();

		            JOptionPane.showMessageDialog(null, "Actualizare pret spa cu succes !");
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Eroare la actualizarea pretului spa-ului !");
		        }
		    }
		});

		
		btnNewButton_1.setForeground(Color.DARK_GRAY);
		btnNewButton_1.setBackground(Color.LIGHT_GRAY);
		btnNewButton_1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_1.setBounds(1151, 422, 143, 27);
		frame.getContentPane().add(btnNewButton_1);
		
		
		
		
	}
}
