import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.UIManager;

import java.awt.Button;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import javax.swing.JCheckBox;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LOGIN {

	JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;
	private static final String ADMIN_EMAIL = "admin@admin";
	
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LOGIN window = new LOGIN();
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LOGIN() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
        frame.setBounds(100, 100, 1550, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(255, 255, 255));
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 1524, 900);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Email");
		lblNewLabel.setForeground(Color.DARK_GRAY);
		lblNewLabel.setFont(new Font("Leelawadee UI", Font.BOLD, 16));
		lblNewLabel.setBounds(553, 284, 61, 27);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Parola");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("Leelawadee UI", Font.BOLD, 16));
		lblNewLabel_1.setBounds(547, 342, 67, 27);
		panel.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setFont(new Font("SansSerif", Font.PLAIN, 15));
		textField.setBackground(new Color(255, 255, 255));
		textField.setForeground(new Color(0, 0, 0));
		textField.setBounds(624, 286, 303, 24);
		panel.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("SansSerif", Font.PLAIN, 15));
		passwordField.setBackground(new Color(255, 255, 255));
		passwordField.setBounds(624, 344, 303, 24);
		panel.add(passwordField);
		
	
		Button button_2 = new Button("FORGOT PASSWORD ?");
		button_2.setForeground(Color.WHITE);
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  FORGOT_PASSWORD fgtpWindow = new FORGOT_PASSWORD();
					fgtpWindow.frame.setVisible(true);
					fgtpWindow.frame.setLocationRelativeTo(null);
				    frame.dispose();
			
			}
		});
		button_2.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		button_2.setBackground(Color.LIGHT_GRAY);
		button_2.setBounds(685, 645, 191, 32);
		panel.add(button_2);
		
		Button button_3 = new Button("SIGNUP");
		button_3.setForeground(Color.WHITE);
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  SIGNUP signupWindow = new SIGNUP();
					signupWindow.frame.setVisible(true);
					signupWindow.frame.setLocationRelativeTo(null);
				    frame.dispose();
			
			}
		});
		button_3.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		button_3.setBackground(Color.LIGHT_GRAY);
		button_3.setBounds(714, 564, 129, 27);
		panel.add(button_3);
		
		Button button_1 = new Button("LOGIN");
		button_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		button_1.setForeground(Color.WHITE);
		button_1.setBackground(Color.LIGHT_GRAY);
		button_1.setBounds(714, 435, 129, 32);
		panel.add(button_1);
		
		JLabel lblNewLabel_3 = new JLabel("HOTEL LABIRINT ");
		lblNewLabel_3.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 28));
		lblNewLabel_3.setForeground(Color.DARK_GRAY);
		lblNewLabel_3.setBounds(652, 80, 250, 32);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
		    boolean passwordVisible = false;

		    @Override
		    public void mouseClicked(MouseEvent e) {
		        passwordVisible = !passwordVisible;
		        updatePasswordVisibility();
		    }

		    private void updatePasswordVisibility() {
		        if (passwordVisible) {
		            passwordField.setEchoChar((char) 0); 
		            lblNewLabel_2.setIcon(new ImageIcon(SIGNUP.class.getResource("/images/icons8-hide-24.png")));
		        } else {
		            passwordField.setEchoChar('*'); 
		            lblNewLabel_2.setIcon(new ImageIcon(SIGNUP.class.getResource("/images/icons8-eye-24.png")));
		        }
		    }
		});
		lblNewLabel_2.setIcon(new ImageIcon(LOGIN.class.getResource("/images/icons8-eye-24.png")));
		lblNewLabel_2.setBounds(937, 347, 36, 18);
		panel.add(lblNewLabel_2);
		
		
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        
				String email=textField.getText();
				String parola= String.valueOf(passwordField.getPassword());
				boolean isAdmin= false;
				String emailadmin = "admin@admin";
				String passwordadmin = "admin";
				
				
				if (email.equals("")|| parola.equals("")) {
					JOptionPane.showMessageDialog(null, "Completeaza fiecare camp!","Eroare!",2);
					
				}
				
				try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root",
						"Gabriel01");)
						
						{
						
						PreparedStatement stmt = conn.prepareStatement("SELECT * FROM utilizator WHERE emailUtil= ? AND aprobat= 'DA' ");
						stmt.setString(1, email);
						ResultSet rs = stmt.executeQuery();

								if (rs.next()) {
									
									email= rs.getString("emailUtil");
								    String paroladb = rs.getString("parolaUtil");
								    String numedb = rs.getString("numeUtil");
								    
								    if (parola.equals(passwordadmin) && email.equals(emailadmin))
								       {
								    		isAdmin=true;
								    		
								    	}else {	
								    		
								    	DASHBOARD window = new DASHBOARD();
				    					window.frame.setVisible(true);
				    					window.frame.setResizable(false);
				    					window.frame.setLocationRelativeTo(null);
				    					frame.dispose();
				    					
				    					Font font = new Font(Font.SANS_SERIF, Font.BOLD, 20);
				    					UIManager.put("OptionPane.messageFont", font);
				    					JOptionPane.showMessageDialog(null, "Bine ai venit, " + numedb + " !" );
				    					
				    					
								    	}
								    
								}else {JOptionPane.showMessageDialog(null, "Nu s-a gasit user sau user neaprobat!","Eroare!",2);}
		
								}catch (Exception e2) {
									 e2.printStackTrace();
								}
										
					                    
					                    if (isAdmin) {
					                    	ADMIN_PAGE window = new ADMIN_PAGE();
					    					window.frame.setVisible(true);
					    					window.frame.setResizable(false);
					    					window.frame.setLocationRelativeTo(null);
					    					frame.dispose();
					    					
					    					Font font = new Font(Font.SANS_SERIF, Font.BOLD, 20);
					    					UIManager.put("OptionPane.messageFont", font);
					    					JOptionPane.showMessageDialog(null, "Bine ai venit, ADMIN !" );
					    					
					                    } 
											
										
			
									
			
			}

			});
	
		}
	}
	
								
				



