
import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JToolBar;
import javax.swing.SpinnerDateModel;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.awt.event.ActionEvent;
import javax.swing.JFormattedTextField;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ContainerAdapter;
import java.awt.event.ContainerEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;
import javax.swing.JPanel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import javax.swing.JCheckBox;

public class REZERVARE_NOUA {

	JFrame frame;
	private JTextField textField1;
	private JTextField textField2;
	private JTextField textField3;
	private JTextField textField4;
	private JTextField textField8;
	private JTextField textField5;
	private JTextField textField9;
	private String idSpa;
	
	
	
	
	
	JRadioButton radioButton1;
	JRadioButton radioButton2;
	JRadioButton radioButton3;
	JRadioButton radioButton10;
	
	
	
	

	

	private String INSERTinrezervare = "INSERT INTO hotel.rezervare (IDClient, IDCamera, "
			+ "IDSpa, checkIN, checkOUT, numarPers, statusRezerv) VALUES (?, ?, ?, ?, ?, ?, ?)";


	
	
	
	
	
	
	
	private JTextField textField10;
	private JTextField textField6;
	private JTextField textField7;
	private JTextField textField11;
	private JTextField textField12;
	private JTextField textField13;
	private JTextField textField14;
	private JTextField textField15;
	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					REZERVARE_NOUA window = new REZERVARE_NOUA();
					window.frame.setSize(1550,900);
					window.frame.setVisible(true);
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

	}

	/**
	 * Create the application.
	 */
	public REZERVARE_NOUA() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.getContentPane().setForeground(new Color(0, 0, 0));
		frame.getContentPane().setBounds(100,100,1550,900);
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.getContentPane().setLayout(null);
		
	
		
		SpinnerDateModel spinnerModel = new SpinnerDateModel();
		JSpinner spinner = new JSpinner(spinnerModel);
		spinner.setForeground(new Color(255, 255, 255));
		spinner.setBounds(547, 93, 126, 38);
		spinner.setFont(new Font("Century Gothic", Font.BOLD, 16));
		JSpinner.DateEditor editor = new JSpinner.DateEditor(spinner, "dd/MM/yyyy");
		spinner.setEditor(editor);
		frame.getContentPane().add(spinner);
		
		SpinnerDateModel spinnerModel1 = new SpinnerDateModel();
		JSpinner spinner1 = new JSpinner(spinnerModel1);
		spinner1.setForeground(new Color(255, 255, 255));
		spinner1.setBounds(935, 93, 115, 38);
		spinner1.setFont(new Font("Century Gothic", Font.BOLD, 16));
		JSpinner.DateEditor editor1 = new JSpinner.DateEditor(spinner1, "dd/MM/yyyy");
		spinner1.setEditor(editor1);
		frame.getContentPane().add(spinner1);
		
		
		

		// se seteaza data de check-in pentru astazi
		
		Calendar azi = Calendar.getInstance();
		azi.add(Calendar.DAY_OF_MONTH, -1);
		Date minDate = azi.getTime();
		spinnerModel.setStart(minDate);
		
		// Se seteaza o zi distanta pt check-out(politica)
		
		Calendar maine = Calendar.getInstance();
		maine.add(Calendar.DAY_OF_MONTH, 1); 
		Date maxDate = maine.getTime();
		spinnerModel1.setValue(maxDate);
		

		
		textField10 = new JTextField();
		textField10.setBounds(933, 441, 281, 26);
		textField10.setFont(new Font("SansSerif", Font.PLAIN, 14));
		textField10.setColumns(10);
		frame.getContentPane().add(textField10);
		textField10.addFocusListener(new FocusAdapter() {
		    @Override
		    public void focusLost(FocusEvent e) {
		        JTextField textField = (JTextField) e.getComponent();
		        String cnpString = textField.getText();
		        boolean isValid = cnpString.length() == 13 && "1256".contains(cnpString.substring(0, 1));

		        if (!isValid) {
		            JOptionPane.showMessageDialog(frame, "CNP-ul trebuie sa contina 13 cifre si sa inceapa cu '1', '2', '5' sau '6' !", "Error", JOptionPane.ERROR_MESSAGE);
		            textField.requestFocus();
		        }
		    }
		});
		
		JCheckBox checkBox1 = new JCheckBox("PISCINA");
		checkBox1.setFont(new Font("Century Gothic", Font.ITALIC, 14));
		checkBox1.setBounds(1197, 587, 97, 23);
		frame.getContentPane().add(checkBox1);
		
		JCheckBox checkBox2 = new JCheckBox("SPA");
		checkBox2.setFont(new Font("Century Gothic", Font.ITALIC, 14));
		checkBox2.setBounds(1197, 628, 97, 26);
		frame.getContentPane().add(checkBox2);
		
		JCheckBox checkBox3 = new JCheckBox("SPA + PISCINA");
		checkBox3.setFont(new Font("Century Gothic", Font.ITALIC, 14));
		checkBox3.setBounds(1197, 670, 137, 26);
		frame.getContentPane().add(checkBox3);

		JCheckBox checkBox4 = new JCheckBox("NU");
		checkBox4.setFont(new Font("Century Gothic", Font.ITALIC, 14));
		checkBox4.setBounds(1197, 713, 80, 26);
		frame.getContentPane().add(checkBox4);
		
		JCheckBox checkBox5 = new JCheckBox("Client existent");
		checkBox5.setFont(new Font("Century Gothic", Font.ITALIC, 15));
		checkBox5.setBounds(24, 23, 145, 23);
		frame.getContentPane().add(checkBox5);
		
		
		
		checkBox5.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        if (checkBox5.isSelected()) {
		            String CNP = textField10.getText();
		            int idClient;
		            String numerezervare;
		            String telefon;
		            String email;
		            String adresa_tara;
		            String adresa_oras;
		            String adresa_strada;
		            String adresa_numar;
		            String act_identitate;
		            String act_serie;
		            int act_nr;
		            String cnpClient;
		            String cetatenie;
		            String nr_masina;

		            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "Gabriel01");) {
		                PreparedStatement stmtGetClient = conn.prepareStatement("SELECT * FROM hotel.client where cnpClient = ?");
		                stmtGetClient.setString(1, CNP);
		                ResultSet rs1 = stmtGetClient.executeQuery();
		                if (rs1.next()) {
		                    idClient = rs1.getInt("IDClient");
		                    numerezervare = rs1.getString("numeClient");
		                    adresa_oras = rs1.getString("adresa_oras");
		                    adresa_strada = rs1.getString("adresa_strada");
		                    adresa_numar = rs1.getString("adresa_numar");
		                    adresa_tara = rs1.getString("cetatenieClient");
		                    act_identitate = rs1.getString("act_identitate");
		                    act_serie = rs1.getString("act_serie");
		                    act_nr = rs1.getInt("act_numar");
		                    cnpClient = rs1.getString("cnpClient");
		                    cetatenie = rs1.getString("cetatenieClient");
		                    telefon = rs1.getString("telefonClient");
		                    email = rs1.getString("emailClient");
		                    nr_masina = rs1.getString("numarMasina");

		                    textField1.setText(numerezervare);
		                    textField3.setText(cetatenie);
		                    textField5.setText(telefon);
		                    textField4.setText(email);
		                    textField2.setText(adresa_oras);
		                    textField7.setText(adresa_strada);
		                    textField11.setText(adresa_numar);
		                    textField12.setText(adresa_tara);
		                    textField13.setText(act_identitate);
		                    textField14.setText(act_serie);
		                    textField15.setText(String.valueOf(act_nr));
		                    textField10.setText(cnpClient);
		                    textField6.setText(nr_masina);
		                    
		                } else {
		                    JOptionPane.showMessageDialog(null, "CNP-ul nu a fost gasit! Introdu client nou sau verifica CNP-ul inca o data.", "Eroare!", JOptionPane.ERROR_MESSAGE);
		                    
		                    textField1.setText("");
		                    textField3.setText("");
		                    textField5.setText("");
		                    textField4.setText("");
		                    textField2.setText("");
		                    textField7.setText("");
		                    textField11.setText("");
		                    textField12.setText("");
		                    textField13.setText("");
		                    textField14.setText("");
		                    textField15.setText("");
		                    textField6.setText("");
		                    checkBox5.setSelected(false);
		                }
		            } catch (Exception e2) {
		                e2.printStackTrace();
		            }
		        }
		    }
		});

		
		
		
			checkBox1.addActionListener(new ActionListener() {
			    public void actionPerformed(ActionEvent e) {
			       if (checkBox1.isSelected()) {
			    	   
			    	 
						checkBox2.setEnabled(false);
				        checkBox3.setEnabled(false);
				        checkBox4.setEnabled(false);
				        
			      }else {
			    	   checkBox2.setEnabled(true);
				       checkBox3.setEnabled(true);
				       checkBox4.setEnabled(true);
					
				}
			    }
			});
			

			
			checkBox2.addActionListener(new ActionListener() {
			    public void actionPerformed(ActionEvent e) {
			       if (checkBox2.isSelected()) {
			        checkBox1.setEnabled(false);
			        checkBox3.setEnabled(false);
			        checkBox4.setEnabled(false);
			      }else {
			    	   checkBox1.setEnabled(true);
				       checkBox3.setEnabled(true);
				       checkBox4.setEnabled(true);
				  }
			    }
			});
			

			
			checkBox3.addActionListener(new ActionListener() {
			    public void actionPerformed(ActionEvent e) {
			       if (checkBox3.isSelected()) {
			        checkBox1.setEnabled(false);
			        checkBox2.setEnabled(false);
			        checkBox4.setEnabled(false);
			      }else {
			    	   checkBox1.setEnabled(true);
				       checkBox2.setEnabled(true);
				       checkBox4.setEnabled(true);	
				   }
			    }
			});
			
			
			checkBox4.addActionListener(new ActionListener() {
			    public void actionPerformed(ActionEvent e) {
			       if (checkBox4.isSelected()) {
			        checkBox1.setEnabled(false);
			        checkBox2.setEnabled(false);
			        checkBox3.setEnabled(false);
			      }else {
			    	   checkBox1.setEnabled(true);
				       checkBox2.setEnabled(true);
				       checkBox3.setEnabled(true);
			      }
			    }
			});
			
			
			
		
	
		
		
		

		JLabel lblNewLabel = new JLabel("NUMELE CLIENTULUI :");
		lblNewLabel.setBounds(75, 223, 175, 20);
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
		frame.getContentPane().add(lblNewLabel);
		
		

		JLabel lblNewLabel_1 = new JLabel("CNP :");
		lblNewLabel_1.setBounds(935, 416, 46, 14);
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD, 14));
		frame.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("DOMICILIUL : ORAS");
		lblNewLabel_2.setBounds(74, 324, 145, 14);
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setFont(new Font("SansSerif", Font.BOLD, 14));
		frame.getContentPane().add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("TELEFON :");
		lblNewLabel_3.setBounds(828, 226, 80, 14);
		lblNewLabel_3.setForeground(new Color(0, 0, 0));
		lblNewLabel_3.setFont(new Font("SansSerif", Font.BOLD, 14));
		frame.getContentPane().add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("EMAIL :");
		lblNewLabel_4.setBounds(1173, 226, 62, 14);
		lblNewLabel_4.setForeground(new Color(0, 0, 0));
		lblNewLabel_4.setFont(new Font("SansSerif", Font.BOLD, 14));
		frame.getContentPane().add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("CETATENIA :");
		lblNewLabel_5.setBounds(451, 223, 115, 20);
		lblNewLabel_5.setForeground(new Color(0, 0, 0));
		lblNewLabel_5.setFont(new Font("SansSerif", Font.BOLD, 14));
		frame.getContentPane().add(lblNewLabel_5);

		textField1 = new JTextField();
		textField1.setBounds(75, 254, 281, 26);
		textField1.setFont(new Font("SansSerif", Font.PLAIN, 14));
		frame.getContentPane().add(textField1);
		textField1.setColumns(10);

		textField2 = new JTextField();
		textField2.setBounds(75, 349, 281, 26);
		textField2.setFont(new Font("SansSerif", Font.PLAIN, 14));
		frame.getContentPane().add(textField2);
		textField2.setColumns(10);

		textField3 = new JTextField();
		textField3.setBounds(451, 254, 281, 26);
		textField3.setFont(new Font("SansSerif", Font.PLAIN, 14));
		frame.getContentPane().add(textField3);
		textField3.setColumns(10);

		textField4 = new JTextField();
		textField4.setBounds(1175, 254, 265, 26);
		textField4.setFont(new Font("SansSerif", Font.PLAIN, 14));
		frame.getContentPane().add(textField4);
		textField4.setColumns(10);
		textField4.addFocusListener(new FocusAdapter() {
		    @Override
		    public void focusLost(FocusEvent e) {
		        JTextField textField = (JTextField) e.getComponent();
		        String email = textField.getText();
		        boolean isValid = email.matches(".+@(gmail|yahoo)\\.com");

		        if (!isValid) {
		            JOptionPane.showMessageDialog(frame, "Adresa de email invalida!", "Error", JOptionPane.ERROR_MESSAGE);
		            textField.requestFocus();
		        }
		    }
		});




		JLabel lblNewLabel_6 = new JLabel("CHECK-IN :");
		lblNewLabel_6.setBounds(451, 96, 86, 33);
		lblNewLabel_6.setForeground(new Color(0, 0, 0));
		lblNewLabel_6.setFont(new Font("SansSerif", Font.BOLD, 15));
		frame.getContentPane().add(lblNewLabel_6);

		JLabel lblNewLabel_7 = new JLabel("CHECK-OUT :");
		lblNewLabel_7.setBounds(828, 99, 115, 26);
		lblNewLabel_7.setForeground(new Color(0, 0, 0));
		lblNewLabel_7.setFont(new Font("SansSerif", Font.BOLD, 15));
		frame.getContentPane().add(lblNewLabel_7);

		JLabel lblNewLabel_9 = new JLabel("NUMAR CAMERA :");
		lblNewLabel_9.setBounds(370, 645, 126, 15);
		lblNewLabel_9.setForeground(new Color(0, 0, 0));
		lblNewLabel_9.setFont(new Font("SansSerif", Font.BOLD, 14));
		frame.getContentPane().add(lblNewLabel_9);

		JLabel lblNewLabel_10 = new JLabel("TIP CAMERA :");
		lblNewLabel_10.setBounds(67, 645, 115, 14);
		lblNewLabel_10.setForeground(new Color(0, 0, 0));
		lblNewLabel_10.setFont(new Font("SansSerif", Font.BOLD, 14));
		frame.getContentPane().add(lblNewLabel_10);

		JLabel lblNewLabel_11 = new JLabel("PRET :");
		lblNewLabel_11.setBounds(675, 645, 102, 14);
		lblNewLabel_11.setForeground(new Color(0, 0, 0));
		lblNewLabel_11.setFont(new Font("SansSerif", Font.BOLD, 14));
		frame.getContentPane().add(lblNewLabel_11);

		textField8 = new JTextField();
		textField8.setHorizontalAlignment(SwingConstants.CENTER);
		textField8.setBackground(new Color(255, 255, 255));
		textField8.setBounds(634, 670, 126, 26);
		textField8.setEditable(false);
		textField8.setFont(new Font("SansSerif", Font.PLAIN, 15));
		frame.getContentPane().add(textField8);
		textField8.setColumns(10);

		JComboBox comboBox2 = new JComboBox();
		comboBox2.setBackground(new Color(255, 255, 255));
		comboBox2.setBounds(370, 670, 157, 26);
		
		comboBox2.setFont(new Font("SansSerif", Font.BOLD, 15));
		frame.getContentPane().add(comboBox2);
		frame.setBounds(100, 100, 1556, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		comboBox2.removeAllItems();
		
		textField9 = new JTextField();
		
		textField9.setBounds(416, 541, 175, 26);
		textField9.setFont(new Font("SansSerif", Font.PLAIN, 14));
		textField9.setColumns(10);
		frame.getContentPane().add(textField9);
		
		
		
		
	
		
	

		JComboBox comboBox1 = new JComboBox();
		comboBox1.setBounds(67, 670, 175, 26);
		comboBox1.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				
				String tipcamera = comboBox1.getSelectedItem().toString();
				
			
				try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
						
						PreparedStatement stmt= conn.prepareStatement("SELECT * from hotel.camera WHERE tipCamera=? AND dotari= 'standard' AND statusCamera= 'Libera'"))
				      
				
				{
					
					
					stmt.setString(1, tipcamera);
				    ResultSet rs = stmt.executeQuery();
				    
					Date checkinForm = (Date) spinner.getValue();
					Date checkoutForm = (Date) spinner1.getValue();
					
					PreparedStatement stmtGetAvailableRes = conn.prepareStatement("SELECT * FROM hotel.rezervare "
							+ "WHERE (checkIN >= ? AND checkIN < ?) OR (checkOUT > ? AND checkOUT <= ?)"
		                    + " OR (checkIN <= ? AND checkOUT >= ?);");
					
					stmtGetAvailableRes.setDate(1, new java.sql.Date(checkinForm.getTime()));
					stmtGetAvailableRes.setDate(2, new java.sql.Date(checkoutForm.getTime()));
					stmtGetAvailableRes.setDate(3, new java.sql.Date(checkinForm.getTime()));
					stmtGetAvailableRes.setDate(4, new java.sql.Date(checkoutForm.getTime()));
					stmtGetAvailableRes.setDate(5, new java.sql.Date(checkinForm.getTime()));
					stmtGetAvailableRes.setDate(6, new java.sql.Date(checkoutForm.getTime()));
					ResultSet rsRez = stmtGetAvailableRes.executeQuery();
					
					comboBox2.removeAllItems();
					Set<String> iduri= new HashSet<String>();
					
					while (rsRez.next()) {
						iduri.add(rsRez.getString("IDCamera"));
						
					}
				
					while (rs.next()) {
						
					    String nrcam = rs.getString("IDCamera");
					   
					    if (!iduri.contains(nrcam)) {
					        comboBox2.addItem(nrcam);
					        textField8.setText(rs.getString("pretCamera"));
					    }
					}

					
				
					 
			        if (radioButton1 != null) {
			            frame.getContentPane().remove(radioButton1);
			            
			        }
			        if (radioButton2 != null) {
			            frame.getContentPane().remove(radioButton2);
			            
			            
			        }
			        if (radioButton3 != null) {
			            frame.getContentPane().remove(radioButton3);
			            
			        }
			        
			        if (radioButton10 != null) {
			            frame.getContentPane().remove(radioButton10);
			            
			        }
			      
			        
			        if (tipcamera.equals("")) {
			        	textField8.setText("");
			        }
			        
			        
			        
			        if (tipcamera.equals("Single")) {
			        	
			        	radioButton1 = new JRadioButton("Balcon +(50 RON)");
			    		radioButton1.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 13));
			            radioButton1.setBounds(75, 718, 167, 38);
			            frame.getContentPane().add(radioButton1);
			            
			            radioButton1.addItemListener(new ItemListener() {
				            public void itemStateChanged(ItemEvent e) {
				            	
				                if (radioButton1.isSelected()) {
				                	
				                	String tipcamera= comboBox1.getSelectedItem().toString();
				                    
				                    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
				                    		
				                         PreparedStatement stmtbalconsingle = conn.prepareStatement("SELECT * FROM camera WHERE tipCamera = ? AND dotari = 'balcon'"))
				                    {
				                    	stmtbalconsingle.setString(1, tipcamera);
				                        ResultSet rsbalconsingle = stmtbalconsingle.executeQuery();

				                        Date checkinForm = (Date) spinner.getValue();
				    					Date checkoutForm = (Date) spinner1.getValue();
				    					
				    					PreparedStatement stmtGetAvailableRes = conn.prepareStatement("SELECT * FROM hotel.rezervare "
				    							+ "WHERE (checkIN >= ? AND checkIN < ?) OR (checkOUT > ? AND checkOUT <= ?)"
				    		                    + " OR (checkIN <= ? AND checkOUT >= ?);");
				    					
				    					stmtGetAvailableRes.setDate(1, new java.sql.Date(checkinForm.getTime()));
				    					stmtGetAvailableRes.setDate(2, new java.sql.Date(checkoutForm.getTime()));
				    					stmtGetAvailableRes.setDate(3, new java.sql.Date(checkinForm.getTime()));
				    					stmtGetAvailableRes.setDate(4, new java.sql.Date(checkoutForm.getTime()));
				    					stmtGetAvailableRes.setDate(5, new java.sql.Date(checkinForm.getTime()));
				    					stmtGetAvailableRes.setDate(6, new java.sql.Date(checkoutForm.getTime()));
				    					
				    					ResultSet rsRezsinglebalcon = stmtGetAvailableRes.executeQuery();
				    					comboBox2.removeAllItems();
				    					Set<String> idurisiniglebalcon = new HashSet<String>();
				    					
				    					while (rsRezsinglebalcon.next()) {
				    						idurisiniglebalcon.add(rsRezsinglebalcon.getString("IDCamera"));
				    						
				    					}
				    				
				    					while (rsbalconsingle.next()) {
				    						
				    					    String nrcam = rsbalconsingle.getString("IDCamera");
				    					   
				    					    if (!idurisiniglebalcon.contains(nrcam)) {
				    					        comboBox2.addItem(nrcam);
				    					        textField8.setText(rsbalconsingle.getString("pretCamera"));
				    					    }
				    					}
				                    } catch (SQLException ex) {
				                        ex.printStackTrace();
				                    }
				                }else {
				                	
				                	comboBox2.removeAllItems();
				                	textField8.setText("");
				                	radioButton1.hide();
									
								}
				            }
				        });
			            
			        } 
			        
			        
			        
			        if (tipcamera.equals("Dubla")) {
			        	
			        	
			        	
			        	radioButton2 = new JRadioButton("Balcon (+25 RON)");
			    		radioButton2.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 14));
			            radioButton2.setBounds(75, 720, 167, 38);
			            frame.getContentPane().add(radioButton2);
			            
			           
			    		  radioButton2.addItemListener(new ItemListener() {
					            public void itemStateChanged(ItemEvent e) {
					                if (radioButton2.isSelected()) {
					                	
					               
					                	
					                	String tipcamera= comboBox1.getSelectedItem().toString();
					                    

					                    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
					                         PreparedStatement stmt = conn.prepareStatement("SELECT * from hotel.camera WHERE tipCamera= ? "
					                         		+ "AND dotari= 'balcon'"
					                         		+ "AND statusCamera='Libera'"))
					                    {
					                        stmt.setString(1, tipcamera);
					                        ResultSet rs = stmt.executeQuery();

					                        Date checkinForm = (Date) spinner.getValue();
					    					Date checkoutForm = (Date) spinner1.getValue();
					    					
					    					PreparedStatement stmtGetAvailableRes = conn.prepareStatement("SELECT * FROM hotel.rezervare "
					    							+ "WHERE (checkIN >= ? AND checkIN < ?) OR (checkOUT > ? AND checkOUT <= ?)"
					    		                    + " OR (checkIN <= ? AND checkOUT >= ?);");
					    					
					    					stmtGetAvailableRes.setDate(1, new java.sql.Date(checkinForm.getTime()));
					    					stmtGetAvailableRes.setDate(2, new java.sql.Date(checkoutForm.getTime()));
					    					stmtGetAvailableRes.setDate(3, new java.sql.Date(checkinForm.getTime()));
					    					stmtGetAvailableRes.setDate(4, new java.sql.Date(checkoutForm.getTime()));
					    					stmtGetAvailableRes.setDate(5, new java.sql.Date(checkinForm.getTime()));
					    					stmtGetAvailableRes.setDate(6, new java.sql.Date(checkoutForm.getTime()));
					    					ResultSet rsRez = stmtGetAvailableRes.executeQuery();
					    					
					    					comboBox2.removeAllItems();
					    					Set<String> iduri = new HashSet<String>();
					    					
					    				
					    					
					    					while (rsRez.next()) {
					    						iduri.add(rsRez.getString("IDCamera"));
					    						
					    					}
					    				
					    					while (rs.next()) {
					    						
					    					    String nrcam = rs.getString("IDCamera");
					    					   
					    					    if (!iduri.contains(nrcam)) {
					    					        comboBox2.addItem(nrcam);
					    					        textField8.setText(rs.getString("pretCamera"));
					    					    }
					    					}
					                    } catch (SQLException ex) {
					                        ex.printStackTrace();
					                    }
					                    
					                }else {
					                	
					                	comboBox2.removeAllItems();
					                	textField8.setText("");
					                	radioButton2.hide();
										
									}
				
					            }
					                
					            
					            
					        });

			    	
			            
			        } 
			        
			        
			        if (tipcamera.equals("Suita")) {
			        	
			        	 radioButton3 = new JRadioButton("Doua paturi duble (+50 RON)");
			    		 radioButton3.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 14));
			             radioButton3.setBounds(71, 733, 227, 33);
			             frame.getContentPane().add(radioButton3);
			             radioButton3.addItemListener(new ItemListener() {
				            public void itemStateChanged(ItemEvent e) {
				                if (radioButton3.isSelected()) {
				                	
				                	String tipcamera= comboBox1.getSelectedItem().toString();
				                    

				                    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
				                         PreparedStatement stmt = conn.prepareStatement("SELECT * from hotel.camera WHERE tipCamera= ? AND "
				                         		+ "dotari= '2*patdublu' AND statusCamera= 'Libera' "))
				                    {
				                        stmt.setString(1, tipcamera);
				                        ResultSet rs = stmt.executeQuery();

				                        Date checkinForm = (Date) spinner.getValue();
				    					Date checkoutForm = (Date) spinner1.getValue();
				    					
				    					PreparedStatement stmtGetAvailableRes = conn.prepareStatement("SELECT * FROM hotel.rezervare "
				    							+ "WHERE (checkIN >= ? AND checkIN < ?) OR (checkOUT > ? AND checkOUT <= ?)"
				    		                    + " OR (checkIN <= ? AND checkOUT >= ?);");
				    					
				    					stmtGetAvailableRes.setDate(1, new java.sql.Date(checkinForm.getTime()));
				    					stmtGetAvailableRes.setDate(2, new java.sql.Date(checkoutForm.getTime()));
				    					stmtGetAvailableRes.setDate(3, new java.sql.Date(checkinForm.getTime()));
				    					stmtGetAvailableRes.setDate(4, new java.sql.Date(checkoutForm.getTime()));
				    					stmtGetAvailableRes.setDate(5, new java.sql.Date(checkinForm.getTime()));
				    					stmtGetAvailableRes.setDate(6, new java.sql.Date(checkoutForm.getTime()));
				    					ResultSet rsRez = stmtGetAvailableRes.executeQuery();
				    					
				    					comboBox2.removeAllItems();
				    					Set<String> iduri = new HashSet<String>();
				    					
				    				
				    					
				    					while (rsRez.next()) {
				    						iduri.add(rsRez.getString("IDCamera"));
				    						
				    					}
				    				
				    					while (rs.next()) {
				    						
				    					    String nrcam = rs.getString("IDCamera");
				    					   
				    					    if (!iduri.contains(nrcam)) {
				    					        comboBox2.addItem(nrcam);
				    					        textField8.setText(rs.getString("pretCamera"));
				    					    }
				    					}
				                    } catch (SQLException ex) {
				                        ex.printStackTrace();
				                    }
				                }else {
				                	
				                	comboBox2.removeAllItems();
				                	textField8.setText("");
				                	radioButton3.hide();
								}
				            }
				        });
			        }
			        
		
			        
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}

			}

		
			
			
			});
		
		
		
      //filtrare combobox dupa numarul intordus de persoane
		
		   textField9.addFocusListener(new FocusAdapter() {
		    @Override
		    public void focusLost(FocusEvent e) {
		        String textFieldValue = textField9.getText();
		        if (textFieldValue.equals("1")) {
		            comboBox1.setModel(new DefaultComboBoxModel(new String[] { "", "Single" }));
		            
		            
		        } else if (textFieldValue.equals("2")) {
		            comboBox1.setModel(new DefaultComboBoxModel(new String[] { "", "Dubla" }));
		            
		        } else if (textFieldValue.equals("3") || textFieldValue.equals("4")) {
		        	
		            comboBox1.setModel(new DefaultComboBoxModel(new String[] { "", "Suita" }));
		            
		        } else {
		            comboBox1.setModel(new DefaultComboBoxModel(new String[] { "" }));
		            textField8.setText("");
		        }
		    }
		});
		
		
		
		comboBox1.setModel(new DefaultComboBoxModel(new String[] {"", "Single", "Dubla", "Suita"}));
		comboBox1.setToolTipText("");
		comboBox1.setBackground(new Color(255, 255, 255));
		comboBox1.setFont(new Font("SansSerif", Font.PLAIN, 15));
		frame.getContentPane().add(comboBox1);

		JComboBox comboBox5 = new JComboBox();
		comboBox5.setBackground(new Color(255, 255, 255));
		comboBox5.setBounds(689, 540, 198, 26);
		comboBox5.setFont(new Font("SansSerif", Font.PLAIN, 14));
		comboBox5.setModel(new DefaultComboBoxModel(new String[] {"", "Walk-in", "Rezervare telefon", "E-mail"}));
		frame.getContentPane().add(comboBox5);

		JButton btnNewButton = new JButton("ADAUGA REZERVAREA");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton.setBackground(new Color(210, 210, 210 ));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton.setBackground(new Color(255, 255, 255 ));
			}
		});
		btnNewButton.setBounds(667, 790, 220, 39);
		
		
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String numerezervare = textField1.getText();
				String adresa_oras = textField2.getText();
				String adresa_strada=textField7.getText();
				String adresa_numar= textField11.getText();
				String adresa_tara=textField12.getText();
				String act_identitate=textField13.getText();
				String act_serie= textField14.getText();
				int act_nr = Integer.parseInt(textField15.getText());
				String cnpClient = textField10.getText();
				
				String cetatenie = textField3.getText();
				String telefon = textField5.getText();
				String email = textField4.getText();
				String provenienta = (String) comboBox5.getSelectedItem();
				String numarpersoane = textField9.getText();
				String nr_masina=textField6.getText();
				
			

				String s1 = (String) comboBox1.getSelectedItem();
				String s2 = (String) comboBox2.getSelectedItem();
				String pretcamera = textField8.getText();
				
				int existaClient = 0;
				int idClient = -1;
				int idRezervare= -1;
				int spaSelectat = 0;
				
				
				Date checkin = (Date) spinner.getValue();
				Date checkout = (Date) spinner1.getValue();

				SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
				String formattedCheckin = dateFormatter.format(checkin);
				String formattedCheckout = dateFormatter.format(checkout);

			

				if (numerezervare.equals("") || adresa_oras.equals("") ||adresa_strada.equals("") ||adresa_numar.equals("") || adresa_tara.equals("") || 
						act_identitate.equals("")|| act_serie.equals("") || email.equals("") || textField15.equals("") || cnpClient.equals("")
						|| cetatenie.equals("") || telefon.equals("") || email.equals("") || provenienta.equals("")
						|| numarpersoane.equals("") || s1.equals("") || s2.equals("") || pretcamera.equals(""))
				
				{
					JOptionPane.showMessageDialog(null, "Fiecare camp trebuie completat !");
					
				} else {
					
					try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root",
							"Gabriel01");) {
						
						//se alege spa-ul
						
					    int idSpa1 = 0;
					    int idSpa2 = 0;
					    int idSpa3 = 0;
					    int idSpa4 = 0;
						    
				        PreparedStatement stmtPiscina = conn.prepareStatement("SELECT IDSpa FROM hotel.spa WHERE descriere = 'Piscina'");
				        ResultSet rsPiscina = stmtPiscina.executeQuery();
				        if (rsPiscina.next()) {
				            idSpa1 = rsPiscina.getInt("IDSpa");
				        }
				        
				    
			            PreparedStatement stmtSpa = conn.prepareStatement("SELECT IDSpa FROM hotel.spa WHERE descriere = 'Spa'");
			            ResultSet rsSpa = stmtSpa.executeQuery();
			            if (rsSpa.next()) {
			                idSpa2 = rsSpa.getInt("IDSpa");
			            }

			            PreparedStatement stmtSpaPiscina = conn.prepareStatement("SELECT IDSpa FROM hotel.spa WHERE descriere = 'Spa&Piscina'");
			            ResultSet rsSpaPiscina = stmtSpaPiscina.executeQuery();
			            if (rsSpaPiscina.next()) {
			                idSpa3 = rsSpaPiscina.getInt("IDSpa");
			            }

			            PreparedStatement stmtNu = conn.prepareStatement("SELECT IDSpa FROM hotel.spa WHERE descriere = 'Nimic'");
			            ResultSet rsNu = stmtNu.executeQuery();
			            if (rsNu.next()) {
			                idSpa4 = rsNu.getInt("IDSpa");
			            }
						
						
			            if (checkBox1.isSelected()) {
			                spaSelectat = idSpa1;
			            } else if (checkBox2.isSelected()) {
			                spaSelectat = idSpa2;
			            } else if (checkBox3.isSelected()) {
			                spaSelectat = idSpa3;
			            } else if (checkBox4.isSelected()) {
			                spaSelectat = idSpa4;
			            } else {
			                JOptionPane.showMessageDialog(null, "Selectati optiunea de spa!", "Eroare!", JOptionPane.ERROR_MESSAGE);
			                return;        
			            }
			            
						
					
						
						PreparedStatement stmtGetClient = conn.prepareStatement("SELECT * FROM hotel.client where emailClient= ?");
						stmtGetClient.setString(1, email);
						ResultSet rs1 = stmtGetClient.executeQuery();
						if (rs1.next()) {
							 idClient = rs1.getInt("IDClient");
							 numerezervare=rs1.getString("numeClient");
							 adresa_oras = rs1.getString("adresa_oras");
							 adresa_strada=rs1.getString("adresa_strada");
							 adresa_numar= rs1.getString("adresa_numar");
							 adresa_tara=rs1.getString("cetatenieClient");
							 act_identitate=rs1.getString("act_identitate");
							 act_serie= rs1.getString("act_serie");
							 act_nr = rs1.getInt("act_numar");
							 cnpClient = rs1.getString("cnpClient");
							 cetatenie = rs1.getString("cetatenieClient");
							 telefon = rs1.getString("telefonClient");
							 email = rs1.getString("emailClient");
							 provenienta = rs1.getString("provClient");
							 nr_masina=rs1.getString("numarMasina");
							existaClient = 1;
						}

						if (existaClient == 0) {
							
//							
							
							PreparedStatement stmtInsertClient = conn.prepareStatement("INSERT INTO client (numeClient, telefonClient, emailClient, adresa_tara, adresa_oras, adresa_strada, adresa_numar, act_identitate, act_serie, act_numar, cnpClient, cetatenieClient, provClient, numarMasina) "
								    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

								stmtInsertClient.setString(1, numerezervare);
								stmtInsertClient.setString(2, telefon);
								stmtInsertClient.setString(3, email);
								stmtInsertClient.setString(4, adresa_tara);
								stmtInsertClient.setString(5, adresa_oras);
								stmtInsertClient.setString(6, adresa_strada);
								stmtInsertClient.setString(7, adresa_numar);
								stmtInsertClient.setString(8, act_identitate);
								stmtInsertClient.setString(9, act_serie);
								stmtInsertClient.setInt(10, act_nr);
								stmtInsertClient.setString(11, cnpClient);
								stmtInsertClient.setString(12, cetatenie);
								stmtInsertClient.setString(13, provenienta);
								stmtInsertClient.setString(14, nr_masina);

								stmtInsertClient.executeUpdate();

							
							
							
							
						}

						stmtGetClient.setString(1, email);
						rs1 = stmtGetClient.executeQuery();

						if (rs1.next()) {
							idClient = rs1.getInt("IDClient");
						}
						
						if (checkout.before(checkin)) {
						    JOptionPane.showMessageDialog(null, "Selecteaza data de check-out mai mare ca cea de check-in", "Eroare!", JOptionPane.ERROR_MESSAGE);
						    return; 
						}
		
//						private String INSERTinrezervare = "INSERT INTO hotel.rezervare (IDClient, IDCamera, "
//								+ "IDSpa, checkIN, checkOUT, numarPers, statusRezerv) VALUES (?, ?, ?, ?, ?, ?, ?)";

						PreparedStatement stmtInsertRezervare = conn.prepareStatement(INSERTinrezervare, Statement.RETURN_GENERATED_KEYS);
						stmtInsertRezervare.setInt(1, idClient);
						stmtInsertRezervare.setInt(2, Integer.parseInt(s2));
						stmtInsertRezervare.setInt(3, spaSelectat);
						stmtInsertRezervare.setDate(4, new java.sql.Date(checkin.getTime()));
						stmtInsertRezervare.setDate(5, new java.sql.Date(checkout.getTime()));
						stmtInsertRezervare.setInt(6, Integer.parseInt(numarpersoane));
						stmtInsertRezervare.setString(7, "INREGISTRATA");
						stmtInsertRezervare.executeUpdate();

						ResultSet rs = stmtInsertRezervare.getGeneratedKeys();
						if (rs.next()) {
						    idRezervare = rs.getInt(1);
						}

					
						PreparedStatement stmtInsertFacturi= conn.prepareStatement("INSERT INTO hotel.facturi (IDRezervare, IDCamera, IDClient, dataFactura, TotalfaraTVA, TotalcuTVA) "
								+ "values (?, ?, ?, null, null, null)");
						
						stmtInsertFacturi.setInt(1, idRezervare);
						stmtInsertFacturi.setInt(2, Integer.parseInt(s2));
						stmtInsertFacturi.setInt(3, idClient);
						stmtInsertFacturi.executeUpdate();
						
					
						Font font = new Font(Font.SANS_SERIF, Font.BOLD, 18);
    					UIManager.put("OptionPane.messageFont", font);
						JOptionPane.showMessageDialog(null, "Rezervare adaugata !");
						
						REZERVARE_NOUA window = new REZERVARE_NOUA();
						window.frame.setVisible(true);
						window.frame.setResizable(false);
						window.frame.setLocationRelativeTo(null);
						frame.dispose();
						

						} catch (Exception e2) {
							
						e2.printStackTrace();
						
					}
				}

			
			}});
		

		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 16));
		frame.getContentPane().add(btnNewButton);

		JLabel lblNewLabel_12 = new JLabel("PROVENIENTA :");
		lblNewLabel_12.setBounds(692, 514, 115, 15);
		lblNewLabel_12.setForeground(new Color(0, 0, 0));
		lblNewLabel_12.setFont(new Font("SansSerif", Font.BOLD, 14));
		frame.getContentPane().add(lblNewLabel_12);

		textField5 = new JTextField();
		textField5.setBounds(828, 254, 281, 26);
		textField5.setFont(new Font("SansSerif", Font.PLAIN, 14));
		frame.getContentPane().add(textField5);
		textField5.setColumns(10);
		textField5.addFocusListener(new FocusAdapter() {
		    @Override
		    public void focusLost(FocusEvent e) {
		        String numberString = textField5.getText();
		        if (!numberString.matches("[0-9]+")) {
		            JOptionPane.showMessageDialog(frame, "Acest camp trebuie sa contina doar cifre!", "Eroare", JOptionPane.ERROR_MESSAGE);
		        }
		    }
		});


		JLabel lblNewLabel13 = new JLabel("NR. PERSOANE :");
		lblNewLabel13.setBounds(416, 514, 145, 15);
		lblNewLabel13.setForeground(new Color(0, 0, 0));
		lblNewLabel13.setFont(new Font("SansSerif", Font.BOLD, 14));
		frame.getContentPane().add(lblNewLabel13);

		
	
	
		
		JLabel lblNumarMasinadaca = new JLabel("NUMAR MASINA (daca exista)");
		lblNumarMasinadaca.setBounds(75, 513, 220, 20);
		lblNumarMasinadaca.setForeground(Color.BLACK);
		lblNumarMasinadaca.setFont(new Font("SansSerif", Font.BOLD, 14));
		frame.getContentPane().add(lblNumarMasinadaca);
		
		textField6 = new JTextField();
		textField6.setBounds(75, 548, 191, 26);
		textField6.setFont(new Font("SansSerif", Font.PLAIN, 14));
		textField6.setColumns(10);
		frame.getContentPane().add(textField6);
		
		textField7 = new JTextField();
		textField7.setFont(new Font("SansSerif", Font.PLAIN, 14));
		textField7.setColumns(10);
		textField7.setBounds(451, 349, 281, 26);
		frame.getContentPane().add(textField7);
		
		JLabel lblNewLabel_2_1 = new JLabel("STRADA :");
		lblNewLabel_2_1.setForeground(Color.BLACK);
		lblNewLabel_2_1.setFont(new Font("SansSerif", Font.BOLD, 14));
		lblNewLabel_2_1.setBounds(451, 324, 145, 14);
		frame.getContentPane().add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("NR :");
		lblNewLabel_2_1_1.setForeground(Color.BLACK);
		lblNewLabel_2_1_1.setFont(new Font("SansSerif", Font.BOLD, 14));
		lblNewLabel_2_1_1.setBounds(828, 324, 145, 14);
		frame.getContentPane().add(lblNewLabel_2_1_1);
		
		textField11 = new JTextField();
		textField11.setFont(new Font("SansSerif", Font.PLAIN, 14));
		textField11.setColumns(10);
		textField11.setBounds(828, 349, 145, 26);
		frame.getContentPane().add(textField11);
		
		JLabel lblNewLabel_2_1_1_1 = new JLabel("TARA :");
		lblNewLabel_2_1_1_1.setForeground(Color.BLACK);
		lblNewLabel_2_1_1_1.setFont(new Font("SansSerif", Font.BOLD, 14));
		lblNewLabel_2_1_1_1.setBounds(1068, 324, 145, 14);
		frame.getContentPane().add(lblNewLabel_2_1_1_1);
		
		textField12 = new JTextField();
		textField12.setFont(new Font("SansSerif", Font.PLAIN, 14));
		textField12.setColumns(10);
		textField12.setBounds(1068, 349, 265, 26);
		frame.getContentPane().add(textField12);
		
		JLabel lblNewLabel_2_2 = new JLabel("ACT DE INDENTITATE :");
		lblNewLabel_2_2.setForeground(Color.BLACK);
		lblNewLabel_2_2.setFont(new Font("SansSerif", Font.BOLD, 14));
		lblNewLabel_2_2.setBounds(75, 416, 157, 14);
		frame.getContentPane().add(lblNewLabel_2_2);
		
		textField13 = new JTextField();
		textField13.addFocusListener(new FocusAdapter() {
		    @Override
		    public void focusLost(FocusEvent e) {
		        String ActIdentitateString = textField13.getText();
		        String[] allowedValues = { "CI", "BI", "Pasaport" };
		        
		        boolean isValid = false;
		        for (String value : allowedValues) {
		            if (value.equals(ActIdentitateString)) {
		                isValid = true;
		                break;
		            }
		        }

		        if (!isValid) {
		            JOptionPane.showMessageDialog(null, "Actul de identitate trebuie sa fie 'CI', 'BI', sau 'Pasaport'!", "EROARE!", JOptionPane.ERROR_MESSAGE);
		            textField13.requestFocus();
		        }
		    }
		});
		textField13.setFont(new Font("SansSerif", Font.PLAIN, 14));
		textField13.setColumns(10);
		textField13.setBounds(75, 441, 243, 26);
		frame.getContentPane().add(textField13);
		
		JLabel lblNewLabel_1_1 = new JLabel("SERIA (SAU CODUL TARII) :");
		lblNewLabel_1_1.setForeground(Color.BLACK);
		lblNewLabel_1_1.setFont(new Font("SansSerif", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(416, 416, 198, 14);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		textField14 = new JTextField();
		textField14.setFont(new Font("SansSerif", Font.PLAIN, 14));
		textField14.setColumns(10);
		textField14.setBounds(416, 441, 182, 26);
		frame.getContentPane().add(textField14);
		
		JLabel lblNewLabel_2_1_1_2 = new JLabel("NR :");
		lblNewLabel_2_1_1_2.setForeground(Color.BLACK);
		lblNewLabel_2_1_1_2.setFont(new Font("SansSerif", Font.BOLD, 14));
		lblNewLabel_2_1_1_2.setBounds(692, 416, 145, 14);
		frame.getContentPane().add(lblNewLabel_2_1_1_2);
		
		textField15 = new JTextField();
		textField15.setFont(new Font("SansSerif", Font.PLAIN, 14));
		textField15.setColumns(10);
		textField15.setBounds(692, 441, 145, 26);
		textField15.addFocusListener(new FocusAdapter() {
		    @Override
		    public void focusLost(FocusEvent e) {
		        String numberString = textField15.getText();
		        if (!numberString.matches("\\d+")) {
		            JOptionPane.showMessageDialog(frame, "Acest camp trebuie sa contina doar numere!", "Eroare", JOptionPane.ERROR_MESSAGE);
		            textField15.setText(""); 
		        }
		    }
		});

		frame.getContentPane().add(textField15);
		
	
		
		JLabel lblNewLabel_10_1 = new JLabel("SERVICII DE SPA/PISCINA :");
		lblNewLabel_10_1.setForeground(Color.BLACK);
		lblNewLabel_10_1.setFont(new Font("SansSerif", Font.BOLD, 14));
		lblNewLabel_10_1.setBounds(1197, 553, 191, 14);
		frame.getContentPane().add(lblNewLabel_10_1);
		
		
		JLabel lblNewLabel_13 = new JLabel("New label");
		lblNewLabel_13.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DASHBOARD window = new DASHBOARD();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		
		lblNewLabel_13.setIcon(new ImageIcon(REZERVARE_NOUA.class.getResource("/images/icons8-home-page-48.png")));
		lblNewLabel_13.setBounds(1478, 11, 46, 46);
		frame.getContentPane().add(lblNewLabel_13);
		
		JLabel lblNewLabel_8 = new JLabel("CHECK-IN");
		lblNewLabel_8.setBounds(689, 13, 198, 33);
		frame.getContentPane().add(lblNewLabel_8);
		lblNewLabel_8.setForeground(Color.DARK_GRAY);
		lblNewLabel_8.setBackground(new Color(0, 0, 0));
		lblNewLabel_8.setFont(new Font("Century Gothic", Font.BOLD | Font.ITALIC, 22));
		
		
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.setBounds(0, 0, 151, -4);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_14 = new JLabel("");
		lblNewLabel_14.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				REZERVARE_NOUA window = new REZERVARE_NOUA();
				window.frame.setSize(1550,900);
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		lblNewLabel_14.setIcon(new ImageIcon(REZERVARE_NOUA.class.getResource("/images/icons8-update-left-rotation-24.png")));
		lblNewLabel_14.setBounds(1500, 827, 24, 23);
		frame.getContentPane().add(lblNewLabel_14);
		
		
		


	}
}

