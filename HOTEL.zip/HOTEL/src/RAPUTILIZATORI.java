import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.HorizontalAlignment;
import com.itextpdf.layout.properties.TextAlignment;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JRadioButton;

public class RAPUTILIZATORI {

	JFrame frame;
	private JSpinner startSpinner;
	private JSpinner endSpinner;
	private JTextField textField1;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RAPUTILIZATORI window = new RAPUTILIZATORI();
					window.frame.setResizable(false);
					window. frame.setLocationRelativeTo(null);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RAPUTILIZATORI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 1550, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("RAPORT UTILIZATORI");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel_1.setBounds(10, 11, 235, 21);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("DATA INCEPUT");
		lblNewLabel_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel_1_1.setBounds(526, 11, 181, 21);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("DATA FINAL");
		lblNewLabel_1_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel_1_1_1.setBounds(849, 11, 181, 21);
		frame.getContentPane().add(lblNewLabel_1_1_1);
		
		SpinnerDateModel startModel = new SpinnerDateModel();
        startSpinner = new JSpinner(startModel);
        startSpinner.setFont(new Font("Arial", Font.BOLD, 15));
        startSpinner.setBounds(536, 43, 115, 33); 
        startSpinner.setEditor(new JSpinner.DateEditor(startSpinner, "MM/dd/yyyy"));
        frame.getContentPane().add(startSpinner);
	
        SpinnerDateModel endModel = new SpinnerDateModel();
        endSpinner = new JSpinner(endModel);
        endSpinner.setFont(new Font("Arial", Font.BOLD, 15));
        endSpinner.setBounds(848, 43, 115, 33); 
        endSpinner.setEditor(new JSpinner.DateEditor(endSpinner, "MM/dd/yyyy"));
        frame.getContentPane().add(endSpinner);
		
		JButton button1 = new JButton("AFISEAZA RAPORT");
		button1.setForeground(Color.DARK_GRAY);
		button1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 14));
		button1.setBackground(Color.LIGHT_GRAY);
		button1.setBounds(645, 265, 185, 27);
		frame.getContentPane().add(button1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				RAPOARTE window = new RAPOARTE();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		lblNewLabel.setIcon(new ImageIcon(RAPUTILIZATORI.class.getResource("/images/icons8-home-page-48.png")));
		lblNewLabel.setBounds(1478, 11, 46, 42);
		frame.getContentPane().add(lblNewLabel);
		
		JButton button2 = new JButton("");
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RAPUTILIZATORI window = new RAPUTILIZATORI();
				window.frame.setResizable(false);
				window. frame.setLocationRelativeTo(null);
				window.frame.setVisible(true);
				frame.dispose();
				
			}
		});
		button2.setIcon(new ImageIcon(RAPUTILIZATORI.class.getResource("/images/icons8-update-left-rotation-24.png")));
		button2.setForeground(Color.DARK_GRAY);
		button2.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 14));
		button2.setBackground(Color.LIGHT_GRAY);
		button2.setBounds(1489, 823, 35, 27);
		frame.getContentPane().add(button2);
		
		JRadioButton radioButton1 = new JRadioButton("Afisare utilizatori");
		radioButton1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
		radioButton1.setBounds(130, 170, 148, 23);
		frame.getContentPane().add(radioButton1);
		
		JRadioButton radioButton2 = new JRadioButton("Afisare utilizatori + introdu nume");
		radioButton2.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
		radioButton2.setBounds(299, 170, 235, 23);
		frame.getContentPane().add(radioButton2);
		
		textField1 = new JTextField();
		textField1.setBounds(540, 170, 242, 23);
		frame.getContentPane().add(textField1);
		textField1.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(123, 318, 1293, 344);
		frame.getContentPane().add(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		
		JButton button3 = new JButton("Print");
		button3.setForeground(Color.DARK_GRAY);
		button3.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 14));
		button3.setBackground(Color.LIGHT_GRAY);
		button3.setBounds(1301, 672, 115, 21);
		frame.getContentPane().add(button3);
		
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				generateReport();
			}
		});
		
}
	
	private void generateReport() {
        try {
            
	            Class.forName("com.mysql.cj.jdbc.Driver");
	
	            
	            String url = "jdbc:mysql://localhost:3306/hotel";
	            String username = "root";
	            String password = "Gabriel01";
	            Connection conn = DriverManager.getConnection(url, username, password);
	
	            
	           
	            Date startDate = (Date) startSpinner.getValue();
	            Date endDate = (Date) endSpinner.getValue();
	            SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
	            String formattedsStart = dateFormatter.format(startDate);
				String formattedEnd = dateFormatter.format(endDate);
	            
				// se afiseaza datele 
				
	            String query1 = "SELECT IDUtil, numeUtil, emailUtil FROM utilizator"
	            		+ " WHERE numeUtil != 'Admin' ";

	       		PreparedStatement stmt = conn.prepareStatement(query1);
	            ResultSet rs = stmt.executeQuery();
	            
	            SimpleDateFormat dateFormatter2 = new SimpleDateFormat("yyyy-MM-dd");
	            String timeStamp = dateFormatter2.format(startDate);
	            
	        	String filePath = "C:\\Users\\Gabi\\Desktop\\rapoarte_hotel\\"; 
	        	String fileName = filePath + "Raport_utilizatori_" + timeStamp + ".pdf";
			

		        PdfWriter writer = new PdfWriter(new FileOutputStream(fileName));
		        PdfDocument pdf = new PdfDocument(writer);
		        Document document = new Document(pdf, PageSize.A4);

	            
	            Paragraph title = new Paragraph("RAPORT UTILIZATORI");
	            title.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
	            document.add(title);
	            
	            Paragraph title2 = new Paragraph("-----------------------------------------------------------------------------"
	            		+ "---------------------------------------------------");
	            title2.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
	            document.add(title2);

	            
	            Paragraph perioada = new Paragraph("Perioada raportului: " + formattedsStart.toString() + " - " + formattedEnd.toString());
	            perioada.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
	            document.add(perioada);

	            
	            Table table = new Table(3);
	            table.addCell("Cod Utilizator:");
	            table.addCell("Nume:");
	            table.addCell("Email: ");
	     
	            table.setHorizontalAlignment(HorizontalAlignment.CENTER);
	            
	           

	            while (rs.next()) {
	                table.addCell(rs.getString("IDUtil"));
	                table.addCell(rs.getString("numeUtil"));
	                table.addCell(rs.getString("emailUtil"));
	              
	                table.setMarginBottom(20);
	            }
	            
	            document.add(table);
	            
	            Paragraph title3 = new Paragraph("-----------------------------------------------------------------------------"
	            		+ "---------------------------------------------------");
	            title3.setTextAlignment(TextAlignment.CENTER).setMarginBottom(20);
	            document.add(title3);
	            
	           
	            String query2= "SELECT COUNT(*) AS total_utilizatori FROM utilizator WHERE numeUtil != 'Admin' ";
	            PreparedStatement stmt2 = conn.prepareStatement(query2);
	            ResultSet rs2 = stmt2.executeQuery();
	            
	            int totalutilizatori=0;
	            if (rs2.next()) {
	            	
	                 totalutilizatori = rs2.getInt("total_utilizatori");
	            }
	                
	                String totalUtil = "Numarul total de utilizatori intre " +
	                                      dateFormatter.format(startDate) + " si " +
	                                      dateFormatter.format(endDate) + " este: " + totalutilizatori;
	                
	                Paragraph totalRezerv = new Paragraph(totalUtil).setTextAlignment(TextAlignment.CENTER)
	                		.setMarginBottom(15);
	                totalRezerv.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
	                document.add(totalRezerv);
	                document.close();

	            JOptionPane.showMessageDialog(null, "Raport realizat!");
	            RAPUTILIZATORI window = new RAPUTILIZATORI();
				window.frame.setResizable(false);
				window. frame.setLocationRelativeTo(null);
				window.frame.setVisible(true);
				frame.dispose();
	            
	            
		} catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Eroare la generarea raportului!");
        }
		
		
	
   }
}
		
		
		
		
		
		

