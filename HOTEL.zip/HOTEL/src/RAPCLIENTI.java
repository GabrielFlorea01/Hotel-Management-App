import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.HorizontalAlignment;
import com.itextpdf.layout.properties.TextAlignment;

import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class RAPCLIENTI {

	JFrame frame;
	private JSpinner startSpinner;
	private JSpinner endSpinner;
	private JTextField textField1;
	private JTextField textField2;
	private JRadioButton radioButton5;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RAPCLIENTI window = new RAPCLIENTI();
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RAPCLIENTI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 1550, 900);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1_1 = new JLabel("DATA INCEPUT");
		lblNewLabel_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel_1_1.setBounds(535, 12, 153, 21);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("DATA FINAL");
		lblNewLabel_1_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel_1_1_1.setBounds(854, 12, 181, 21);
		frame.getContentPane().add(lblNewLabel_1_1_1);
		
		    SpinnerDateModel startModel = new SpinnerDateModel();
	        startSpinner = new JSpinner(startModel);
	        startSpinner.setFont(new Font("Arial", Font.BOLD, 15));
	        startSpinner.setBounds(545, 44, 115, 33); 
	        startSpinner.setEditor(new JSpinner.DateEditor(startSpinner, "MM/dd/yyyy"));
	        frame.getContentPane().add(startSpinner);
		
	        SpinnerDateModel endModel = new SpinnerDateModel();
	        endSpinner = new JSpinner(endModel);
	        endSpinner.setFont(new Font("Arial", Font.BOLD, 15));
	        endSpinner.setBounds(854, 44, 115, 33); 
	        endSpinner.setEditor(new JSpinner.DateEditor(endSpinner, "MM/dd/yyyy"));
	        frame.getContentPane().add(endSpinner);
		
		JLabel lblNewLabel_1 = new JLabel("RAPORT CLIENTI");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 19));
		lblNewLabel_1.setBounds(10, 11, 197, 21);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton3 = new JButton("");
		btnNewButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RAPCLIENTI window = new RAPCLIENTI();
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				window.frame.setVisible(true);
				frame.dispose();
				
			}
		});
		btnNewButton3.setIcon(new ImageIcon(RAPCLIENTI.class.getResource("/images/icons8-update-left-rotation-24.png")));
		btnNewButton3.setForeground(Color.DARK_GRAY);
		btnNewButton3.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 14));
		btnNewButton3.setBackground(Color.LIGHT_GRAY);
		btnNewButton3.setBounds(1486, 819, 38, 31);
		frame.getContentPane().add(btnNewButton3);
		
		JButton btnNewButton2 = new JButton("ARATA RAPORT");
		btnNewButton2.setBackground(Color.LIGHT_GRAY);
		btnNewButton2.setForeground(Color.DARK_GRAY);
		btnNewButton2.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 14));
		btnNewButton2.setBounds(667, 261, 176, 31);
		frame.getContentPane().add(btnNewButton2);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				RAPOARTE window = new RAPOARTE();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		lblNewLabel.setIcon(new ImageIcon(RAPCLIENTI.class.getResource("/images/icons8-home-page-48.png")));
		lblNewLabel.setBounds(1476, 11, 48, 48);
		frame.getContentPane().add(lblNewLabel);
		
		JRadioButton radioButton1 = new JRadioButton("Afiseaza toti clientii");
		radioButton1.setForeground(Color.DARK_GRAY);
		radioButton1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 13));
		radioButton1.setBounds(64, 151, 163, 23);
		frame.getContentPane().add(radioButton1);
		
		JRadioButton radioButton2 = new JRadioButton("Afiseaza clientii + rezervari");
		radioButton2.setForeground(Color.DARK_GRAY);
		radioButton2.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 13));
		radioButton2.setBounds(282, 152, 197, 23);
		frame.getContentPane().add(radioButton2);
		
		JRadioButton radioButton3 = new JRadioButton("Alege localitatea");
		radioButton3.setForeground(Color.DARK_GRAY);
		radioButton3.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 13));
		radioButton3.setBounds(546, 152, 142, 23);
		frame.getContentPane().add(radioButton3);
		
		textField1 = new JTextField();
		textField1.setBounds(695, 153, 124, 21);
		frame.getContentPane().add(textField1);
		textField1.setColumns(10);
		
		JRadioButton radioButton4 = new JRadioButton("Alege tara");
		radioButton4.setForeground(Color.DARK_GRAY);
		radioButton4.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 13));
		radioButton4.setBounds(872, 151, 115, 23);
		frame.getContentPane().add(radioButton4);
		
		textField2 = new JTextField();
		textField2.setColumns(10);
		textField2.setBounds(993, 153, 124, 21);
		frame.getContentPane().add(textField2);
		
		radioButton5 = new JRadioButton("Alege provenienta");
		radioButton5.setForeground(Color.DARK_GRAY);
		radioButton5.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 13));
		radioButton5.setBounds(1175, 151, 153, 23);
		frame.getContentPane().add(radioButton5);
		
		JComboBox comboBox1 = new JComboBox();
		comboBox1.setForeground(Color.DARK_GRAY);
		comboBox1.setFont(new Font("Arial", Font.ITALIC, 14));
		comboBox1.setModel(new DefaultComboBoxModel(new String[] {"Walk-in", "Rezervare telefon", "E-mail"}));
		comboBox1.setBounds(1334, 151, 115, 23);
		frame.getContentPane().add(comboBox1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(131, 323, 1268, 373);
		frame.getContentPane().add(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		
		JButton btnPrint = new JButton("Print");
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnPrint.setForeground(Color.DARK_GRAY);
		btnPrint.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 14));
		btnPrint.setBackground(Color.LIGHT_GRAY);
		btnPrint.setBounds(1289, 707, 110, 21);
		frame.getContentPane().add(btnPrint);
		
		
		btnNewButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				generateReport();
				
				
			}
		});
		
	
	}
	
		private void generateReport() {
	        try {
	            
	            Class.forName("com.mysql.cj.jdbc.Driver");
	
	            
	            String url = "jdbc:mysql://localhost:3306/hotel";
	            String username = "root";
	            String password = "Gabriel01";
	            Connection conn = DriverManager.getConnection(url, username, password);
	
	            
	           
	            Date startDate = (Date) startSpinner.getValue();
	            Date endDate = (Date) endSpinner.getValue();
	            SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
	            String formattedsStart = dateFormatter.format(startDate);
				String formattedEnd = dateFormatter.format(endDate);
	            
	            String query1 = "SELECT c.IDClient, c.numeClient, c.adresaClient, c.telefonClient, c.emailClient " +
	                    "FROM istoric_rezervari ir " +
	                    "INNER JOIN client c ON ir.idclient = c.IDClient " +
	                    "WHERE ir.checkin >= ? AND checkout <= ?";

	            
	            PreparedStatement stmt = conn.prepareStatement(query1);
	            stmt.setDate(1, new java.sql.Date(startDate.getTime()));
	            stmt.setDate(2, new java.sql.Date(endDate.getTime()));
	            ResultSet rs = stmt.executeQuery();
	            
		    
	            SimpleDateFormat dateFormatter2 = new SimpleDateFormat("yyyy-MM-dd");
	            String timeStamp = dateFormatter2.format(startDate);
	            
	        	String filePath = "C:\\Users\\Gabi\\Desktop\\rapoarte_hotel\\"; 
	        	String fileName = filePath + "Raport_clienti_" + timeStamp + ".pdf";
            	
				
	
			        PdfWriter writer = new PdfWriter(new FileOutputStream(fileName));
			        PdfDocument pdf = new PdfDocument(writer);
			        Document document = new Document(pdf, PageSize.A4);
	
		            
		            Paragraph title = new Paragraph("RAPORT CLIENTI");
		            title.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
		            document.add(title);

		            Paragraph title2 = new Paragraph("-----------------------------------------------------------------------------"
		            		+ "---------------------------------------------------");
		            title2.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
		            document.add(title2);
		            
		            Paragraph perioada = new Paragraph("Perioada raportului: " + formattedsStart.toString() + " - " + formattedEnd.toString());
		            perioada.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
		            document.add(perioada);
	
		            
		            Table table = new Table(5);
		            table.addCell("Cod");
		            table.addCell("Nume");
		            table.addCell("Adresa");
		            table.addCell("Telefon");
		            table.addCell("E-mail");
		            table.setHorizontalAlignment(HorizontalAlignment.CENTER);
		            
		           
	
		            while (rs.next()) {
		                String idclient = rs.getString("IDClient");
		                String numeclient = rs.getString("numeClient");
		                String adresaclient = rs.getString("adresaClient");
		                String telefonclient = rs.getString("telefonClient");
		                String emailclient = rs.getString("emailClient");
		                
		                table.addCell(idclient);
		                table.addCell(numeclient);
		                table.addCell(adresaclient);
		                table.addCell(telefonclient);
		                table.addCell(emailclient);
		                table.setMarginBottom(20);
		                document.add(table);
		            }
		            
		            Paragraph title3 = new Paragraph("-----------------------------------------------------------------------------"
		            		+ "---------------------------------------------------");
		            title3.setTextAlignment(TextAlignment.CENTER).setMarginBottom(20);
		            document.add(title3);
		            
		           
		            String query2 = "SELECT idclient, COUNT(*) AS total_Clienti "
		            		+ "FROM istoric_rezervari "
		            		+ "WHERE checkin >= ? AND checkout <= ? "
		            		+ "GROUP BY idclient "
		            		+ "ORDER BY COUNT(*) DESC";
		            
		            PreparedStatement stmt2 = conn.prepareStatement(query2);
		            stmt2.setDate(1, new java.sql.Date(startDate.getTime()));
		            stmt2.setDate(2, new java.sql.Date(endDate.getTime()));
		            ResultSet rs2 = stmt2.executeQuery();
		            
		            if (rs2.next()) {
		            	
		                int numClients = rs2.getInt("total_Clienti");
		                
		                String totalClienti = "Numarul total de clienti intre " +
		                                      dateFormatter.format(startDate) + " si " +
		                                      dateFormatter.format(endDate) + " este: " + numClients;
		                
		                Paragraph total = new Paragraph(totalClienti).setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
		                total.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
		                document.add(total);
		            }
		          
		                    
		                    
		            document.close();
	
		            JOptionPane.showMessageDialog(null, "Raport realizat!");
		            
			} catch (Exception e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(null, "Eroare la generarea raportului!");
	        }
	        
		
		
		
	}
}
