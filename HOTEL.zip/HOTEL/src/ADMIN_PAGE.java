import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;

public class ADMIN_PAGE {

	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ADMIN_PAGE window = new ADMIN_PAGE();
					window.frame.setVisible(true);
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ADMIN_PAGE() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setForeground(Color.DARK_GRAY);
		frame.setResizable(false);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("LOG OUT");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				LOGIN window = new LOGIN();
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				window.frame.setVisible(true);
				frame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNewLabel_1.setForeground(Color.red);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblNewLabel_1.setForeground(Color.darkGray);
			}
		});
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_1.setIcon(new ImageIcon(ADMIN_PAGE.class.getResource("/images/icons8-log-out-32.png")));
		lblNewLabel_1.setBounds(1413, 801, 111, 37);
		frame.getContentPane().add(lblNewLabel_1);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 0, 305, 861);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.setBounds(0, 0, 305, -14);
		panel.add(btnNewButton);
		
		JButton button3 = new JButton("DASHBOARD");
		button3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				button3.setBackground(Color.lightGray);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				button3.setBackground(Color.DARK_GRAY);
			}
		});
		button3.setBounds(0, 391, 305, 37);
		panel.add(button3);
		button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DASHBOARD window = new DASHBOARD();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				
			}
		});
		button3.setForeground(Color.WHITE);
		button3.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 16));
		button3.setBackground(Color.DARK_GRAY);
		
		JButton btnUtilizatori = new JButton("UTILIZATORI");
		btnUtilizatori.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnUtilizatori.setBackground(Color.LIGHT_GRAY);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnUtilizatori.setBackground(Color.darkGray);
			}
		});
		btnUtilizatori.setBounds(0, 343, 305, 37);
		panel.add(btnUtilizatori);
		btnUtilizatori.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				UTILIZATORI window = new UTILIZATORI();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		btnUtilizatori.setForeground(Color.WHITE);
		btnUtilizatori.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 16));
		btnUtilizatori.setBackground(Color.DARK_GRAY);
		
		JButton btnNewButton2 = new JButton("RAPOARTE");
		btnNewButton2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton2.setBackground(Color.lightGray);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton2.setBackground(Color.darkGray);
			}
		});
		btnNewButton2.setBounds(0, 480, 305, 37);
		panel.add(btnNewButton2);
		btnNewButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				RAPOARTE window = new RAPOARTE();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
				
				
			}
		});
		btnNewButton2.setForeground(Color.WHITE);
		btnNewButton2.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 16));
		btnNewButton2.setBackground(Color.DARK_GRAY);
		
		JLabel lblNewLabel = new JLabel("Welcome Admin !");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 0, 305, 48);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(ADMIN_PAGE.class.getResource("/images/icons8-admin-48.png")));
		lblNewLabel_3.setBounds(124, 44, 57, 56);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setIcon(new ImageIcon(ADMIN_PAGE.class.getResource("/images/labirint.png")));
		lblNewLabel_4.setBounds(670, 37, 286, 102);
		frame.getContentPane().add(lblNewLabel_4);
		frame.setBounds(100, 100, 1550, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
