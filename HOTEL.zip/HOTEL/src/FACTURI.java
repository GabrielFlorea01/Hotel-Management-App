import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class FACTURI {

	JFrame frame;
	private JTextField textField;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FACTURI window = new FACTURI();
					window.frame.setLocationRelativeTo(null);
					window.frame.setResizable(false);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FACTURI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 1550, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Cauta facturi dupa data de check-out");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setBounds(438, 77, 267, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 15));
		textField.setBounds(712, 71, 165, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnCauta = new JButton("CAUTA");
		btnCauta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String dataCO= textField.getText();
				ResultSet rs=null;
				
				if (dataCO.equals("")) 
				{
					JOptionPane.showMessageDialog(null, "Completeaza data de Check-out !");
				}
				
				else 
					
					try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root",
							"Gabriel01");
							
							PreparedStatement stmt = conn.prepareStatement("SELECT IDRezervare, IDClient, IDCamera, IDRestaurant, IDSpa, checkIN, checkOUT, numarPers from hotel.rezervare WHERE checkOUT= ?");) 
					{
						
						stmt.setString(1, dataCO);
					    rs = stmt.executeQuery();
				
			        }
				
				catch (Exception e2) {
					
				}
			}});
		
		btnCauta.setForeground(Color.DARK_GRAY);
		btnCauta.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 13));
		btnCauta.setBackground(Color.LIGHT_GRAY);
		btnCauta.setBounds(882, 72, 97, 25);
		frame.getContentPane().add(btnCauta);
		
		JButton btnNewButton6 = new JButton("");
		btnNewButton6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FACTURI window = new FACTURI();
				window.frame.setLocationRelativeTo(null);
				window.frame.setResizable(false);
				window.frame.setVisible(true);
				frame.dispose();
				
			}
		});
		btnNewButton6.setIcon(new ImageIcon(FACTURI.class.getResource("/images/icons8-update-left-rotation-24.png")));
		btnNewButton6.setBackground(Color.LIGHT_GRAY);
		btnNewButton6.setBounds(1489, 824, 35, 26);
		frame.getContentPane().add(btnNewButton6);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DASHBOARD window = new DASHBOARD();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		lblNewLabel.setIcon(new ImageIcon(FACTURI.class.getResource("/images/icons8-home-page-48.png")));
		lblNewLabel.setBounds(1472, 12, 46, 44);
		frame.getContentPane().add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(256, 343, 1082, 280);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID Factura", "ID Rezervare", "Nr. Camera", "Numele Clientului", "Data emiterii", "Valoare totala (faraT.V.A)", "Valoare (cu T.V.A)"
			}
		));
		table.getColumnModel().getColumn(3).setPreferredWidth(99);
		table.getColumnModel().getColumn(5).setPreferredWidth(100);
		table.setFont(new Font("Century Gothic", Font.ITALIC, 14));
		scrollPane.setViewportView(table);
		
		JButton button2 = new JButton("Arata toate facturile");
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		button2.setForeground(Color.DARK_GRAY);
		button2.setBackground(Color.LIGHT_GRAY);
		button2.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 14));
		button2.setBounds(254, 312, 181, 23);
		frame.getContentPane().add(button2);
		
		JButton button3 = new JButton("Printeaza factura fiscala");
		button3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				button3.setForeground(Color.green);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				button3.setForeground(Color.darkGray);
			}
		});
		button3.setForeground(Color.DARK_GRAY);
		button3.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 14));
		button3.setBackground(Color.LIGHT_GRAY);
		button3.setBounds(697, 679, 203, 23);
		frame.getContentPane().add(button3);
	}
}
