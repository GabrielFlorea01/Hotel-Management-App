import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class CAMERE {

	JFrame frame;
	private JTextField textField3;
	
	private static final String SQL_INSERT = "INSERT INTO hotel.camera (IDCamera,tipCamera, pretCamera, statusCamera) VALUES (?,?,?,'Libera')";
	
	private JTable table;
	private JTextField textField;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CAMERE window = new CAMERE();
					window.frame.setVisible(true);
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CAMERE() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setForeground(new Color(255, 255, 255));
		frame.getContentPane().setFont(new Font("SansSerif", Font.PLAIN, 15));
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 1550, 900);
		frame.getContentPane().setLayout(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLabel lblNewLabel4 = new JLabel("Introdu pretul actualizat");
		lblNewLabel4.setForeground(Color.DARK_GRAY);
		lblNewLabel4.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel4.setBounds(1152, 452, 174, 23);
		frame.getContentPane().add(lblNewLabel4);
		
		textField3 = new JTextField();
		textField3.setHorizontalAlignment(SwingConstants.CENTER);
		textField3.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 16));
		textField3.setBounds(1175, 486, 135, 23);
		frame.getContentPane().add(textField3);
		textField3.setColumns(10);
		
		JButton btnNewButton3 = new JButton("Modifica pretul");
		btnNewButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int selectedRow = table.getSelectedRow();
				String pret = textField3.getText();
				
				 // daca nu este selectat nimic se afiseaza eroare
				
				 if (selectedRow == -1) {
			            JOptionPane.showMessageDialog(null, "Selecteaza o camera!", "Eroare!", JOptionPane.ERROR_MESSAGE);
			            return;
			        }
				 
				// se verifica daca este gol textfield-ul de pret
				 
			        if (pret.isEmpty()) {
			            JOptionPane.showMessageDialog(null, "Introduceti un pret valid!", "Eroare!", JOptionPane.ERROR_MESSAGE);
			            return;
			        }

			        // Se parseaza textul in float
			        
			        float pretCamera;
			        try {
			            pretCamera = Float.parseFloat(pret);
			        } catch (NumberFormatException ex) {
			            JOptionPane.showMessageDialog(null, "Introduceti un pret valid!", "Eroare!", JOptionPane.ERROR_MESSAGE);
			            return;
			        }
				 
				  // se ia ID-ul camerei selectate din tabel
			        
				    int IDCamera = (int) table.getValueAt(selectedRow, 0);
			        
				
				
				
				try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "Gabriel01");
						
				    PreparedStatement stmt = conn.prepareStatement("UPDATE camera SET pretCamera =? WHERE IDCamera = ?")) {
					
				    
				    stmt.setFloat(1, pretCamera);
				    stmt.setInt(2, IDCamera); 
				    stmt.executeUpdate();
				    
				    JOptionPane.showMessageDialog(null, "Actualizare pret cu succes !");
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Eroare la actualizarea camerei !");
		        }
			}
		});
		
			
		btnNewButton3.setBackground(Color.LIGHT_GRAY);
		btnNewButton3.setForeground(Color.DARK_GRAY);
		btnNewButton3.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 14));
		btnNewButton3.setBounds(1169, 531, 141, 28);
		frame.getContentPane().add(btnNewButton3);
		
		JButton btnNewButton6 = new JButton("");
		btnNewButton6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CAMERE camWindow = new CAMERE();
				camWindow.frame.setVisible(true);
				camWindow.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		btnNewButton6.setBackground(Color.LIGHT_GRAY);
		btnNewButton6.setIcon(new ImageIcon(CAMERE.class.getResource("/images/icons8-update-left-rotation-24.png")));
		btnNewButton6.setBounds(1479, 821, 45, 29);
		frame.getContentPane().add(btnNewButton6);
	
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(34, 206, 865, 502);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setForeground(Color.DARK_GRAY);
		table.setFont(new Font("Century Gothic", Font.ITALIC, 14));
		table.setBackground(Color.WHITE);
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nr.camera", "Tip camera", "Pret", "Status ", "Dotari"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(86);
		table.getColumnModel().getColumn(1).setPreferredWidth(95);
		table.getColumnModel().getColumn(2).setPreferredWidth(84);
		table.getColumnModel().getColumn(3).setPreferredWidth(93);
		table.getColumnModel().getColumn(4).setPreferredWidth(102);
		
		JLabel lblNewLabel_4 = new JLabel("Introdu numarul camerei ");
		lblNewLabel_4.setForeground(Color.DARK_GRAY);
		lblNewLabel_4.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_4.setBounds(574, 39, 182, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		textField = new JTextField();
		textField.setFont(new Font("SansSerif", Font.BOLD, 16));
		textField.setBounds(758, 34, 86, 23);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton5 = new JButton("CAUTA");
		btnNewButton5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
                String textFieldid = textField.getText();
				
				if (textFieldid.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Completeaza numarul camerei !","Eroare !", JOptionPane.ERROR_MESSAGE);

				} else if (!textFieldid.matches("\\d+")) {
					JOptionPane.showMessageDialog(null, "Te rog intorodu un numar valabil !", "Eroare !", JOptionPane.ERROR_MESSAGE);
					textField.setText("");
				} else {
				
				try 
				(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
				PreparedStatement stmt = conn.prepareStatement("SELECT * from hotel.camera WHERE IDCamera= ?");)
				{
					stmt.setInt(1, Integer.parseInt(textField.getText()));
					ResultSet rs =stmt.executeQuery();
					DefaultTableModel tm = (DefaultTableModel)table.getModel();
					tm.setRowCount(0);
					
					if(rs.next()) {
						Object o[]= {rs.getInt("IDCamera"),rs.getString("tipCamera"),rs.getString("pretCamera"),rs.getString("statusCamera"), rs.getString("dotari")};
					    tm.addRow(o);
					}else {
						JOptionPane.showMessageDialog(null, "Camera nu exista !", "Eroare !", JOptionPane.ERROR_MESSAGE);
					}
					
				}catch (SQLException e1) {
					e1.printStackTrace();
				}
				
			}
	}});
		
		btnNewButton5.setBackground(Color.LIGHT_GRAY);
		btnNewButton5.setForeground(Color.DARK_GRAY);
		btnNewButton5.setFont(new Font("SansSerif", Font.BOLD, 15));
		btnNewButton5.setBounds(854, 34, 89, 23);
		frame.getContentPane().add(btnNewButton5);
		
		JButton btnNewButton = new JButton("Arata camerele");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
				PreparedStatement stmt = conn.prepareStatement("SELECT * from hotel.camera");)
				{
				ResultSet rs = stmt.executeQuery();
				DefaultTableModel tm = (DefaultTableModel)table.getModel();
				tm.setRowCount(0);
				
				while(rs.next()) {
					Object o[]= {rs.getInt("IDCamera"),rs.getString("tipCamera"),rs.getString("pretCamera"),rs.getString("statusCamera"),rs.getString("dotari")};
				    tm.addRow(o);
				}
				
				
				
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		
		btnNewButton.setForeground(Color.DARK_GRAY);
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 14));
		btnNewButton.setBounds(37, 172, 149, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DASHBOARD window = new DASHBOARD();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		lblNewLabel.setIcon(new ImageIcon(CAMERE.class.getResource("/images/icons8-home-page-48.png")));
		lblNewLabel.setBounds(1478, 11, 46, 42);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblSelecteazaDotarileCamerei = new JLabel("Modifica statusul camerei");
		lblSelecteazaDotarileCamerei.setForeground(Color.DARK_GRAY);
		lblSelecteazaDotarileCamerei.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		lblSelecteazaDotarileCamerei.setBounds(1143, 277, 200, 23);
		frame.getContentPane().add(lblSelecteazaDotarileCamerei);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Indisponibila", "Curatenie", "Libera"}));
		comboBox.setFont(new Font("Century Gothic", Font.ITALIC, 15));
		comboBox.setBackground(Color.WHITE);
		comboBox.setBounds(1152, 311, 174, 28);
		frame.getContentPane().add(comboBox);
		
		JButton button4 = new JButton("Modifica status");
		button4.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        int selectedRow = table.getSelectedRow();
		        String statusCamera = comboBox.getSelectedItem().toString();

		        if (selectedRow == -1) {
		            JOptionPane.showMessageDialog(null, "Selecteaza o camera!", "Eroare!", JOptionPane.ERROR_MESSAGE);
		            return;
		        }

		        int IDCamera = (int) table.getValueAt(selectedRow, 0);

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "Gabriel01")) {
		            // se verifica daca este inregistrata camere pe o rezervare
		        	
		           
		            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM rezervare WHERE IDCamera = ?");
		            stmt.setInt(1, IDCamera);
		            ResultSet reservationResult = stmt.executeQuery();

		            // daca exista rezervare se va afisa o eroare
		            if (reservationResult.next()) {
		                JOptionPane.showMessageDialog(null, "Camera este inregistrata pe o rezervare. Nu se poate modifica statusul !", "Eroare!", JOptionPane.ERROR_MESSAGE);
		                return;
		            }

		            // se face update-ul daca nu este inregistrata nicio rezevare cu camera respectiva
		            
		            
		            PreparedStatement stmt2 = conn.prepareStatement("UPDATE camera SET statusCamera = ? WHERE IDCamera = ?");
		            stmt2.setString(1, statusCamera);
		            stmt2.setInt(2, IDCamera);
		            stmt2.executeUpdate();

		            JOptionPane.showMessageDialog(null, "Actualizare status cu succes !");
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Eroare la actualizarea camerei !");
		        }
		    }
		});

		button4.setForeground(Color.DARK_GRAY);
		button4.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 14));
		button4.setBackground(Color.LIGHT_GRAY);
		button4.setBounds(1169, 361, 141, 28);
		frame.getContentPane().add(button4);
	}
}

