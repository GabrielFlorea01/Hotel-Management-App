import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class UTILIZATORI {

	JFrame frame;
	private JTextField textField1;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UTILIZATORI window = new UTILIZATORI();
					window.frame.setVisible(true);
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UTILIZATORI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1550, 900);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton1 = new JButton("CAUTA");
		btnNewButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String nume = textField1.getText();
				
				if (nume.equals("")) 
				{
					JOptionPane.showMessageDialog(null, "Completeaza numele utilizatorului !");
				}else 
				
				try 
				(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
				PreparedStatement stmt = conn.prepareStatement("SELECT IDUtil, numeUtil, emailUtil, data_adaugare, aprobat from hotel.utilizator WHERE numeUtil = ?");)
				{
					stmt.setString(1, nume);
					ResultSet rs =stmt.executeQuery();
					DefaultTableModel tm = (DefaultTableModel)table.getModel();
					tm.setRowCount(0);
					
					while(rs.next()) {
						Object o[]= {rs.getInt("IDUtil"),rs.getString("numeUtil"),rs.getString("emailUtil"),rs.getString("data_adaugare"), rs.getString("aprobat")};
					    tm.addRow(o);
					}
					
				}catch (SQLException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		
		btnNewButton1.setForeground(Color.DARK_GRAY);
		btnNewButton1.setFont(new Font("Arial", Font.BOLD, 14));
		btnNewButton1.setBackground(Color.LIGHT_GRAY);
		btnNewButton1.setBounds(931, 80, 89, 29);
		frame.getContentPane().add(btnNewButton1);
		
		textField1 = new JTextField();
		textField1.setFont(new Font("Arial", Font.ITALIC, 16));
		textField1.setColumns(10);
		textField1.setBounds(687, 79, 234, 29);
		frame.getContentPane().add(textField1);
		
		JLabel lblNewLabel_4 = new JLabel("Introdu numele utilizatorului");
		lblNewLabel_4.setForeground(Color.DARK_GRAY);
		lblNewLabel_4.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel_4.setBounds(459, 87, 250, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(324, 336, 878, 226);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Century Gothic", Font.PLAIN, 14));
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID Utilizator", "Nume", "Email", "Data inregistrarii", "Aprobat"
			}
		));
		scrollPane.setViewportView(table);
		
		JButton btnNewButton2 = new JButton("Sterge utilizator");
		btnNewButton2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton2.setForeground(Color.red);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton2.setForeground(Color.darkGray);
			}
		});
		
		btnNewButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nume = textField1.getText();
				if (nume.equals("")) 
				{
					JOptionPane.showMessageDialog(null, "Completeaza numele utilizatorului ! !");
				}else 
				try 
				(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
						PreparedStatement stmt = conn.prepareStatement("DELETE from hotel.utilizator WHERE numeUtil= ?");)
								{
									stmt.setString(1, nume);
									stmt.executeUpdate();
									JOptionPane.showMessageDialog(null, "Utilizatorul a fost sters cu succes !");
									UTILIZATORI window = new UTILIZATORI();
									window.frame.setVisible(true);
									window.frame.setResizable(false);
									window.frame.setLocationRelativeTo(null);
									
								}catch (SQLException e1) {
									e1.printStackTrace();
								}
				
				
				
				
			}
		});
		
		btnNewButton2.setForeground(Color.DARK_GRAY);
		btnNewButton2.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 14));
		btnNewButton2.setBackground(Color.LIGHT_GRAY);
		btnNewButton2.setBounds(1017, 300, 187, 25);
		frame.getContentPane().add(btnNewButton2);
		
		JButton btnNewButton3 = new JButton("Arata utilizatorii");
		btnNewButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
						PreparedStatement stmt = conn.prepareStatement("SELECT * from hotel.utilizator");)
						{
						ResultSet rs = stmt.executeQuery();
						DefaultTableModel tm = (DefaultTableModel)table.getModel();
						tm.setRowCount(0);
						
						while(rs.next()) {
							Object o[]= {rs.getInt("IDUtil"),rs.getString("numeUtil"),rs.getString("emailUtil"),rs.getDate("data_adaugare"),rs.getString("aprobat")};
						    tm.addRow(o);
						}
						
						
						
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
						
					}
				});
		
		
		btnNewButton3.setForeground(Color.DARK_GRAY);
		btnNewButton3.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 14));
		btnNewButton3.setBackground(Color.LIGHT_GRAY);
		btnNewButton3.setBounds(324, 300, 175, 25);
		frame.getContentPane().add(btnNewButton3);
		
		JButton btnNewButton6 = new JButton("");
		btnNewButton6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UTILIZATORI window = new UTILIZATORI();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
				
			}
		});
		btnNewButton6.setIcon(new ImageIcon(UTILIZATORI.class.getResource("/images/icons8-update-left-rotation-24.png")));
		btnNewButton6.setBackground(Color.LIGHT_GRAY);
		btnNewButton6.setBounds(1491, 821, 33, 29);
		frame.getContentPane().add(btnNewButton6);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ADMIN_PAGE window = new ADMIN_PAGE();
					window.frame.setVisible(true);
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
					frame.dispose();
			}
		});
		
		lblNewLabel.setIcon(new ImageIcon(UTILIZATORI.class.getResource("/images/icons8-admin-48.png")));
		lblNewLabel.setBounds(1476, 11, 48, 48);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnAprobaUtilizator = new JButton("APROBA UTILIZATOR");
		btnAprobaUtilizator.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	
		    	String nume = textField1.getText();
		    	
		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "Gabriel01");
		             PreparedStatement stmt = conn.prepareStatement("UPDATE utilizator SET aprobat = ? WHERE numeUtil = ?")) {

		            stmt.setString(1, "DA");
		            stmt.setString(2, nume);
		            
		            int rowsUpdated = stmt.executeUpdate();

		            if (rowsUpdated > 0) {
		            	JOptionPane.showMessageDialog(null, "Utilizatorul este deja aprobat !");
		            } else {
		            	JOptionPane.showMessageDialog(null, "Utilizatorul a fost aprobat !");
		            }

		        } catch (SQLException e1) {
		            e1.printStackTrace();
		        }
		    }
		});

		btnAprobaUtilizator.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnAprobaUtilizator.setForeground(Color.green);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnAprobaUtilizator.setForeground(Color.DARK_GRAY);
			}
		});
		btnAprobaUtilizator.setForeground(Color.DARK_GRAY);
		btnAprobaUtilizator.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 14));
		btnAprobaUtilizator.setBackground(Color.LIGHT_GRAY);
		btnAprobaUtilizator.setBounds(662, 589, 195, 25);
		frame.getContentPane().add(btnAprobaUtilizator);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
