import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class RAPOARTE {

	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RAPOARTE window = new RAPOARTE();
					window.frame.setVisible(true);
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RAPOARTE() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		frame.getContentPane().setForeground(Color.WHITE);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 1550, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton button1 = new JButton("RAPORT CLIENTI");
		button1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RAPCLIENTI window = new RAPCLIENTI();
			    window.frame.setLocationRelativeTo(null);
				window.frame.setVisible(true);
				frame.dispose();
			}
		});
		button1.setBackground(Color.DARK_GRAY);
		button1.setForeground(Color.WHITE);
		button1.setBounds(0, 162, 244, 39);
		frame.getContentPane().add(button1);
		
		JButton button2 = new JButton("RAPORT CAMERE");
		button2.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RAPCAMERE window = new RAPCAMERE();
				window.frame.setLocationRelativeTo(null);
				window.frame.setVisible(true);
				frame.dispose();
			}
		});
		button2.setBackground(Color.DARK_GRAY);
		button2.setForeground(Color.WHITE);
		button2.setBounds(0, 262, 244, 39);
		frame.getContentPane().add(button2);
		
		JButton button3 = new JButton("RAPORT REZERVARI");
		button3.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RAPREZERVARI window = new RAPREZERVARI();
				window.frame.setLocationRelativeTo(null);
				window.frame.setVisible(true);
				frame.dispose();
			}
		});
		button3.setBackground(Color.DARK_GRAY);
		button3.setForeground(Color.WHITE);
		button3.setBounds(0, 212, 244, 39);
		frame.getContentPane().add(button3);
		
		JButton button4 = new JButton("RAPORT RESTAURANT");
		button4.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		button4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RAPRESTAURANT window = new RAPRESTAURANT();
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				window.frame.setVisible(true);
				frame.dispose();
			}
		});
		button4.setBackground(Color.DARK_GRAY);
		button4.setForeground(Color.WHITE);
		button4.setBounds(0, 312, 244, 39);
		frame.getContentPane().add(button4);
		
		JButton button5 = new JButton("RAPORT UTILIZATORI");
		button5.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		button5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RAPUTILIZATORI window = new RAPUTILIZATORI();
				window. frame.setLocationRelativeTo(null);
				window.frame.setVisible(true);
				frame.dispose();
			}
		});
		button5.setBackground(Color.DARK_GRAY);
		button5.setForeground(Color.WHITE);
		button5.setBounds(0, 412, 244, 39);
		frame.getContentPane().add(button5);
		
		JButton button6 = new JButton("RAPORT SERVICII SPA");
		button6.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		button6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RAPSPA window = new RAPSPA();
				window.frame.setLocationRelativeTo(null);
				window.frame.setVisible(true);
				frame.dispose();
			}
		});
		button6.setForeground(Color.WHITE);
		button6.setBackground(Color.DARK_GRAY);
		button6.setBounds(0, 362, 244, 39);
		frame.getContentPane().add(button6);
		
		JButton button7 = new JButton("RAPORT FACTURI");
		button7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RAPFACTURI window = new RAPFACTURI();
				window.frame.setResizable(false);
				window. frame.setLocationRelativeTo(null);
				window.frame.setVisible(true);
				frame.dispose();
			}
		});
		button7.setForeground(Color.WHITE);
		button7.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 14));
		button7.setBackground(Color.DARK_GRAY);
		button7.setBounds(0, 462, 244, 39);
		frame.getContentPane().add(button7);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 0, 244, 861);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setBounds(0, 0, 241, -12);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(85, -1, 69, 58);
		panel.add(lblNewLabel);
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ADMIN_PAGE window = new ADMIN_PAGE();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		lblNewLabel.setIcon(new ImageIcon(RAPOARTE.class.getResource("/images/icons8-admin-48.png")));
		
		JLabel lblNewLabel_1 = new JLabel("Inapoi la admin");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setBounds(72, 56, 107, 18);
		panel.add(lblNewLabel_1);
	}

}
