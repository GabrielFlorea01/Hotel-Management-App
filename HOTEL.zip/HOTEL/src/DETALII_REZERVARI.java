import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.border.MatteBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;

public class DETALII_REZERVARI {

	JFrame frame;
	private JTextField textField1;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DETALII_REZERVARI window = new DETALII_REZERVARI();
					window.frame.setVisible(true);
					window.frame.setLocationRelativeTo(null);
					window.frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DETALII_REZERVARI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Cauta dupa data de check-in");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setBounds(498, 42, 223, 31);
		frame.getContentPane().add(lblNewLabel_1);
		
		textField1 = new JTextField();
		textField1.setFont(new Font("SansSerif", Font.PLAIN, 16));
		textField1.setColumns(10);
		textField1.setBounds(731, 44, 142, 27);
		frame.getContentPane().add(textField1);
		
		JButton btnNewButton1 = new JButton("CAUTA");
		btnNewButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
            String textFieldid = textField1.getText();
				
				if (textFieldid.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Completeaza data de Check-in !","Eroare !", JOptionPane.ERROR_MESSAGE);

				} else if (!textFieldid.matches("\\d{4}-\\d{2}-\\d{2}")) {
				    JOptionPane.showMessageDialog(null, "Te rog introdu un format de data valid (yyyy-MM-dd)!", "Eroare!", JOptionPane.ERROR_MESSAGE);
				}

				 else {

            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
            		PreparedStatement stmt = conn.prepareStatement("SELECT rezervare.IDRezervare, client.numeClient, rezervare.IDClient, rezervare.IDCamera, rezervare.IDSpa, rezervare.checkIN, rezervare.checkOUT, rezervare.numarPers, rezervare.statusRezerv "
            		        + "FROM hotel.rezervare "
            		        + "JOIN hotel.client ON client.IDClient = rezervare.IDClient "
            		        + "WHERE rezervare.checkIN = ?");)
            {
            	stmt.setString(1, textField1.getText());
                ResultSet rs =stmt.executeQuery();
                DefaultTableModel tm = (DefaultTableModel)table.getModel();
                tm.setRowCount(0);

                if (!rs.next()) {
                    JOptionPane.showMessageDialog(null, "Nu s-a gasit nicio rezervare !");
                    return;
                }

                do {
                    Object o[]= {rs.getInt("IDRezervare"),rs.getString("numeClient"),rs.getString("IDClient"),rs.getString("IDCamera"),rs.getString("IDSpa"), rs.getString("checkIN"),rs.getString("checkOUT"),rs.getString("numarPers"),rs.getString("statusRezerv")};
                    tm.addRow(o);
                } while (rs.next());
            } catch (SQLException e1) {
                e1.printStackTrace();
            }

				
			}
		}});
		
		btnNewButton1.setForeground(Color.DARK_GRAY);
		btnNewButton1.setFont(new Font("SansSerif", Font.BOLD, 15));
		btnNewButton1.setBackground(Color.LIGHT_GRAY);
		btnNewButton1.setBounds(893, 44, 89, 27);
		frame.getContentPane().add(btnNewButton1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane.setBounds(63, 275, 1427, 356);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Nume Client", "ID Client", "Nr. Camera", "Cod Spa", "Data Check-in", "Data Check-out", "Nr.Persoane", "Status rezervare"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(82);
		table.getColumnModel().getColumn(1).setPreferredWidth(93);
		table.getColumnModel().getColumn(3).setPreferredWidth(89);
		table.getColumnModel().getColumn(4).setPreferredWidth(85);
		table.getColumnModel().getColumn(5).setPreferredWidth(104);
		table.getColumnModel().getColumn(6).setPreferredWidth(118);
		
		JButton btnNewButton4 = new JButton("Sterge rezervarea selctata");
		btnNewButton4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton4.setForeground(Color.red);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton4.setForeground(Color.darkGray);
			}
		});
		btnNewButton4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				        // se ia index-ul tableului 
				
				        int selectedRow = table.getSelectedRow();

				        // se afiseaza eroare daca nu a fost selectat nimic
				        
				        if (selectedRow == -1) {
				            JOptionPane.showMessageDialog(null, "Selecteaza o rezervare!", "Eroare!", JOptionPane.ERROR_MESSAGE);
				            return;
				        }

				        // se ia ID-ul rezervarii selectate
				        
				        int IDRezervare = (int) table.getValueAt(selectedRow, 0);

				        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "Gabriel01");
				        	     PreparedStatement stmt = conn.prepareStatement("DELETE FROM facturi WHERE IDRezervare = ?");
				        	     PreparedStatement stmt2 = conn.prepareStatement("DELETE FROM rezervare WHERE IDRezervare = ?");
				        	     PreparedStatement stmt3 = conn.prepareStatement("UPDATE camera SET statusCamera = 'Libera' WHERE IDCamera = (SELECT IDCamera FROM rezervare WHERE IDRezervare = ?)")) {

				        	    stmt.setInt(1, IDRezervare);
				        	    int rowsFacturi = stmt.executeUpdate();

				        	    stmt2.setInt(1, IDRezervare);
				        	    int rowsRezervare = stmt2.executeUpdate();

				        	    stmt3.setInt(1, IDRezervare);
				        	    int rowsCamera = stmt3.executeUpdate();

				        	    if (rowsRezervare > 0) {
				        	        JOptionPane.showMessageDialog(null, "Rezervarea a fost stearsa!");
				        	    } else {
				        	        JOptionPane.showMessageDialog(null, "Nu s-a putut sterge rezervarea!", "Eroare!", JOptionPane.ERROR_MESSAGE);
				        	    }
				        	    
				        } catch (SQLException ex) {
				            ex.printStackTrace();
				        }
				    }
				});
		
		
		btnNewButton4.setForeground(Color.DARK_GRAY);
		btnNewButton4.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 14));
		btnNewButton4.setBackground(Color.LIGHT_GRAY);
		btnNewButton4.setBounds(1260, 657, 230, 27);
		frame.getContentPane().add(btnNewButton4);
		
		JButton btnConfirmaRezervarea = new JButton("Confirma rezervarea selctata ");
		btnConfirmaRezervarea.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnConfirmaRezervarea.setForeground(Color.green);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnConfirmaRezervarea.setForeground(Color.darkGray);
			}
		});
		
		btnConfirmaRezervarea.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				 int selectedRow = table.getSelectedRow();

			        // daca nu este selectat nimic se afiseaza eroare
			        
				 if (selectedRow == -1) {
			            JOptionPane.showMessageDialog(null, "Selecteaza o rezervare!", "Eroare!", JOptionPane.ERROR_MESSAGE);
			            return;
			        }

			        // se ia ID-ul rezervarii selectate din tabel
			        
				    int IDRezervare = (int) table.getValueAt(selectedRow, 0);
			        String statusRezerv = (String) table.getValueAt(selectedRow, 8);

			        if (statusRezerv.equalsIgnoreCase("CONFIRMAT")) {
			            JOptionPane.showMessageDialog(null, "Rezervarea este deja confirmata!");
			            return;
			        }


			        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "Gabriel01");
			             PreparedStatement stmt = conn.prepareStatement("UPDATE rezervare SET statusRezerv = 'CONFIRMAT' WHERE IDRezervare = ?");
			        		PreparedStatement stmt2 = conn.prepareStatement("UPDATE camera c " +
                                    "JOIN rezervare r ON c.IDCamera = r.IDCamera " +
                                    "SET c.statusCamera = 'Ocupata' " +
                                    "WHERE r.IDRezervare = ?");) 
			        
			        {
			        	 
			        	// se seteaza ID-ul rezervarii in query
			            
			        	stmt.setInt(1, IDRezervare);
			        	stmt2.setInt(1, IDRezervare);

			            // se exectuta query
			            
			        	int rowsUpdated = stmt.executeUpdate();
			        	int rowsUpdated2= stmt2.executeUpdate();

			            if (rowsUpdated > 0  && rowsUpdated2 > 0) {
			                JOptionPane.showMessageDialog(null, "Rezervarea a fost confirmata!");
			            } else {
			                JOptionPane.showMessageDialog(null, "Nu s-a putut confirma rezervarea!", "Eroare!", JOptionPane.ERROR_MESSAGE);
			            }
			        } catch (SQLException ex) {
			            ex.printStackTrace();
			        }
			    }
			});
		
		btnConfirmaRezervarea.setForeground(Color.DARK_GRAY);
		btnConfirmaRezervarea.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		btnConfirmaRezervarea.setBackground(Color.LIGHT_GRAY);
		btnConfirmaRezervarea.setBounds(63, 669, 261, 27);
		frame.getContentPane().add(btnConfirmaRezervarea);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DASHBOARD window = new DASHBOARD();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
			
		});
		
		lblNewLabel.setIcon(new ImageIcon(DETALII_REZERVARI.class.getResource("/images/icons8-home-page-48.png")));
		lblNewLabel.setBounds(1478, 11, 46, 39);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnArataRezervarile = new JButton("Arata rezervarile");
		btnArataRezervarile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
		            		PreparedStatement stmt = conn.prepareStatement("SELECT rezervare.IDRezervare, client.numeClient, rezervare.IDClient, rezervare.IDCamera, rezervare.IDSpa, rezervare.checkIN, rezervare.checkOUT, rezervare.numarPers, rezervare.statusRezerv "
		            		        + "FROM hotel.rezervare "
		            		        + "JOIN hotel.client ON client.IDClient = rezervare.IDClient ");)
		            {
		            	
		                ResultSet rs =stmt.executeQuery();
		                DefaultTableModel tm = (DefaultTableModel)table.getModel();
		                tm.setRowCount(0);

		                if (!rs.next()) {
		                    JOptionPane.showMessageDialog(null, "Nu s-a gasit nicio rezervare !");
		                    return;
		                }

		                do {
		                    Object o[]= {rs.getInt("IDRezervare"),rs.getString("numeClient"),rs.getString("IDClient"),rs.getString("IDCamera"),rs.getString("IDSpa"), rs.getString("checkIN"),rs.getString("checkOUT"),rs.getString("numarPers"),rs.getString("statusRezerv")};
		                    tm.addRow(o);
		                } while (rs.next());
		            } catch (SQLException e1) {
		                e1.printStackTrace();
		            }
			}
		});
		
		btnArataRezervarile.setForeground(Color.DARK_GRAY);
		btnArataRezervarile.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		btnArataRezervarile.setBackground(Color.LIGHT_GRAY);
		btnArataRezervarile.setBounds(63, 237, 156, 27);
		frame.getContentPane().add(btnArataRezervarile);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DETALII_REZERVARI window = new DETALII_REZERVARI();
				window.frame.setVisible(true);
				window.frame.setLocationRelativeTo(null);
				window.frame.setResizable(false);
				frame.dispose();
			}
		});
		lblNewLabel_2.setIcon(new ImageIcon(DETALII_REZERVARI.class.getResource("/images/icons8-update-left-rotation-24.png")));
		lblNewLabel_2.setBounds(1500, 826, 24, 24);
		frame.getContentPane().add(lblNewLabel_2);
		frame.setBounds(100, 100, 1550, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
