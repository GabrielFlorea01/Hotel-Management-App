import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;

import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.HorizontalAlignment;
import com.itextpdf.layout.properties.TextAlignment;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class RAPSPA {

	JFrame frame;
	private JSpinner startSpinner;
	private JSpinner endSpinner;
	private JTable table_1;
 

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RAPSPA window = new RAPSPA();
					window.frame.setResizable(false);
					window. frame.setLocationRelativeTo(null);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RAPSPA() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setForeground(Color.DARK_GRAY);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 1550, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
	 SpinnerDateModel startModel = new SpinnerDateModel();
        startSpinner = new JSpinner(startModel);
        startSpinner.setFont(new Font("Arial", Font.BOLD, 15));
        startSpinner.setBounds(501, 43, 115, 33); 
        startSpinner.setEditor(new JSpinner.DateEditor(startSpinner, "MM/dd/yyyy"));
        frame.getContentPane().add(startSpinner);
        
    
        SpinnerDateModel endModel = new SpinnerDateModel();
        endSpinner = new JSpinner(endModel);
        endSpinner.setFont(new Font("Arial", Font.BOLD, 15));
        endSpinner.setBounds(829, 43, 115, 33); 
        endSpinner.setEditor(new JSpinner.DateEditor(endSpinner, "MM/dd/yyyy"));
        frame.getContentPane().add(endSpinner);
        
        JLabel lblNewLabel_1_1 = new JLabel("DATA INCEPUT");
 		lblNewLabel_1_1.setForeground(Color.DARK_GRAY);
 		lblNewLabel_1_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
 		lblNewLabel_1_1.setBounds(501, 11, 181, 21);
 		frame.getContentPane().add(lblNewLabel_1_1);
 		
 		JLabel lblNewLabel_1_1_1 = new JLabel("DATA FINAL");
 		lblNewLabel_1_1_1.setForeground(Color.DARK_GRAY);
 		lblNewLabel_1_1_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 16));
 		lblNewLabel_1_1_1.setBounds(835, 11, 181, 21);
 		frame.getContentPane().add(lblNewLabel_1_1_1);
 		
 		JLabel lblNewLabel_1 = new JLabel("RAPORT SERVICII SPA");
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel_1.setBounds(10, 11, 214, 21);
		frame.getContentPane().add(lblNewLabel_1);
			
		
		JButton button2 = new JButton("AFISEAZA RAPORT");
		button2.setForeground(Color.DARK_GRAY);
		button2.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 14));
		button2.setBackground(Color.LIGHT_GRAY);
		button2.setBounds(647, 268, 181, 27);
		frame.getContentPane().add(button2);
		
		JRadioButton radioButton1 = new JRadioButton("Afisare rezervari cu spa");
		radioButton1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
		radioButton1.setBounds(117, 180, 187, 23);
		frame.getContentPane().add(radioButton1);
		
		JRadioButton radioButton2 = new JRadioButton("Afisare cel mai popular tip de spa");
		radioButton2.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
		radioButton2.setBounds(347, 180, 233, 23);
		frame.getContentPane().add(radioButton2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(117, 331, 1288, 375);
		frame.getContentPane().add(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		
		JButton button3 = new JButton("Print");
		button3.setForeground(Color.DARK_GRAY);
		button3.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 14));
		button3.setBackground(Color.LIGHT_GRAY);
		button3.setBounds(1290, 714, 115, 21);
		frame.getContentPane().add(button3);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				RAPOARTE window = new RAPOARTE();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		lblNewLabel.setIcon(new ImageIcon(RAPSPA.class.getResource("/images/icons8-home-page-48.png")));
		lblNewLabel.setBounds(1478, 11, 46, 43);
		frame.getContentPane().add(lblNewLabel);
		
		JButton button4 = new JButton("");
		button4.setBackground(Color.LIGHT_GRAY);
		button4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RAPSPA window = new RAPSPA();
				window.frame.setResizable(false);
				window. frame.setLocationRelativeTo(null);
				window.frame.setVisible(true);
				frame.dispose();
				
			}
		});
		button4.setIcon(new ImageIcon(RAPSPA.class.getResource("/images/icons8-update-left-rotation-24.png")));
		button4.setBounds(1485, 823, 39, 27);
		frame.getContentPane().add(button4);
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				generateReport();
			}
		});

	}
	
		private void generateReport() {
	        try {
	            
	            Class.forName("com.mysql.cj.jdbc.Driver");
	
	            
	            String url = "jdbc:mysql://localhost:3306/hotel";
	            String username = "root";
	            String password = "Gabriel01";
	            Connection conn = DriverManager.getConnection(url, username, password);
	
	            
	           
	            Date startDate = (Date) startSpinner.getValue();
	            Date endDate = (Date) endSpinner.getValue();
	            SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
	        	String formattedsStart = dateFormatter.format(startDate);
				String formattedEnd = dateFormatter.format(endDate);
	            
				String sql = "SELECT s.descriere, COUNT(*) AS total_rezervari " +
			                "FROM istoric_rezervari ir " +
			                "INNER JOIN spa s ON ir.idspa = s.IDSpa " +
			                "WHERE ir.checkin BETWEEN ? AND ? OR ir.checkout BETWEEN ? AND ? " +
			                "GROUP BY s.descriere " +
			                "ORDER BY total_rezervari DESC";

			        PreparedStatement stmt = conn.prepareStatement(sql);
			        stmt.setDate(1, new java.sql.Date(startDate.getTime()));
			        stmt.setDate(2, new java.sql.Date(endDate.getTime()));
			        stmt.setDate(3, new java.sql.Date(startDate.getTime()));
			        stmt.setDate(4, new java.sql.Date(endDate.getTime()));
			        ResultSet rs1 = stmt.executeQuery();
		            
		            
			        // Query cel mai popular tip de spa ales 
			        
			        String query2 = "SELECT s.descriere " +
			                "FROM istoric_rezervari ir " +
			                "INNER JOIN spa s ON ir.idspa = s.IDSpa " +
			                "WHERE ir.checkin BETWEEN ? AND ? OR ir.checkout BETWEEN ? AND ? " +
			                "GROUP BY s.descriere " +
			                "ORDER BY COUNT(*) DESC " +
			                "LIMIT 1";

			        PreparedStatement stmt2 = conn.prepareStatement(query2);
			        stmt2.setDate(1, new java.sql.Date(startDate.getTime()));
			        stmt2.setDate(2, new java.sql.Date(endDate.getTime()));
			        stmt2.setDate(3, new java.sql.Date(startDate.getTime()));
			        stmt2.setDate(4, new java.sql.Date(endDate.getTime()));
			        ResultSet rs2 = stmt2.executeQuery();
			       
			        
		            SimpleDateFormat dateFormatter2 = new SimpleDateFormat("yyyy-MM-dd");
		            String timeStamp = dateFormatter2.format(startDate);
	
		            String filePath = "C:\\Users\\Gabi\\Desktop\\rapoarte_hotel\\"; 
		            String fileName = filePath + "Raport_spa_" + timeStamp + ".pdf";
				
	
			        PdfWriter writer = new PdfWriter(new FileOutputStream(fileName));
			        PdfDocument pdf = new PdfDocument(writer);
			        Document document = new Document(pdf, PageSize.A4);
	
		            
		            Paragraph title = new Paragraph("RAPORT REZERVARE SPA/PISCINA");
		            title.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
		            document.add(title);
	
		            
		            Paragraph perioada = new Paragraph("Perioada raportului: " + formattedsStart.toString() + " - " + formattedEnd.toString());
		            perioada.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
		            document.add(perioada);
	
		            
		            
		            Table table = new Table(2);
		            table.addCell("Cod Rezervare");
		            table.addCell("Tip");
		            table.setHorizontalAlignment(HorizontalAlignment.CENTER);
		            table.setMarginBottom(20);
		            
		            while (rs1.next()) {
		                String descriereSpa = rs1.getString("descriere");
		                
		                            
		                String sql2 = "SELECT ir.idrezervare, ir.idspa, s.descriere " +
		                              "FROM istoric_rezervari ir " +
		                              "INNER JOIN spa s ON ir.idspa = s.IDSpa " +
		                              "WHERE (ir.checkin BETWEEN ? AND ? OR ir.checkout BETWEEN ? AND ?) " +
		                              "AND s.descriere = ?";
		                            
		                PreparedStatement stmt3 = conn.prepareStatement(sql2);
		                stmt3.setDate(1, new java.sql.Date(startDate.getTime()));
		                stmt3.setDate(2, new java.sql.Date(endDate.getTime()));
		                stmt3.setDate(3, new java.sql.Date(startDate.getTime()));
		                stmt3.setDate(4, new java.sql.Date(endDate.getTime()));
		                stmt3.setString(5, descriereSpa);
		                ResultSet rs3 = stmt3.executeQuery();

		                while (rs3.next()) {
		                    int idRezervare = rs3.getInt("idrezervare");
		                    String descriere = rs3.getString("descriere");
		                    table.addCell(Integer.toString(idRezervare));
		                    table.addCell(descriere);
		                }
		            }

		            
		          

		            
		            document.add(table);

		            if (rs2.next()) {
		            	
		                String celmaialesTip = rs2.getString("descriere");
		                Paragraph celmaiales = new Paragraph("Cel mai rezervat tip in perioada " + formattedsStart.toString() 
			            + " - " + formattedEnd.toString() + " este: " + celmaialesTip);
			            celmaiales.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15);
			            document.add(celmaiales);
		                
		            }
		           

		            document.close();

		            JOptionPane.showMessageDialog(null, "Raport realizat!");
		            
		          } catch (Exception e) {
		            e.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Eroare la generarea raportului!");
		        }
	        
		}

	
	
	
}
