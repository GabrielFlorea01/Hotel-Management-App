import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Label;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.StyleConstants.FontConstants;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.image.LookupTable;
import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

import java.io.FileOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.PatternSyntaxException;

import com.itextpdf.io.exceptions.IOException;
import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.List;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.properties.HorizontalAlignment;
import com.itextpdf.layout.properties.TextAlignment;
import java.awt.Toolkit;
import java.awt.Window.Type;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;








public class CHECK_OUT {

	JFrame frame;
	private JTextField textField;
	private JTextField textField1;
	private JTextField textField2;
	private JTextField textField3;
	private JTextField textField4;
	private JTextField textField5;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	private JTable table;
	private JScrollPane scrollPane;
	private JLabel lblNewLabel_2;
	private JTextField textField6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CHECK_OUT window = new CHECK_OUT();
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CHECK_OUT() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.getContentPane().setFont(new Font("SansSerif", Font.PLAIN, 14));
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 1550, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		Label label_1 = new Label("Introdu numarul camerei ");
		label_1.setBounds(550, 39, 195, 22);
		label_1.setForeground(Color.DARK_GRAY);
		label_1.setFont(new Font("Leelawadee UI", Font.BOLD | Font.ITALIC, 16));
		frame.getContentPane().add(label_1);
		
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setBounds(751, 39, 105, 22);
		textField.setFont(new Font("SansSerif", Font.BOLD, 15));
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("CAUTA");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String nrcamera=textField.getText();
				
				
				String textFieldValue = textField.getText();
				if (textFieldValue.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Completeaza numarul camerei !","Eroare !", JOptionPane.ERROR_MESSAGE);
					
				} else if (!textFieldValue.matches("\\d+")) {
					JOptionPane.showMessageDialog(null, "Te rog intorodu un numar valabil  !", "Eroare !", JOptionPane.ERROR_MESSAGE);
					textField.setText("");
					
				} else {
					
					try  (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");)
					{
						
						// se selecteaza toate datele din tabelul rezervare
						
						PreparedStatement stmt = conn.prepareStatement("SELECT * FROM hotel.rezervare WHERE IDCamera= ?");
						stmt.setString(1, nrcamera);
						ResultSet rs =stmt.executeQuery();
						if (rs.next()) 
						{
								DefaultTableModel tm = (DefaultTableModel)table.getModel();
								tm.setRowCount(0);
			                 	Object o[]= {rs.getInt("IDRezervare"),rs.getString("IDClient"),rs.getString("IDCamera"),rs.getString("IDSpa"), rs.getString("checkIN"),rs.getString("checkOUT"),rs.getString("numarPers"),rs.getString("statusRezerv")};
							    tm.addRow(o);
							    
							 // se selecteaza numele clientului de pe camera respectiva
								
								PreparedStatement stmt2 = conn.prepareStatement("SELECT client.numeClient "
						                 + "FROM client "
						                 + "JOIN rezervare ON client.IDClient = rezervare.IDClient "
						                 + "JOIN camera ON rezervare.IDCamera = camera.IDCamera "
						                 + "WHERE camera.IDCamera = ?");
								
								int numcamera = Integer.parseInt(textField.getText());
								stmt2.setInt(1, numcamera);
							    ResultSet rs2 = stmt2.executeQuery();
								    if (rs2.next()) {
								        String numeclient = rs2.getString("numeClient");
								        textField1.setText(numeclient);}
								        
								 // se selecteaza data de check-in
			
								  PreparedStatement stmt3 = conn.prepareStatement("SELECT checkIN FROM rezervare WHERE IDCamera = ?");
								    int roomno = Integer.parseInt(textField.getText());
								    stmt3.setInt(1, roomno);
								    ResultSet rs3 = stmt3.executeQuery();
								    if (rs3.next()) {
								        Date checkIn = rs3.getDate("checkIN");
								        textField2.setText(checkIn.toString());}
								    
								    // se arata pretul pe noapte in functie de camera aleasa
								    
								    PreparedStatement stmt4 = conn.prepareStatement("SELECT pretCamera FROM camera WHERE IDCamera = ?");
								    int numarcamera = Integer.parseInt(textField.getText());
								    stmt4.setInt(1, numarcamera);
								    ResultSet rs4 = stmt4.executeQuery();
								    if (rs4.next()) {
								        Integer pretcam = rs4.getInt("pretCamera");
								        textField3.setText(pretcam.toString());}
								        
								     // se calculeaza numarul de nopti
			
								    PreparedStatement stmt5 = conn.prepareStatement("SELECT checkIN, checkOUT FROM rezervare WHERE IDCamera = ?");
								    int numarcam = Integer.parseInt(textField.getText());
								    stmt5.setInt(1, numarcam);
								    ResultSet rs5 = stmt5.executeQuery();
								    if (rs5.next()) {
								        Date dataCheckIn = rs5.getDate("checkIN");
								        Date dataCheckOut = rs5.getDate("checkOUT");
								        
								        
								       
								        
								        // se calculeaza nr de nopti
								      
								        long millisecondsPerDay = 24 * 60 * 60 * 1000;
								        long nights = (dataCheckOut.getTime() - dataCheckIn.getTime()) / millisecondsPerDay;
								        textField4.setText(Long.toString(nights));}
								    

								       // CALCULAREA TOTALULUI
								    int numcam = Integer.parseInt(textField.getText()); 
								    PreparedStatement stmt6 = conn.prepareStatement("SELECT * FROM rezervare WHERE IDCamera = " + numcam);
								    ResultSet rs6 = stmt6.executeQuery();
								    rs6.next();

								 //  se iau datele de check-in si check-out
								    
								 Date checkInDate = rs6.getDate("checkIN");
								 Date checkOutDate = rs6.getDate("checkOUT");

								 // se calculeaza costul de sejur
								 
								 long millisecondsPerDay = 24 * 60 * 60 * 1000;
								 long nopti = (checkOutDate.getTime() - checkInDate.getTime()) / millisecondsPerDay;
								 long pretcamera=Long.parseLong(textField3.getText());
								 long totalsejur = nopti * pretcamera;
								 
								 

								

								 // se adauga la total valoarea spa-ului
								 
								 PreparedStatement stmt8 = conn.prepareStatement("SELECT spa.pretSpa "
								 		+ "FROM rezervare "
								 		+ "JOIN spa ON rezervare.IDSpa = spa.IDSpa "
								 		+ "WHERE rezervare.IDCamera = " + numcam);
								 
								 ResultSet rs8 = stmt8.executeQuery();
								 float pretspa = 0;
								 while (rs8.next()) {
								    pretspa += rs8.getLong("pretSpa");
								 }

								 // SE CALULEAZA TOTALUL SI SE AFISEAZA
								float totalspa = pretspa* nopti;
								
								long totalmasa = 0;
								
								//se extrage totalul de la restaurant
						        
						        PreparedStatement stmtGETtotalmasa = conn.prepareStatement("SELECT SUM(p.pret * r.cantitate) AS pret_total " +
							             "FROM restaurant r " +
							             "INNER JOIN preparate p ON r.IDPreparat = p.IDPreparat " +
							             "WHERE r.IDMasa = ?");
						        
						        stmtGETtotalmasa.setInt(1, numarcam);
							    ResultSet rsm = stmtGETtotalmasa.executeQuery();
							    if (rsm.next()) {
							    	 
							         totalmasa = rsm.getLong("pret_total");   
							    }
							    
							    
							    // se dauga la TOTAL( fara TVA) in textfield.
							    
								float Total = totalsejur + totalspa + totalmasa;
								textField5.setText(String.valueOf(Total));
								
								
								// se dauga la TOTAL(cu TVA) in textfield.
								
								double TVA = 0.09;
								double TVAAmount = Total * TVA;
								double pretTotal = Total + TVAAmount;
								textField6.setText(String.valueOf(pretTotal));
								
								
								// se da enable la butonul de check-out
								
								btnNewButton_2.setEnabled(true);
								 
			
						       } else  {JOptionPane.showMessageDialog(null,"Nu exista rezervare pe aceasta camera !");}
						
						
					} catch (Exception e1) {
						e1.printStackTrace();
							        }
		
					
				}
				
			}
		});
		
		
		btnNewButton.setBounds(861, 39, 94, 23);
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.setForeground(Color.DARK_GRAY);
		btnNewButton.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Numele clientului");
		lblNewLabel.setBounds(42, 181, 138, 15);
		lblNewLabel.setForeground(Color.DARK_GRAY);
		lblNewLabel.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		frame.getContentPane().add(lblNewLabel);
		
		textField1 = new JTextField();
		textField1.setEditable(false);
		textField1.setHorizontalAlignment(SwingConstants.CENTER);
		textField1.setBounds(174, 178, 204, 23);
		textField1.setFont(new Font("Arial", Font.BOLD, 14));
		textField1.setText("");
		frame.getContentPane().add(textField1);
		textField1.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Data de check-in");
		lblNewLabel_1.setBounds(443, 181, 121, 14);
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("Pretul pe noapte");
		lblNewLabel_3.setBounds(1139, 177, 131, 22);
		lblNewLabel_3.setForeground(Color.DARK_GRAY);
		lblNewLabel_3.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 15));
		frame.getContentPane().add(lblNewLabel_3);
		
		textField2 = new JTextField();
		textField2.setEditable(false);
		textField2.setHorizontalAlignment(SwingConstants.CENTER);
		textField2.setBounds(574, 177, 204, 23);
		textField2.setFont(new Font("SansSerif", Font.BOLD, 14));
		frame.getContentPane().add(textField2);
		textField2.setColumns(10);
		
		textField3 = new JTextField();
		textField3.setHorizontalAlignment(SwingConstants.CENTER);
		textField3.setEditable(false);
		textField3.setBounds(1271, 177, 170, 23);
		textField3.setFont(new Font("SansSerif", Font.BOLD, 14));
		frame.getContentPane().add(textField3);
		textField3.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Numar de nopti");
		lblNewLabel_4.setBounds(840, 181, 115, 14);
		lblNewLabel_4.setForeground(Color.DARK_GRAY);
		lblNewLabel_4.setFont(new Font("SansSerif", Font.BOLD, 15));
		frame.getContentPane().add(lblNewLabel_4);
		
		textField4 = new JTextField();
		textField4.setHorizontalAlignment(SwingConstants.CENTER);
		textField4.setEditable(false);
		textField4.setBounds(958, 177, 86, 23);
		textField4.setFont(new Font("SansSerif", Font.BOLD, 14));
		frame.getContentPane().add(textField4);
		textField4.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("TOTAL DE PLATA (CU TVA)");
		lblNewLabel_5.setBounds(992, 323, 229, 14);
		lblNewLabel_5.setForeground(Color.DARK_GRAY);
		lblNewLabel_5.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 16));
		frame.getContentPane().add(lblNewLabel_5);
		
		textField5 = new JTextField();
		textField5.setHorizontalAlignment(SwingConstants.CENTER);
		textField5.setEditable(false);
		textField5.setBounds(401, 320, 156, 21);
		textField5.setFont(new Font("SansSerif", Font.BOLD, 16));
		frame.getContentPane().add(textField5);
		textField5.setColumns(10);
		
		btnNewButton_2 = new JButton("CHECK-OUT");
		btnNewButton_2.setEnabled(false);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String numeclient=null;
				String telefon=null;
				String emailclient=null;
				String tipcamera=null;
				String strada=null;
		    	String oras=null;
		    	String numar=null;
		    	String tara=null;
				int pretcam=-1;
				int idrezervare = -1;
				int idclient = -1;
				int idcamera= -1;
				int idspa= -1;
				int idfactura= -1;
				Date checkin = null;
				Date checkout = null;
				int numarpers= -1;
				float totalmasa = 0;
				int number = 0;
				int numberspa=0;
				
				
				// se face procesul de check-out in cazul in care camera a fost gasita cu rezervare
				// se extrag toate datele necesare
				
				String textFieldValue = textField.getText();
				
			
				int nrcamera = Integer.parseInt(textFieldValue);
	
				try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");) 
				{
					
					PreparedStatement stmtGETallrezervare= conn.prepareStatement("SELECT * FROM hotel.rezervare WHERE IDCamera= ?");
					stmtGETallrezervare.setInt(1, nrcamera);
					ResultSet rs9= stmtGETallrezervare.executeQuery();
					while (rs9.next()) {
						idrezervare= rs9.getInt("IDRezervare");
						idclient= rs9.getInt("IDClient");
						idcamera=rs9.getInt("IDCamera");
						idspa=rs9.getInt("IDSpa");
						checkin=rs9.getDate("checkIN");
						checkout=rs9.getDate("checkOUT");
						numarpers=rs9.getInt("numarPers");
						
						
						
					}
					
					
					
					long millisecondsPerDay = 24 * 60 * 60 * 1000;
					long nopti = (checkout.getTime() - checkin.getTime()) / millisecondsPerDay;
					
				    PreparedStatement stmtGETfactura = conn.prepareStatement("SELECT IDFactura FROM facturi "
				    		+ "INNER JOIN rezervare ON facturi.IDClient = rezervare.IDClient "
				    		+ "WHERE rezervare.IDCamera = ?"); 
				    
				    stmtGETfactura.setInt(1, nrcamera);
				    ResultSet rs11 =stmtGETfactura.executeQuery();
				    if (rs11.next()) {
					     idfactura = rs11.getInt("IDFactura");
					}
			
			
					PreparedStatement stmtGETclient = conn.prepareStatement("SELECT client.numeClient FROM client "
							+ "JOIN rezervare ON client.IDClient = rezervare.IDClient "
							+ "JOIN camera ON rezervare.IDCamera = camera.IDCamera "
							+ "WHERE camera.IDCamera = ?");
					stmtGETclient.setInt(1, nrcamera);
					ResultSet rs10 = stmtGETclient.executeQuery();
					    if (rs10.next()) {
					          numeclient = rs10.getString("numeClient");}
					    
					    PreparedStatement stmtGETemail = conn.prepareStatement("SELECT client.emailClient FROM client "
								+ "JOIN rezervare ON client.IDClient = rezervare.IDClient "
								+ "JOIN camera ON rezervare.IDCamera = camera.IDCamera "
								+ "WHERE camera.IDCamera = ?");
						stmtGETemail.setInt(1, nrcamera);
						ResultSet rs12 = stmtGETemail.executeQuery();
						    if (rs12.next()) {
						           emailclient = rs12.getString("emailClient");  
						          
						    }
						    
						    
						    PreparedStatement stmtGETtelefon = conn.prepareStatement("SELECT client.telefonClient FROM client "
									+ "JOIN rezervare ON client.IDClient = rezervare.IDClient "
									+ "JOIN camera ON rezervare.IDCamera = camera.IDCamera "
									+ "WHERE camera.IDCamera = ?");
							stmtGETtelefon.setInt(1, nrcamera);
							ResultSet rs16 = stmtGETtelefon.executeQuery();
							    if (rs16.next()) {
							           telefon = rs16.getString("telefonClient");
					
							    }
						    
						  
							    PreparedStatement stmtGETadresa = conn.prepareStatement("SELECT client.adresa_strada, client.adresa_oras, client.adresa_numar, client.adresa_tara FROM client "
										+ "JOIN rezervare ON client.IDClient = rezervare.IDClient "
										+ "JOIN camera ON rezervare.IDCamera = camera.IDCamera "
										+ "WHERE camera.IDCamera = ?");
								stmtGETadresa.setInt(1, nrcamera);
								ResultSet rs17 = stmtGETadresa.executeQuery();
								    if (rs17.next()) {
								    	
								    	  strada = rs17.getString("adresa_strada");
								    	  oras = rs17.getString("adresa_oras");
								    	  numar =rs17.getString("adresa_numar");
								    	  tara = rs17.getString("adresa_tara");
						
								    }
								    
								    
							PreparedStatement stmtPretcamera = conn.prepareStatement("SELECT tipCamera, pretCamera FROM camera WHERE IDCamera = ?");
						    stmtPretcamera.setInt(1, nrcamera);
						    ResultSet rs14 = stmtPretcamera.executeQuery();
						    if (rs14.next()) {
						    	tipcamera =rs14.getString("tipCamera");
						        pretcam = rs14.getInt("pretCamera");}
						    
						        
						   PreparedStatement stmtPretspa = conn.prepareStatement("SELECT spa.pretSpa "
								 		+ "FROM rezervare "
								 		+ "JOIN spa ON rezervare.IDSpa = spa.IDSpa "
								 		+ "WHERE rezervare.IDCamera = ?");
						    stmtPretspa.setInt(1, nrcamera);
						    ResultSet res = stmtPretspa.executeQuery();
							float pretspa = (float) 0;
							while (res.next()) {
								  pretspa += res.getFloat("pretSpa");
								 }
							
							PreparedStatement stmtGETSpa = conn.prepareStatement("SELECT IDSpa FROM rezervare WHERE IDCamera = ?");
							stmtGETSpa.setInt(1, nrcamera);
							ResultSet rsSpa = stmtGETSpa.executeQuery();

							if (rsSpa.next()) {
							    int spaid = rsSpa.getInt("IDSpa");
							    if (spaid == 1 || spaid == 2 || spaid == 3) {
							        numberspa = 1;
							    } else if (spaid == 4) {
							        numberspa = 0;
							    }
							 }
							

							
							
							PreparedStatement stmtINSERTfacutra = conn.prepareStatement("INSERT INTO facturi(datafactura, TotalfaraTVA, TotalcuTVA) VALUES (?, ?, ?)");
						    stmtINSERTfacutra.setDate(1, checkout); 
						    stmtINSERTfacutra.setFloat(2, Float.parseFloat(textField5.getText()));
						    stmtINSERTfacutra.setFloat(3, Float.parseFloat(textField6.getText()));
						    
						    
						    PreparedStatement stmtGETtotalmasa = conn.prepareStatement("SELECT SUM(p.pret * r.cantitate) AS pret_total " +
						             "FROM restaurant r " +
						             "INNER JOIN preparate p ON r.IDPreparat = p.IDPreparat " +
						             "WHERE r.IDMasa = ?");
						    
						    stmtGETtotalmasa.setInt(1, nrcamera);
						    ResultSet rs = stmtGETtotalmasa.executeQuery();
						    if (rs.next()) {
						         totalmasa = rs.getFloat("pret_total");   
						    }
						    
						    PreparedStatement stmtGETcantitate = conn.prepareStatement("SELECT COUNT(*) AS preparat_count " +
                                    "FROM restaurant r " +
                                    "WHERE r.IDMasa = ?");

								stmtGETcantitate.setInt(1, nrcamera);
								ResultSet rscant = stmtGETcantitate.executeQuery();
								if (rscant.next()) {
									
								int preparatCount = rscant.getInt("preparat_count");
								
								if (preparatCount > 0) {
								number = 1;
								} else {
									
								number = 0;}
								}
						 
						    PreparedStatement stmtGETmasa = conn.prepareStatement("SELECT * FROM restaurant WHERE IDMasa= ?");
						    stmtGETmasa.setInt(1, nrcamera);
						    ResultSet rSet = stmtGETmasa.executeQuery();

						    if (rSet.next()) { 
						        PreparedStatement stmtistoristoricRestaurant = conn.prepareStatement("INSERT INTO istoric_restaurant (idmasa, idpreparat, datapreparat, cantitate, totalincasat) VALUES (?,?,?,?,?)");

						        do {
						            int idPreparat = rSet.getInt("IDPreparat");
						            Date dataPreparat = rSet.getDate("datapreparat");
						            int cantitate = rSet.getInt("cantitate");
						            stmtistoristoricRestaurant.setInt(1, nrcamera);
						            stmtistoristoricRestaurant.setInt(2, idPreparat);
						            stmtistoristoricRestaurant.setDate(3, dataPreparat);
						            stmtistoristoricRestaurant.setInt(4, cantitate);
						            stmtistoristoricRestaurant.setFloat(5, totalmasa);
						            stmtistoristoricRestaurant.executeUpdate();
						        } while (rSet.next()); 
						    }

						    
				
						    
					    PreparedStatement stmtistoricRezervare = conn.prepareStatement("INSERT INTO istoric_rezervari "
					    	    + "(idrezervare, idclient, "
					    	    + "numeclient, idcamera, tipcamera, idspa, "
					    	    + "idfactura, checkin, checkout, numarpers, TOTALincasare) "
					    	    + "VALUES (?,?,?,?,?,?,?,?,?,?,?) ");
					    
					    	stmtistoricRezervare.setInt(1, idrezervare);
					    	stmtistoricRezervare.setInt(2, idclient);
							stmtistoricRezervare.setString(3, numeclient);
					    	stmtistoricRezervare.setInt(4, idcamera);
					    	stmtistoricRezervare.setString(5, tipcamera);
					    	stmtistoricRezervare.setInt(6, idspa);
					    	stmtistoricRezervare.setInt(7, idfactura);
					    	stmtistoricRezervare.setDate(8, checkin);
					    	stmtistoricRezervare.setDate(9, checkout);
					    	stmtistoricRezervare.setInt(10, numarpers);
					    	stmtistoricRezervare.setFloat(11, Float.parseFloat(textField6.getText()));
					    	stmtistoricRezervare.executeUpdate();

					    	
	
	                // se face stergerea
					    	
					
					 PreparedStatement stmtcheckout = conn.prepareStatement("DELETE FROM facturi WHERE IDCamera= ?");
				     stmtcheckout.setInt(1, nrcamera);
					 stmtcheckout.executeUpdate();
					 
					PreparedStatement stmtcheckout3= conn.prepareStatement("DELETE FROM restaurant WHERE IDMasa= ?");
					stmtcheckout3.setInt(1, nrcamera);
					stmtcheckout3.executeUpdate();
					
					PreparedStatement stmtcheckout2 = conn.prepareStatement("DELETE FROM rezervare WHERE IDCamera= ?");
				    stmtcheckout2.setInt(1, nrcamera);
					stmtcheckout2.executeUpdate();
					
					
					PreparedStatement stmtcheckout5 = conn.prepareStatement("UPDATE camera SET statusCamera = ? WHERE IDCamera= ?");
					stmtcheckout5.setString(1,"Libera");
					stmtcheckout5.setInt(2, nrcamera);
					stmtcheckout5.executeUpdate();
					
					
					JOptionPane.showMessageDialog(null, "Se salveaza facturile !","Verifica dosarul !", JOptionPane.INFORMATION_MESSAGE);
					
				// se creeaza factura de sejur(PDF)
					
				int nrRezervare = idrezervare;
				
				
				String filePath = "C:\\Users\\Gabi\\Desktop\\facturi_sejur_PDF\\"; 
				String fileName = filePath + "Factura_sejur_rezervare_" + nrRezervare + "_" + checkout + ".pdf";

			    PdfWriter writer = new PdfWriter(new FileOutputStream(fileName));
			    PdfDocument pdf = new PdfDocument(writer);
			    Document document = new Document(pdf, PageSize.A4);
			        
			        


			        // header
			    document.add(new Paragraph("FACTURA DE SEJUR").setFontSize(16)
			                .setTextAlignment(TextAlignment.CENTER).setMarginBottom(5));
			        
			      
			    document.add(new Paragraph("Factura cu nr: " + idrezervare).setFontSize(13)
			        		.setTextAlignment(TextAlignment.CENTER).setMarginBottom(15));
		
		        document.add(new Paragraph("---------------------------------------------------------------------------------------------------------------------------------").setTextAlignment(TextAlignment.CENTER) .setMarginBottom(10));
			  
		        
		        // detalii
		        
			        document.add(new Paragraph("Detalii client:").setMarginBottom(10));
		            document.add(new Paragraph("Nume: " + numeclient));
		            document.add(new Paragraph("Telefon: " + telefon));
		            document.add(new Paragraph("Email: " + emailclient));
		            
		            document.add(new Paragraph("---------------------------------------------------------------------------------------------------------------------------------").setTextAlignment(TextAlignment.CENTER) .setMarginBottom(15));

		            document.add(new Paragraph("Detalii sejur:").setMarginBottom(10));
		            document.add(new Paragraph("Numar camera: " + nrcamera));
		            document.add(new Paragraph("Tip : " + tipcamera));
		            document.add(new Paragraph("Pret pe noapte: " + pretcam));
		            document.add(new Paragraph("Servicii Spa: " + idspa));
		            document.add(new Paragraph("Total Spa: " +  pretspa * nopti));
		            document.add(new Paragraph("Total restaurant: " + totalmasa));
		            
		            document.add(new Paragraph("---------------------------------------------------------------------------------------------------------------------------------").setTextAlignment(TextAlignment.CENTER).setMarginBottom(15));

		            
		            Table table = new Table(4); 
		            table.addCell(new Cell().add(new Paragraph("Data check IN :\n" + checkin)));
		            table.addCell(new Cell().add(new Paragraph("Data check OUT :\n" + checkout)));
		            table.addCell(new Cell().add(new Paragraph("Sejur (nopti ) : \n" + textField4.getText())));
		            table.addCell(new Cell().add(new Paragraph("Total de plata :\n" + Float.parseFloat(textField6.getText()))));
		            table.setHorizontalAlignment(HorizontalAlignment.CENTER);
		            document.add(table);
		            document.add(new Paragraph());


		            
		            document.add(new Paragraph("------------------------------------------------------------------------------------------------------------------------------").setTextAlignment(TextAlignment.CENTER).setMarginBottom(15));
		            document.add(new Paragraph("Labirint Hotel Nr.113 Bucuresti").setFontSize(11));
		            document.add(new Paragraph("Telefon : +40735784881").setFontSize(11));
		            document.add(new Paragraph("Email: reservations@labirinthotel.ro                                                                                                 Multumim!").setFontSize(11));
		            

		            Image icon = new Image(ImageDataFactory.create("C:\\Users\\Gabi\\eclipse-workspace\\HOTEL\\src\\images\\labirint.png"));
		            float x = (PageSize.A4.getWidth() - icon.getImageScaledWidth()) / 2;
		            float y = PageSize.A4.getBottom() + icon.getImageScaledHeight();
		            icon.setFixedPosition(x, y);
		            icon.scale(0.8f, 0.8f);
		            document.add(icon);
		            					    
		            document.close();
		            writer.close();
		            

		         // se creeaza factura fiscala(PDF)
		            
		            int nrRezervarefisk = idrezervare;
					
					
					String filePath2 = "C:\\Users\\Gabi\\Desktop\\facturi_fiscale_PDF\\"; 
					String fileName2 = filePath2 + "Factura_fiscala_rezervare_" + nrRezervarefisk + "_" + checkout + ".pdf";

				    PdfWriter writer2 = new PdfWriter(new FileOutputStream(fileName2));
				    PdfDocument pdf2 = new PdfDocument(writer2);
				    Document document2 = new Document(pdf2, PageSize.A4);
					
				    // Header
		            document2.add(new Paragraph("Furnizor:S.C.CHAB IMPEX 2003S.R.L                                                                            Cumparator: " + numeclient).setFontSize(10).setTextAlignment(TextAlignment.LEFT));
		            document2.add(new Paragraph("Reg.com.:J40/5997/2003                                                                   Sediul:Strada " + strada +"Nr."+numar + oras+","+tara).setFontSize(10).setTextAlignment(TextAlignment.LEFT));
		            document2.add(new Paragraph("Capital social:107.5042,35                                                                                             CIF: .......................................").setFontSize(10).setTextAlignment(TextAlignment.LEFT));
		            document2.add(new Paragraph("CIF:RO15408327                                                                                                         Reg.Com : ..................................").setFontSize(10).setTextAlignment(TextAlignment.LEFT));
		            document2.add(new Paragraph("Sediul:Strada Labirint Nr.113 Bucuresti,Romania                                                             Banca : ....................................").setFontSize(10).setTextAlignment(TextAlignment.LEFT));
		            document2.add(new Paragraph("Contul:ROINGB412412667890").setFontSize(10));
		            document2.add(new Paragraph("Banca:ING Bank Bucuresti").setFontSize(10));
		            
		          
		            document2.add(new Paragraph("FACTURA").setFontSize(16).setTextAlignment(TextAlignment.CENTER).setMarginBottom(3));
		            document2.add(new Paragraph("Numar Factura #" + nrRezervarefisk).setFontSize(13).setTextAlignment(TextAlignment.CENTER).setMarginBottom(15));
		            document2.add(new Paragraph("------------------------------------------------------------------------------------------------------------------------------").setTextAlignment(TextAlignment.CENTER).setMarginBottom(15));
		            
		            // Tabel
		            
		            Table table2 = new Table(7);
		            table2.addHeaderCell(new Cell().add(new Paragraph("Nr.crt.").setFontSize(10).setTextAlignment(TextAlignment.CENTER)));
		            table2.addHeaderCell(new Cell().add(new Paragraph("Denumirea produselor sau a serviciilor").setFontSize(10).setTextAlignment(TextAlignment.CENTER)));
		            table2.addHeaderCell(new Cell().add(new Paragraph("U.M").setFontSize(10).setTextAlignment(TextAlignment.CENTER)));
		            table2.addHeaderCell(new Cell().add(new Paragraph("Cantitatea").setFontSize(10).setTextAlignment(TextAlignment.CENTER)));
		            table2.addHeaderCell(new Cell().add(new Paragraph("Pretul unitar(fara T.V.A)").setFontSize(10).setTextAlignment(TextAlignment.CENTER)));
		            table2.addHeaderCell(new Cell().add(new Paragraph("Valoarea").setFontSize(10).setTextAlignment(TextAlignment.CENTER)));
		            table2.addHeaderCell(new Cell().add(new Paragraph("Valoarea T.V.A").setFontSize(10).setTextAlignment(TextAlignment.CENTER)));
		            table2.setHorizontalAlignment(HorizontalAlignment.CENTER);
		            table2.setMarginBottom(5);
		            
		           
		            
		            
		            table2.addCell(new Cell().add(new Paragraph("1\n\n\n2\n\n\n3")).setPadding(5).setFontSize(10));
		            table2.addCell(new Cell().add(new Paragraph("Servicii de cazare " + tipcamera + checkin + "-" + checkout + "\n\nServicii restaurant\n\n\nServicii spa " + "("+ idspa+")")).setPadding(5).setFontSize(10));
		            table2.addCell(new Cell().add(new Paragraph("buc\n\n\nbuc\n\n\nbuc")).setPadding(5).setFontSize(10));
		            table2.addCell(new Cell().add(new Paragraph("1\n\n\n" + number + "\n\n\n" + numberspa)).setPadding(5).setFontSize(10));
		            table2.addCell(new Cell().add(new Paragraph(pretcam + "\n\n\n" + totalmasa + "\n\n\n" + pretspa * nopti)).setPadding(5).setFontSize(10));
		            table2.addCell(new Cell().add(new Paragraph(pretcam * nopti + "\n\n\n" + totalmasa + "\n\n\n" + pretspa * nopti)).setPadding(5).setFontSize(10));
		            table2.addCell(new Cell().add(new Paragraph(0.09 * (pretcam * nopti) + "\n\n\n" + 0.09 * totalmasa + "\n\n\n" + 0.09 * (pretspa * nopti))).setPadding(5).setFontSize(10));
		            document2.add(table2);

		            
		            document2.add(new Paragraph("------------------------------------------------------------------------------------------------------------------------------").setTextAlignment(TextAlignment.CENTER).setMarginBottom(10));
		            document2.add(new Paragraph("Total: " + Float.parseFloat(textField5.getText())).setTextAlignment(TextAlignment.LEFT).setFontSize(11));  
		            document2.add(new Paragraph("TVA: " + 0.09*Float.parseFloat(textField5.getText())).setTextAlignment(TextAlignment.LEFT).setFontSize(11));
		            document2.add(new Paragraph("Total de plata: " + Float.parseFloat(textField6.getText())).setTextAlignment(TextAlignment.LEFT).setFontSize(11));
		            document2.add(new Paragraph("Semnatura si stampila :").setTextAlignment(TextAlignment.RIGHT).setMarginBottom(5).setFontSize(12));
		            document2.add(new Paragraph("...............................................").setTextAlignment(TextAlignment.RIGHT));
		            

		            
		            document2.close();
		            writer2.close();
					
					}catch (Exception e1) {
					e1.printStackTrace();
				}
			
			}
	});
		
		btnNewButton_2.setBounds(703, 644, 138, 29);
		btnNewButton_2.setForeground(Color.DARK_GRAY);
		btnNewButton_2.setBackground(Color.LIGHT_GRAY);
		btnNewButton_2.setFont(new Font("SansSerif", Font.BOLD, 16));
		frame.getContentPane().add(btnNewButton_2);
		
		btnNewButton_3 = new JButton("");
		btnNewButton_3.setIcon(new ImageIcon(CHECK_OUT.class.getResource("/images/icons8-update-left-rotation-24.png")));
		btnNewButton_3.setBounds(1487, 821, 37, 29);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CHECK_OUT coutWindow = new CHECK_OUT();
				coutWindow.frame.setVisible(true);
				coutWindow.frame.setLocationRelativeTo(null);
			    frame.dispose();
				
			}
		});
		
		btnNewButton_3.setForeground(new Color(255, 255, 255));
		btnNewButton_3.setBackground(Color.WHITE);
		btnNewButton_3.setFont(new Font("SansSerif", Font.BOLD, 15));
		frame.getContentPane().add(btnNewButton_3);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(107, 404, 1350, 192);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
					"Cod Rezervare", "Cod Client", "Nr. Camera", "Cod Spa", "Data Check-in", "Data Check-out", "Nr.Persoane", "Status rezervare"
			}
		));
		
		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DASHBOARD window = new DASHBOARD();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
				
			}
		});
		lblNewLabel_2.setIcon(new ImageIcon(CHECK_OUT.class.getResource("/images/icons8-home-page-48.png")));
		lblNewLabel_2.setBounds(1478, 11, 46, 42);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_5_1 = new JLabel("TOTAL DE PLATA (FARA TVA)");
		lblNewLabel_5_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_5_1.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel_5_1.setBounds(154, 323, 251, 14);
		frame.getContentPane().add(lblNewLabel_5_1);
		
		textField6 = new JTextField();
		textField6.setHorizontalAlignment(SwingConstants.CENTER);
		textField6.setFont(new Font("SansSerif", Font.BOLD, 16));
		textField6.setEditable(false);
		textField6.setColumns(10);
		textField6.setBounds(1215, 320, 156, 21);
		frame.getContentPane().add(textField6);
		
	
		
	}
}
