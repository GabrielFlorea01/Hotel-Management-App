import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PREPARATE {

	JFrame frame;
	private JTable table;
	private JTextField textField1;
	private JTextField textField3;
	private static final String SQL_INSERT = "INSERT INTO hotel.preparate (descriere, pret) VALUES (?,?)";
	private JTextField textField;
	private JTextField textField2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PREPARATE window = new PREPARATE();
					window.frame.setVisible(true);
					window.frame.setResizable(false);
					window.frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PREPARATE() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 1550, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("PREPARATE");
		lblNewLabel.setForeground(Color.DARK_GRAY);
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setIcon(new ImageIcon(RESTAURANT.class.getResource("/images/icons8-restaurant-on-site-48.png")));
		lblNewLabel.setBounds(21, 22, 180, 56);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton_1 = new JButton("Arata preparatele");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
						PreparedStatement stmt = conn.prepareStatement("SELECT * from hotel.preparate");)
						{
						ResultSet rs = stmt.executeQuery();
						DefaultTableModel tm = (DefaultTableModel)table.getModel();
						tm.setRowCount(0);
						
						while(rs.next()) {
							Object o[]= {rs.getInt("IDPreparat"),rs.getString("descriere"),rs.getString("categorie"),rs.getString("pret")};
						    tm.addRow(o);
						}
						
						
						
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
						
					
			
				
			}
		});
		btnNewButton_1.setForeground(Color.DARK_GRAY);
		btnNewButton_1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_1.setBackground(Color.LIGHT_GRAY);
		btnNewButton_1.setBounds(1024, 786, 145, 29);
		frame.getContentPane().add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(315, 421, 854, 354);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Arial", Font.ITALIC, 13));
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"IDPreparat", "Descriere preparat", "Categorie", "Pret "
			}
		));
		table.getColumnModel().getColumn(0).setResizable(false);
		table.getColumnModel().getColumn(1).setResizable(false);
		table.getColumnModel().getColumn(2).setResizable(false);
		table.getColumnModel().getColumn(3).setResizable(false);
		scrollPane.setViewportView(table);
		
		JButton btnNewButton6 = new JButton("");
		btnNewButton6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PREPARATE window = new PREPARATE();
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		btnNewButton6.setIcon(new ImageIcon(PREPARATE.class.getResource("/images/icons8-update-left-rotation-24.png")));
		btnNewButton6.setBackground(Color.LIGHT_GRAY);
		btnNewButton6.setBounds(1484, 821, 40, 29);
		frame.getContentPane().add(btnNewButton6);
		
		JLabel lblNewLabel_1 = new JLabel("Introdu denumirea");
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setBounds(109, 158, 145, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Introdu pretul");
		lblNewLabel_2.setForeground(Color.DARK_GRAY);
		lblNewLabel_2.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_2.setBounds(1134, 158, 110, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField1 = new JTextField();
		textField1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField1.setColumns(10);
		textField1.setBounds(109, 183, 261, 24);
		frame.getContentPane().add(textField1);
		
		textField3 = new JTextField();
		textField3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField3.setColumns(10);
		textField3.setBounds(1134, 183, 217, 24);
		frame.getContentPane().add(textField3);
		
		JButton btnNewButton_1_1 = new JButton("Salveaza");
		btnNewButton_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton_1_1.setForeground(Color.green);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton_1_1.setForeground(Color.DARK_GRAY);
			}
		});
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String denumire= textField1.getText();
				String pret=textField3.getText();
				
				
				ResultSet rs=null;
				
				
				if (denumire.equals("")||pret.equals("")) 
				{
					JOptionPane.showMessageDialog(null, "Fiecare camp trebuie completat !");
				}
				
				else{
					
					try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root",
						"Gabriel01");
						
	
					PreparedStatement stmt = conn.prepareStatement("SELECT IDPreparat from hotel.preparate WHERE descriere = ?");) {
					
						stmt.setString(1, denumire);
					    rs = stmt.executeQuery();
					  
					    if(rs.next()) 
					    {
					    	
					    	JOptionPane.showMessageDialog(null, "Preparatul deja exista !");
					    } 
					    else 
					    {
					    	PreparedStatement stmt2= conn.prepareStatement(SQL_INSERT);
							stmt2.setString(1,denumire);
							stmt2.setString(2,pret);
						    stmt2.executeUpdate();
						    JOptionPane.showMessageDialog(null, "Preparatul a fost adaugat cu succes !");
						    
					
						    PREPARATE window = new PREPARATE();
							window.frame.setVisible(true);
							window.frame.setResizable(false);
							window.frame.setLocationRelativeTo(null);
							frame.dispose();
						    
					
						    
					           
					    }
					    
					}
					   
					    catch (SQLException ex) {
					         ex.printStackTrace();
					    
					    }
					 };
				
				
			}
		});
		btnNewButton_1_1.setForeground(Color.DARK_GRAY);
		btnNewButton_1_1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_1_1.setBackground(Color.LIGHT_GRAY);
		btnNewButton_1_1.setBounds(531, 292, 153, 29);
		frame.getContentPane().add(btnNewButton_1_1);
		
		JButton btnNewButton_1_3 = new JButton("Sterge");
		btnNewButton_1_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnNewButton_1_3.setForeground(Color.red);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnNewButton_1_3.setForeground(Color.DARK_GRAY);
			}
		});
		
		btnNewButton_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String denumire = textField.getText();
				
				if (denumire.equals("")) 
				{
					JOptionPane.showMessageDialog(null, "Completeaza denumirea preparatului !");
				}
				
				else 
				try 
				(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
						PreparedStatement stmt = conn.prepareStatement("DELETE from hotel.preparate WHERE descriere = ?");)
								{
									stmt.setString(1, denumire);
									int count =stmt.executeUpdate();
									JOptionPane.showMessageDialog(null, "Preparatul a fost sters cu succes !");
									PREPARATE window = new PREPARATE();
									window.frame.setVisible(true);
									window.frame.setResizable(false);
									window.frame.setLocationRelativeTo(null);
									
								}catch (SQLException e1) {
									e1.printStackTrace();
								}
				
			}
		});
		btnNewButton_1_3.setForeground(Color.DARK_GRAY);
		btnNewButton_1_3.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 13));
		btnNewButton_1_3.setBackground(Color.LIGHT_GRAY);
		btnNewButton_1_3.setBounds(813, 293, 137, 27);
		frame.getContentPane().add(btnNewButton_1_3);
		
		textField = new JTextField();
		textField.setBounds(684, 39, 237, 24);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnCautaPreparat = new JButton("CAUTA");
		btnCautaPreparat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String descriere = textField.getText();
				
				if (descriere.equals("")) 
				{
					JOptionPane.showMessageDialog(null, "Completeaza denumirea preparatului !");
				}else 
				
				try 
				(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root","Gabriel01");
				PreparedStatement stmt = conn.prepareStatement("SELECT IDPReparat, descriere, pret from hotel.preparate WHERE descriere = ?");)
				{
					stmt.setString(1, descriere);
					ResultSet rs =stmt.executeQuery();
					DefaultTableModel tm = (DefaultTableModel)table.getModel();
					tm.setRowCount(0);
					
					while(rs.next()) {
						Object o[]= {rs.getInt("IDPreparat"),rs.getString("descriere"),rs.getString("pret")};
					    tm.addRow(o);
					}
					
				}catch (SQLException e1) {
					e1.printStackTrace();
				}
				
			
				
				
			}
		});
		btnCautaPreparat.setForeground(Color.DARK_GRAY);
		btnCautaPreparat.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 15));
		btnCautaPreparat.setBackground(Color.LIGHT_GRAY);
		btnCautaPreparat.setBounds(931, 37, 90, 26);
		frame.getContentPane().add(btnCautaPreparat);
		
		JLabel lblNewLabel_2_1 = new JLabel("Introdu categoria");
		lblNewLabel_2_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_2_1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_2_1.setBounds(630, 153, 145, 24);
		frame.getContentPane().add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Introdu denumirea preparatului");
		lblNewLabel_1_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1_1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1_1.setBounds(455, 43, 229, 14);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		textField2 = new JTextField();
		textField2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField2.setColumns(10);
		textField2.setBounds(630, 183, 261, 24);
		frame.getContentPane().add(textField2);
		
		JLabel lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				RESTAURANT window = new RESTAURANT();
				window.frame.setSize(1550,900);
				window.frame.setVisible(true);
				window.frame.setResizable(false);
				window.frame.setLocationRelativeTo(null);
				frame.dispose();
			}
		});
		
		lblNewLabel_3.setIcon(new ImageIcon(PREPARATE.class.getResource("/images/icons8-restaurant-on-site-48.png")));
		lblNewLabel_3.setBounds(1478, 11, 46, 52);
		frame.getContentPane().add(lblNewLabel_3);
		

	}
}
